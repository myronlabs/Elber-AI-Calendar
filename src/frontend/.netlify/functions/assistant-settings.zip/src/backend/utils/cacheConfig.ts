// src/backend/utils/cacheConfig.ts
// Centralized cache configuration for backend services - single source of truth

/**
 * Centralized cache configuration for backend services
 * This ensures consistent cache behavior across all backend functions
 */
export const CACHE_CONFIG = {
  // Ultra-short TTL for assistant operations (near-instant updates)
  ASSISTANT_UPDATES: 100, // 100ms - for immediate assistant operations updates
  
  // Short TTL for interactive operations  
  USER_OPERATIONS: 1 * 1000, // 1 second - for data modified by user operations
  
  // Search operations (should be very responsive)
  SEARCH_RESULTS: 100, // 100ms - for search results that change frequently
  
  // General data operations
  GENERAL_DATA: 200, // 200ms - default for most data operations
  
  // Static/configuration data (can be cached longer)
  STATIC_DATA: 5 * 1000, // 5 seconds - for data that rarely changes (meets 5 second max requirement)
  
  // Rate limiting and security (can be cached longer)
  RATE_LIMIT_DATA: 60 * 1000, // 1 minute - for rate limiting data
  
  // OAuth tokens and auth data
  AUTH_TOKENS: 5 * 60 * 1000, // 5 minutes - for auth tokens (security sensitive)
} as const;

/**
 * Cache cleanup intervals
 */
export const CACHE_CLEANUP_CONFIG = {
  // Backend cache cleanup interval
  BACKEND_CLEANUP_INTERVAL: 2 * 1000, // 2 seconds - faster cleanup
  
  // Query timeout
  QUERY_TIMEOUT_MS: 5 * 1000, // 5 seconds - reduced from 10 seconds to meet max requirement
} as const;

/**
 * Cache size limits
 */
export const CACHE_SIZE_CONFIG = {
  // Backend cache limits  
  SEARCH_CACHE_MAX_SIZE: 200,
  AI_RESPONSE_CACHE_MAX_SIZE: 100,
  CONFIG_CACHE_MAX_SIZE: 50,
} as const;

/**
 * Helper function to get appropriate TTL based on operation type
 */
export function getCacheTTL(operationType: 'assistant' | 'user' | 'search' | 'general' | 'static' | 'auth'): number {
  switch (operationType) {
    case 'assistant':
      return CACHE_CONFIG.ASSISTANT_UPDATES;
    case 'user':
      return CACHE_CONFIG.USER_OPERATIONS;
    case 'search':
      return CACHE_CONFIG.SEARCH_RESULTS;
    case 'general':
      return CACHE_CONFIG.GENERAL_DATA;
    case 'static':
      return CACHE_CONFIG.STATIC_DATA;
    case 'auth':
      return CACHE_CONFIG.AUTH_TOKENS;
    default:
      return CACHE_CONFIG.GENERAL_DATA;
  }
}

/**
 * Type-safe cache operation types
 */
export type CacheOperationType = 'assistant' | 'user' | 'search' | 'general' | 'static' | 'auth';
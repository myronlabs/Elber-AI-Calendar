"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/backend/functions/assistant-conversation-tracking.ts
var assistant_conversation_tracking_exports = {};
__export(assistant_conversation_tracking_exports, {
  ConversationTracker: () => ConversationTracker,
  createUpdateContactArgs: () => createUpdateContactArgs
});
module.exports = __toCommonJS(assistant_conversation_tracking_exports);
var ConversationTracker = class {
  static {
    this.ENTITY_RETENTION_MINUTES = 30;
  }
  static {
    this.MAX_TRACKED_ENTITIES = 10;
  }
  /**
   * Extract entity references from tool call results and assistant responses
   */
  static extractEntityReferences(messages, toolResults) {
    const entities = [];
    const now = /* @__PURE__ */ new Date();
    if (toolResults) {
      for (const result of toolResults) {
        try {
          const resultData = JSON.parse(result.content);
          if (resultData.contacts && Array.isArray(resultData.contacts)) {
            for (const contact of resultData.contacts) {
              if (contact.contact_id && contact.first_name) {
                entities.push({
                  id: contact.contact_id,
                  type: "contact",
                  name: this.formatContactName(contact),
                  lastMentioned: now,
                  context: this.inferContactContext(resultData.message || ""),
                  metadata: {
                    email: contact.email,
                    company: contact.company,
                    phone: contact.phone
                  }
                });
              }
            }
          }
          if (resultData.contact && resultData.contact.contact_id) {
            const contact = resultData.contact;
            entities.push({
              id: contact.contact_id,
              type: "contact",
              name: this.formatContactName(contact),
              lastMentioned: now,
              context: this.inferContactContext(resultData.message || ""),
              metadata: {
                email: contact.email,
                company: contact.company,
                phone: contact.phone
              }
            });
          }
        } catch (error) {
          console.warn("[ConversationTracker] Failed to parse tool result:", error);
        }
      }
    }
    return entities;
  }
  /**
   * Analyze user message for contextual update requests
   * Since the router has already determined this is a contact operation,
   * focus on extracting contact name and update fields
   */
  static analyzeUpdateIntent(userMessage, recentEntities) {
    const recentContacts = recentEntities.filter((e) => e.type === "contact").sort((a, b) => b.lastMentioned.getTime() - a.lastMentioned.getTime());
    const updateFields = this.extractUpdateFields(userMessage);
    if (Object.keys(updateFields).length === 0) {
      return null;
    }
    const hasContextualLanguage = /\b(the contact|his|her|their|again|that person)\b/i.test(userMessage);
    if (hasContextualLanguage && recentContacts.length > 0) {
      const targetContact = recentContacts[0];
      return {
        entityId: targetContact.id,
        entityType: "contact",
        entityName: targetContact.name,
        updateFields,
        confidence: recentContacts.length === 1 ? "high" : "medium"
      };
    }
    return null;
  }
  /**
   * Extract specific field updates from natural language
   */
  static extractUpdateFields(message) {
    const fields = {};
    const message_lower = message.toLowerCase();
    const birthdayPatterns = [
      /birthday\s+(?:is\s+)?(\d{1,2}[-\/]\d{1,2}[-\/]\d{4})/i,
      /birthday\s+(?:is\s+)?(\d{4}[-\/]\d{1,2}[-\/]\d{1,2})/i,
      /born\s+(?:on\s+)?(\d{1,2}[-\/]\d{1,2}[-\/]\d{4})/i,
      /dob\s+(?:is\s+)?(\d{1,2}[-\/]\d{1,2}[-\/]\d{4})/i
    ];
    for (const pattern of birthdayPatterns) {
      const match = message.match(pattern);
      if (match) {
        fields.birthday = this.normalizeDateFormat(match[1]);
        break;
      }
    }
    const emailPattern = /email\s+(?:to\s+|is\s+)?([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i;
    const emailMatch = message.match(emailPattern);
    if (emailMatch) {
      fields.email = emailMatch[1];
    }
    const phonePattern = /phone\s+(?:to\s+|is\s+|number\s+)?([+]?[\d\s\-\(\)\.]{10,})/i;
    const phoneMatch = message.match(phonePattern);
    if (phoneMatch) {
      fields.phone = phoneMatch[1].trim();
    }
    const companyPattern = /company\s+(?:to\s+|is\s+)?([^.,!?]+?)(?:\s+(?:and|,|\.|\!|\?)|$)/i;
    const companyMatch = message.match(companyPattern);
    if (companyMatch) {
      fields.company = companyMatch[1].trim();
    }
    const jobTitlePattern = /(?:job\s+title|title|position)\s+(?:to\s+|is\s+)?([^.,!?]+?)(?:\s+(?:and|,|\.|\!|\?)|$)/i;
    const jobTitleMatch = message.match(jobTitlePattern);
    if (jobTitleMatch) {
      fields.job_title = jobTitleMatch[1].trim();
    }
    const addressPattern = /address\s+(?:to\s+|is\s+)?([^.,!?]+?)(?:\s+(?:and|,|\.|\!|\?)|$)/i;
    const addressMatch = message.match(addressPattern);
    if (addressMatch) {
      fields.address = addressMatch[1].trim();
    }
    const websitePattern = /website\s+(?:to\s+|is\s+)?(https?:\/\/[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i;
    const websiteMatch = message.match(websitePattern);
    if (websiteMatch) {
      fields.website = websiteMatch[1];
    }
    const notesPattern = /notes?\s+(?:to\s+|is\s+)?["']?([^"']+?)["']?(?:\s+(?:and|,|\.|\!|\?)|$)/i;
    const notesMatch = message.match(notesPattern);
    if (notesMatch) {
      fields.notes = notesMatch[1].trim();
    }
    return fields;
  }
  /**
   * Check if a user message contains an explicit entity reference
   */
  static hasExplicitEntityReference(message, entityType = "contact") {
    const message_lower = message.toLowerCase();
    if (entityType === "contact") {
      const namePatterns = [
        /(?:contact\s+)?[A-Z][a-z]+\s+[A-Z][a-z]+/,
        // "John Doe" or "contact John Doe"
        /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/,
        // email addresses
        /(?:for|find|edit|update)\s+[A-Z][a-z]+/
        // "edit John", "find Sarah"
      ];
      return namePatterns.some((pattern) => pattern.test(message));
    }
    return false;
  }
  /**
   * Merge conversation context with recent entities
   */
  static mergeContext(existingEntities, newEntities) {
    const merged = [...existingEntities];
    const now = /* @__PURE__ */ new Date();
    const retentionCutoff = new Date(now.getTime() - this.ENTITY_RETENTION_MINUTES * 60 * 1e3);
    for (const entity of newEntities) {
      const existingIndex = merged.findIndex((e) => e.id === entity.id && e.type === entity.type);
      if (existingIndex >= 0) {
        merged[existingIndex] = entity;
      } else {
        merged.push(entity);
      }
    }
    return merged.filter((entity) => entity.lastMentioned > retentionCutoff).sort((a, b) => b.lastMentioned.getTime() - a.lastMentioned.getTime()).slice(0, this.MAX_TRACKED_ENTITIES);
  }
  /**
   * Helper methods
   */
  static formatContactName(contact) {
    const firstName = contact.first_name || "";
    const lastName = contact.last_name || "";
    const middleName = contact.middle_name || "";
    if (middleName) {
      return `${firstName} ${middleName} ${lastName}`.trim();
    }
    return `${firstName} ${lastName}`.trim();
  }
  static inferContactContext(message) {
    const msg = message.toLowerCase();
    if (msg.includes("created") || msg.includes("added")) return "created";
    if (msg.includes("updated") || msg.includes("modified")) return "updated";
    if (msg.includes("deleted") || msg.includes("removed")) return "deleted";
    if (msg.includes("found") || msg.includes("searching")) return "searched";
    return "viewed";
  }
  static normalizeDateFormat(dateStr) {
    const dateStr_clean = dateStr.replace(/\s+/g, "");
    const mdyPattern = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/;
    const mdyMatch = dateStr_clean.match(mdyPattern);
    if (mdyMatch) {
      const [, month, day, year] = mdyMatch;
      return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }
    const ymdPattern = /^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/;
    const ymdMatch = dateStr_clean.match(ymdPattern);
    if (ymdMatch) {
      const [, year, month, day] = ymdMatch;
      return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }
    return dateStr;
  }
};
function createUpdateContactArgs(contactId, currentContact, updateFields) {
  return {
    contact_id: contactId,
    first_name: updateFields.first_name ?? currentContact.first_name ?? null,
    middle_name: updateFields.middle_name ?? currentContact.middle_name ?? null,
    last_name: updateFields.last_name ?? currentContact.last_name ?? null,
    nickname: updateFields.nickname ?? currentContact.nickname ?? null,
    email: updateFields.email ?? currentContact.email ?? null,
    phone: updateFields.phone ?? currentContact.phone ?? null,
    company: updateFields.company ?? currentContact.company ?? null,
    job_title: updateFields.job_title ?? currentContact.job_title ?? null,
    address: updateFields.address ?? currentContact.address ?? null,
    website: updateFields.website ?? currentContact.website ?? null,
    birthday: updateFields.birthday ?? currentContact.birthday ?? null,
    notes: updateFields.notes ?? currentContact.notes ?? null
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ConversationTracker,
  createUpdateContactArgs
});

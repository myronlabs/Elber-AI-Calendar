"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/backend/functions/assistant-contacts-fast.ts
var assistant_contacts_fast_exports = {};
__export(assistant_contacts_fast_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(assistant_contacts_fast_exports);

// node_modules/jwt-decode/build/esm/index.js
var InvalidTokenError = class extends Error {
};
InvalidTokenError.prototype.name = "InvalidTokenError";
function b64DecodeUnicode(str) {
  return decodeURIComponent(atob(str).replace(/(.)/g, (m, p) => {
    let code = p.charCodeAt(0).toString(16).toUpperCase();
    if (code.length < 2) {
      code = "0" + code;
    }
    return "%" + code;
  }));
}
function base64UrlDecode(str) {
  let output = str.replace(/-/g, "+").replace(/_/g, "/");
  switch (output.length % 4) {
    case 0:
      break;
    case 2:
      output += "==";
      break;
    case 3:
      output += "=";
      break;
    default:
      throw new Error("base64 string is not of the correct length");
  }
  try {
    return b64DecodeUnicode(output);
  } catch (err) {
    return atob(output);
  }
}
function jwtDecode(token, options) {
  if (typeof token !== "string") {
    throw new InvalidTokenError("Invalid token specified: must be a string");
  }
  options || (options = {});
  const pos = options.header === true ? 0 : 1;
  const part = token.split(".")[pos];
  if (typeof part !== "string") {
    throw new InvalidTokenError(`Invalid token specified: missing part #${pos + 1}`);
  }
  let decoded;
  try {
    decoded = base64UrlDecode(part);
  } catch (e) {
    throw new InvalidTokenError(`Invalid token specified: invalid base64 for part #${pos + 1} (${e.message})`);
  }
  try {
    return JSON.parse(decoded);
  } catch (e) {
    throw new InvalidTokenError(`Invalid token specified: invalid json for part #${pos + 1} (${e.message})`);
  }
}

// src/backend/functions/_shared/utils.ts
var getUserIdFromEvent = (event, functionName = "shared-utils") => {
  const authHeader = event.headers?.authorization;
  const logPrefix = `[${functionName}]`;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.substring(7);
    try {
      const decodedToken = jwtDecode(token);
      if (decodedToken && decodedToken.sub) {
        console.log(`${logPrefix} Extracted user ID (sub): ${decodedToken.sub} from JWT.`);
        return decodedToken.sub;
      } else {
        console.warn(`${logPrefix} JWT decoded but did not contain a sub (user ID) claim. Decoded token:`, decodedToken);
        return null;
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error during JWT decoding.";
      console.error(`${logPrefix} Error decoding JWT: ${errorMessage}`, error);
      return null;
    }
  }
  if (!authHeader) {
    console.warn(`${logPrefix} No Authorization header found.`);
  } else if (!authHeader.startsWith("Bearer ")) {
    console.warn(`${logPrefix} Authorization header found but is not a Bearer token.`);
  }
  return null;
};

// src/backend/services/fastContactFormatter.ts
var FastContactFormatter = class {
  /**
   * Format contacts into a markdown response immediately
   * This provides instant feedback while AI generates a more detailed response
   */
  static formatContactsForDisplay(contacts, query) {
    const cleanQuery = query ? query.replace(/["*]/g, "").trim() : "";
    let header = "";
    let body = "";
    const formatterId = `format-${Date.now()}`;
    if (contacts.length === 0) {
      return "No contacts found matching your search.";
    }
    console.log(`[FastContactFormatter ${formatterId}] Formatting ${contacts.length} contacts for query: '${cleanQuery}'`);
    if (contacts.length === 1) {
      header = "";
    } else if (contacts.length > 1) {
      header = `Found ${contacts.length} contacts${cleanQuery ? ` related to "${cleanQuery}"` : ""}:

`;
    }
    contacts.forEach((contact, index) => {
      body += `### ${index + 1}. ${contact.first_name} ${contact.last_name || ""}
`;
      if (contact.email) {
        body += `- **Email**: ${contact.email}
`;
      }
      if (contact.phone) {
        body += `- **Phone**: ${contact.phone}
`;
      }
      if (contact.company) {
        body += `- **Company**: ${contact.company}
`;
        if (contact.job_title) {
          body += `- **Job Title**: ${contact.job_title}
`;
        }
      }
      if (contact.formatted_address) {
        body += `- **Address**: ${contact.formatted_address}
`;
      } else if (contact.street_address) {
        const addressParts = [];
        if (contact.street_address) addressParts.push(contact.street_address);
        if (contact.street_address_2) addressParts.push(contact.street_address_2);
        const cityStateZip = [];
        if (contact.city) cityStateZip.push(contact.city);
        if (contact.state_province || contact.postal_code) {
          const stateZip = [contact.state_province, contact.postal_code].filter(Boolean).join(" ");
          if (stateZip) cityStateZip.push(stateZip);
        }
        if (cityStateZip.length > 0) addressParts.push(cityStateZip.join(", "));
        if (contact.country) addressParts.push(contact.country);
        body += `- **Address**: ${addressParts.join("\n")}
`;
      }
      if (contact.birthday) {
        const date = new Date(contact.birthday);
        body += `- **Birthday**: ${date.toLocaleDateString()}
`;
      }
      if (contact.notes) {
        body += `- **Notes**: ${contact.notes}
`;
      }
      body += "\n";
    });
    return header + body;
  }
  /**
   * Generate a quick summary for large result sets
   */
  static formatContactSummary(contacts, limit = 5) {
    const shown = contacts.slice(0, limit);
    const remaining = contacts.length - limit;
    let response = this.formatContactsForDisplay(shown);
    if (remaining > 0) {
      response += `
... and ${remaining} more contact${remaining === 1 ? "" : "s"}.
`;
      response += `
Please refine your search to see more specific results.`;
    }
    return response;
  }
};

// src/backend/services/assistantConfig.ts
var defaultAssistantConfig = {
  fastContactSearchEnabled: true,
  responseCachingEnabled: true,
  contactSummaryThreshold: 5,
  maxContactResults: 20,
  cacheTimeToLive: 5 * 60 * 1e3,
  // 5 minutes
  upcomingBirthdayDays: 90
  // Look ahead 90 days for birthdays by default
};
function getAssistantConfig() {
  const fastSearchEnabled = process.env.FAST_CONTACT_SEARCH_ENABLED ? process.env.FAST_CONTACT_SEARCH_ENABLED.toLowerCase() !== "false" : true;
  return {
    fastContactSearchEnabled: fastSearchEnabled,
    responseCachingEnabled: process.env.RESPONSE_CACHING_ENABLED !== "false",
    contactSummaryThreshold: parseInt(process.env.CONTACT_SUMMARY_THRESHOLD || "5", 10),
    maxContactResults: parseInt(process.env.MAX_CONTACT_RESULTS || "20", 10),
    cacheTimeToLive: parseInt(process.env.CACHE_TIME_TO_LIVE || String(5 * 60 * 1e3), 10),
    upcomingBirthdayDays: parseInt(process.env.UPCOMING_BIRTHDAY_DAYS || "90", 10)
  };
}

// src/backend/functions/assistant-contacts-fast.ts
var handler = async (event, context) => {
  const reqId = context.awsRequestId || `local-${Date.now()}`;
  const logPrefix = `[assistant-contacts-fast][${reqId}]`;
  console.log(`${logPrefix} Function invoked`);
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: "Method Not Allowed" }),
      headers: { "Content-Type": "application/json" }
    };
  }
  const userId = getUserIdFromEvent(event, "assistant-contacts-fast");
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: "Authentication required" }),
      headers: { "Content-Type": "application/json" }
    };
  }
  try {
    const parsedEventBody = JSON.parse(event.body || "{}");
    const { action, searchTerm, contacts } = parsedEventBody;
    if (action !== "format_contacts") {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "Invalid action" }),
        headers: { "Content-Type": "application/json" }
      };
    }
    const config = getAssistantConfig();
    if (!contacts || !Array.isArray(contacts)) {
      console.error(`${logPrefix} Contacts array is missing or not an array in request body.`);
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "Invalid request: contacts must be an array." }),
        headers: { "Content-Type": "application/json" }
      };
    }
    let formattedResponse;
    if (contacts.length > config.contactSummaryThreshold) {
      formattedResponse = FastContactFormatter.formatContactSummary(
        contacts,
        config.contactSummaryThreshold
      );
    } else {
      formattedResponse = FastContactFormatter.formatContactsForDisplay(
        contacts,
        searchTerm || ""
        // Pass empty string if searchTerm is undefined
      );
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        role: "assistant",
        content: formattedResponse
      }),
      headers: { "Content-Type": "application/json" }
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error(`${logPrefix} Error:`, error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal server error", error: errorMessage }),
      headers: { "Content-Type": "application/json" }
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

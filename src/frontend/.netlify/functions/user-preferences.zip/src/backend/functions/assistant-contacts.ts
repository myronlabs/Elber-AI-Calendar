import type { Handler, HandlerEvent, HandlerContext, HandlerResponse } from "@netlify/functions";
import OpenAI from 'openai';
import fetch from 'node-fetch'; // For making internal HTTP requests
import type { Response as FetchResponse, RequestInit, HeadersInit, RequestInfo } from 'node-fetch'; // Import all needed types from node-fetch
import { contactService } from '@services/contactService';
import type { ContactIdentifier, Contact } from '../types/domain';

// Import shared utilities and types
import {
  isValidUUID,
  getUserIdFromEvent,
  getInternalApiBaseUrl,
  getInternalHeaders
} from './_shared/utils';
import type {
  GenericChatMessage,
  AssistantRequestBody,
  CreateContactToolArgs,
  UpdateContactToolArgs,
  FindContactsToolArgs,
  ConfirmDeleteContactToolArgs,
  FindDuplicateContactsToolArgs,
  FindContactsWithImproperPhoneFormatsToolArgs,
  ContactData,
  ContactSearchApiResponse
} from './_shared/types';
import { FastContactFormatter } from '@services/fastContactFormatter';
import { getAssistantConfig } from '@services/assistantConfig';
import { generateDisplayName } from '../functions/contacts'; // Import the generateDisplayName function

// Import tool handlers
import { handleCreateContact, handleUpdateContact } from './_shared/contactToolHandlers';
import { supabaseAdmin } from '../services/supabaseAdmin'; // Corrected path assuming it's in a parent services directory

// Get assistant config early so it's available throughout the module
const config = getAssistantConfig();

// Type Guards for Tool Arguments
function isCreateContactToolArgs(args: unknown): args is CreateContactToolArgs {
  if (typeof args !== 'object' || args === null) return false;
  const potentialArgs = args as Record<string, unknown>;
  return typeof potentialArgs.first_name === 'string' &&
         (typeof potentialArgs.last_name === 'string' || potentialArgs.last_name === null);
}

function isUpdateContactToolArgs(args: unknown): args is UpdateContactToolArgs {
  if (typeof args !== 'object' || args === null) return false;
  const potentialArgs = args as Record<string, unknown>;
  return typeof potentialArgs.contact_id === 'string' && isValidUUID(potentialArgs.contact_id);
}

function isFindContactsToolArgs(args: unknown): args is FindContactsToolArgs {
  if (typeof args !== 'object' || args === null) return false;
  const potentialArgs = args as Record<string, unknown>;
  // Basic check for existing fields
  const hasBasicFields = 'search_term' in potentialArgs && 
                       (potentialArgs.search_term === null || typeof potentialArgs.search_term === 'string') &&
                       ('contact_id' in potentialArgs ? (potentialArgs.contact_id === null || typeof potentialArgs.contact_id === 'string') : true);

  if (!hasBasicFields) return false;

  // Check optional birthday fields only if they exist
  const hasValidBirthdayQueryType = 'birthday_query_type' in potentialArgs ? 
    (potentialArgs.birthday_query_type === null || 
      ['upcoming', 'on_date', 'in_month', 'in_range'].includes(potentialArgs.birthday_query_type as string)) :
    true;

  const hasValidDateRangeStart = 'date_range_start' in potentialArgs ?
    (potentialArgs.date_range_start === null || 
      (typeof potentialArgs.date_range_start === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(potentialArgs.date_range_start))) :
    true;

  const hasValidDateRangeEnd = 'date_range_end' in potentialArgs ?
    (potentialArgs.date_range_end === null || 
      (typeof potentialArgs.date_range_end === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(potentialArgs.date_range_end))) :
    true;

  const hasValidMonth = 'month' in potentialArgs ?
    (potentialArgs.month === null || 
      (typeof potentialArgs.month === 'number' && potentialArgs.month >= 1 && potentialArgs.month <= 12)) :
    true;

  return hasValidBirthdayQueryType && hasValidDateRangeStart && hasValidDateRangeEnd && hasValidMonth;
}

function isConfirmDeleteContactToolArgs(args: unknown): args is ConfirmDeleteContactToolArgs {
  if (typeof args !== 'object' || args === null) return false;
  const potentialArgs = args as Record<string, unknown>;
  return typeof potentialArgs.contact_id === 'string' && 
         typeof potentialArgs.contact_name === 'string' &&
         typeof potentialArgs.confirm === 'boolean';
}

// Helper function to validate incoming messages against the GenericChatMessage structure.
// This is a basic validation, can be expanded if needed.
const validateMessages = (messages: unknown): messages is GenericChatMessage[] => {
  if (!Array.isArray(messages)) return false;
  return messages.every((msg: unknown) => {
    if (typeof msg !== 'object' || msg === null) return false;
    const msgObj = msg as Record<string, unknown>; // Use Record for loose object check initially
    return (
      typeof msgObj.role === 'string' &&
      (msgObj.content === null || typeof msgObj.content === 'string') &&
      (msgObj.tool_calls === undefined || Array.isArray(msgObj.tool_calls)) &&
      (msgObj.tool_call_id === undefined || typeof msgObj.tool_call_id === 'string')
    );
  });
};

// We've replaced the local resolveContactIdentifier function with the contactService implementation


// REMOVED: DecodedJwt (now in _shared/types.ts, used by getUserIdFromEvent)
// REMOVED: getUserIdFromEvent (now in _shared/utils.ts)
// REMOVED: isValidUUID (now in _shared/utils.ts)
// REMOVED: ConfirmationStatus (now in _shared/types.ts)
// REMOVED: ChatMessage (replaced by GenericChatMessage from _shared/types.ts)
// REMOVED: AssistantRequestBody (now in _shared/types.ts)
// REMOVED: DirectToolCall (now in _shared/types.ts)

// MOVED TO _shared/types.ts: FindDuplicateContactsToolArgs

const tools: OpenAI.Chat.Completions.ChatCompletionTool[] = [
  {
    type: "function",
    function: {
      name: "create_contact",
      description: "Creates a new contact in the CRM. At a minimum, first name and last name are preferred. The more details provided, the better.",
      strict: false,
      parameters: {
        type: "object",
        properties: {
          first_name: { type: "string", description: "First name of the contact." },
          middle_name: { type: ["string", "null"], description: "Middle name of the contact. Can be null." },
          last_name: { type: "string", description: "Last name of the contact." },
          nickname: { type: ["string", "null"], description: "Nickname of the contact. Can be null." },
          email: { type: ["string", "null"], description: "Primary email address. Must be a valid email format if provided. Can be null." },
          phone: { type: ["string", "null"], description: "Primary phone number. Can be null." },
          company: { type: ["string", "null"], description: "Company the contact works for. Can be null." },
          job_title: { type: ["string", "null"], description: "Job title of the contact. Can be null." },
          address: { type: ["string", "null"], description: "Full address of the contact. Can be null." },
          website: { type: ["string", "null"], description: "Website URL. Must be a valid URL if provided. Can be null." },
          birthday: { type: ["string", "null"], description: "Birthday of the contact (YYYY-MM-DD). Can be null." },
          notes: { type: ["string", "null"], description: "Additional notes for the contact. Can be null." }
        },
        required: [
          "first_name",
          "middle_name",
          "last_name",
          "nickname",
          "email",
          "phone",
          "company",
          "job_title",
          "address",
          "website",
          "birthday",
          "notes"
        ],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "update_contact",
      description: "Updates an existing contact in the CRM. Requires the contact_id and at least one field to update.",
      strict: false,
      parameters: {
        type: "object",
        properties: {
          contact_id: { type: "string", description: "The UUID of the contact to update. This is a required field." },
          first_name: { type: ["string", "null"], description: "New first name. Null or empty to clear." },
          middle_name: { type: ["string", "null"], description: "New middle name. Null or empty to clear." },
          last_name: { type: ["string", "null"], description: "New last name. Null or empty to clear." },
          nickname: { type: ["string", "null"], description: "New nickname. Null or empty to clear." },
          email: { type: ["string", "null"], description: "New email. Must be valid format if provided. Null to clear." },
          phone: { type: ["string", "null"], description: "New phone number. Null to clear." },
          company: { type: ["string", "null"], description: "New company. Null to clear." },
          job_title: { type: ["string", "null"], description: "New job title. Null to clear." },
          address: { type: ["string", "null"], description: "New address. Null to clear." },
          website: { type: ["string", "null"], description: "New website. Must be valid URL if provided. Null to clear." },
          birthday: { type: ["string", "null"], description: "New birthday (YYYY-MM-DD). Null to clear." },
          notes: { type: ["string", "null"], description: "New notes. Null to clear." }
        },
        required: [
            "contact_id", 
            "first_name", 
            "middle_name", 
            "last_name", 
            "nickname", 
            "email", 
            "phone", 
            "company", 
            "job_title", 
            "address", 
            "website", 
            "birthday", 
            "notes"
        ],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "find_contacts",
      description: "Finds contacts based on a search term (name, nickname, email, phone, company, job title, address, website), a specific contact_id, or by birthday criteria (upcoming, in a specific month, or on a specific date). If no criteria are provided, it lists all contacts.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          search_term: { type: ["string", "null"], description: "A general search term. Used if not searching by birthday or specific ID." },
          contact_id: { type: ["string", "null"], description: "A specific UUID of a contact. Takes precedence over search_term if provided." },
          birthday_query_type: { 
            type: ["string", "null"], 
            enum: ["upcoming", "on_date", "in_month", "in_range", null],
            description: `Type of birthday search: 'upcoming' (e.g., next ${config.upcomingBirthdayDays} days), 'on_date' (specific MM-DD), 'in_month' (specific month), 'in_range' (between two YYYY-MM-DD dates).`
          },
          date_range_start: { 
            type: ["string", "null"], 
            description: "Start date for birthday range search (YYYY-MM-DD). Used with birthday_query_type 'in_range' or to define 'upcoming' period."
          },
          date_range_end: { 
            type: ["string", "null"], 
            description: "End date for birthday range search (YYYY-MM-DD). Used with birthday_query_type 'in_range'."
          },
          month: { 
            type: ["integer", "null"], 
            minimum: 1, 
            maximum: 12, 
            description: "Month number (1-12) for birthday search. Used with birthday_query_type 'in_month'."
          }
        },
        required: [
          "search_term",
          "contact_id",
          "birthday_query_type",
          "date_range_start",
          "date_range_end",
          "month"
        ], 
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "confirm_delete_contact",
      description: "Confirms or denies the deletion of a contact. Called after user is asked for confirmation.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          contact_id: { type: "string", description: "The UUID of the contact to be deleted." },
          contact_name: { type: "string", description: "The name of the contact, for confirmation context." },
          confirm: { type: "boolean", description: "Set to true if deletion is confirmed, false if denied." }
        },
        required: [
          "contact_id",
          "contact_name",
          "confirm"
        ],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "find_duplicate_contacts",
      description: "Find potential duplicate contacts that might represent the same person. Use when the user asks about finding or cleaning up duplicate contacts.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          threshold: {
            type: ["number", "null"],
            description: "Similarity threshold (0-1) for detecting duplicates. Default is 0.6."
          },
          include_archived: {
            type: ["boolean", "null"],
            description: "Whether to include archived contacts in the search. Default is false."
          },
          page: {
            type: ["number", "null"],
            description: "Page number for pagination (starting at 1). Default is 1.image.png"
          },
          limit: {
            type: ["number", "null"],
            description: "Maximum number of duplicate groups to return per page. Default is 10. Maximum allowed is 25."
          },
          sort_by: {
            type: ["string", "null"],
            description: "Field to sort results by. Options: 'confidence' (default), 'name', 'email'",
            enum: ["confidence", "name", "email", null]
          }
        },
        required: [
          "threshold",
          "include_archived",
          "page",
          "limit",
          "sort_by"
        ],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "find_contacts_with_improper_phone_formats",
      description: "Find contacts with improperly formatted phone numbers. Use this to identify contacts that need their phone numbers reformatted for consistency and better usability.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          include_empty: {
            type: ["boolean", "null"],
            description: "Whether to include contacts with missing or empty phone numbers. Default is false."
          },
          page: {
            type: ["number", "null"],
            description: "Page number for pagination (starting at 1). Default is 1."
          },
          limit: {
            type: ["number", "null"],
            description: "Maximum number of contacts to return per page. Default is 20. Maximum allowed is 50."
          }
        },
        required: [
          "include_empty",
          "page",
          "limit"
        ],
        additionalProperties: false
      }
    }
  }
];

// Export tools and executeSingleToolCall for use by other assistant functions
// Export the tools and functions needed by assistant-general.ts
export { handleCreateContact, handleUpdateContact };
export { tools as contactTools };
export { executeSingleToolCall };


async function executeSingleToolCall(
  toolCall: OpenAI.Chat.Completions.ChatCompletionMessageToolCall, 
  eventHeaders: HandlerEvent['headers'], 
  userId: string | null,
  contactSummaryThreshold: number,
  reqId?: string,
  currentUserEmail?: string | null // Added to accept current user's email
): Promise<OpenAI.Chat.Completions.ChatCompletionToolMessageParam> {
  const functionName = toolCall.function.name;
  let functionArgs: Record<string, unknown> = {}; // Initialize with a default value
  const toolCallId = toolCall.id;
  const currentReqId = reqId || `tool_exec_${toolCallId.substring(0,8)}_${Date.now()}`;
  const logPrefix = `[assistant-contacts.ts][ReqID:${currentReqId}][${functionName}]`; // Define logPrefix here for proper scope

  console.log(`${logPrefix} Executing tool: ${functionName}, Tool Call ID: ${toolCallId}`);

  // Extract email from JWT if not provided and we need it for specific tools
  if (!currentUserEmail && functionName === 'find_contacts') {
    try {
      const authHeader = eventHeaders.authorization || eventHeaders.Authorization;
      if (authHeader && typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        const tokenParts = token.split('.');
        if (tokenParts.length === 3) {
          const payload = JSON.parse(Buffer.from(tokenParts[1], 'base64').toString('utf-8'));
          currentUserEmail = payload.email || null;
          console.log(`${logPrefix} Extracted user email from token for tool execution: ${currentUserEmail || 'null'}`);
        }
      }
    } catch (error) {
      console.warn(`${logPrefix} Error extracting email from JWT:`, error);
      // Continue without the email rather than failing the request
    }
  }

  try {
    // Ensure toolCall.function.arguments is a string before parsing
    if (typeof toolCall.function.arguments === 'string') {
      functionArgs = JSON.parse(toolCall.function.arguments) as Record<string, unknown>;
    } else {
      // Handle cases where arguments might not be a string
      console.warn(`${logPrefix} Tool call arguments are not a string:`, toolCall.function.arguments);
      // Use empty args, or could throw an error depending on desired strictness
      functionArgs = {}; 
    }
    console.log(`${logPrefix} Parsed arguments for ${functionName}:`, functionArgs);
    
    // Check for placeholder contact_id in delete operations
    if (functionName === 'confirm_delete_contact' && 
        typeof functionArgs.contact_id === 'string' && // Check property exists and is string
        functionArgs.contact_id === 'contact_id_placeholder') {
      console.log(`${logPrefix} Found contact_id_placeholder in confirm_delete_contact, will need to fetch actual ID`);
    }
  } catch (e) {
    const errorMsg = e instanceof Error ? e.message : String(e);
    console.error(`${logPrefix} Error parsing arguments for ${functionName} (ID: ${toolCallId}): ${toolCall.function.arguments}`, e);
    return {
      tool_call_id: toolCallId,
      role: "tool" as const,
      content: JSON.stringify({ success: false, error: "ArgumentParsingError", message: `Failed to parse arguments for ${functionName}: ${errorMsg}` }),
    };
  }

  let toolResultContent = "";
  const internalApiBaseUrl = getInternalApiBaseUrl();
  const internalHeaders = getInternalHeaders(eventHeaders);

  // Type for generic API error objects parsed from response bodies
  interface ApiErrorResponseBody {
    message?: string;
    // Add other potential error properties if known
  }

  try {
    switch (functionName) {
      case "create_contact":
        {
          if (!isCreateContactToolArgs(functionArgs)) {
            toolResultContent = JSON.stringify({
              success: false,
              error: "InvalidArguments",
              message: "Invalid arguments provided for create_contact. Ensure first_name and last_name are present and all fields match the expected types."
            });
            break;
          }
          const typedArgs = functionArgs as CreateContactToolArgs; // Type guard ensures this is safe
          console.log(`${logPrefix} Calling handleCreateContact for tool: ${functionName}`);
          toolResultContent = await handleCreateContact(
            typedArgs,
            userId,
            internalApiBaseUrl,
            internalHeaders as HeadersInit,
            currentReqId
          );
        }
        break;

      case "update_contact":
        {
          if (!isUpdateContactToolArgs(functionArgs)) {
            toolResultContent = JSON.stringify({
              success: false,
              error: "InvalidArguments",
              message: "Invalid arguments for update_contact. contact_id (UUID) is required."
            });
            break;
          }
          const typedArgs = functionArgs as UpdateContactToolArgs; // Type guard ensures this is safe
          console.log(`${logPrefix} Calling handleUpdateContact for tool: ${functionName}`);
          toolResultContent = await handleUpdateContact(
            typedArgs,
            userId,
            internalApiBaseUrl,
            internalHeaders as HeadersInit,
            currentReqId
          );
        }
        break;

      case "find_contacts":
        {
          if (!isFindContactsToolArgs(functionArgs)) {
            toolResultContent = JSON.stringify({
              success: false,
              error: "InvalidArguments",
              message: "Invalid arguments for find_contacts. Review parameters."
            });
            break;
          }
          
          const typedArgs = functionArgs as FindContactsToolArgs;
          console.log(`${logPrefix} Executing find_contacts with args:`, typedArgs);
          
          // Interface for contacts that have had upcoming birthday info calculated
          interface ContactWithCalculatedBirthdayInfo extends Contact { // Extends the imported Contact
            birthDate: Date; // Parsed birthday
            diffDays: number; // Days until next birthday
            nextBirthday: Date; // Date of the next birthday
          }

          let response: FetchResponse;
          let responseBody: string;

          if (typedArgs.birthday_query_type) {
            console.log(`${logPrefix} Processing birthday query: ${typedArgs.birthday_query_type}`);
            if (!userId) {
              toolResultContent = JSON.stringify({ success: false, error: "AuthenticationError", message: "User ID is required for birthday queries." });
              break;
            }

            try {
              const today = new Date();
              today.setHours(0, 0, 0, 0);

              // Ensure the select query matches fields in the imported Contact type
              let query = supabaseAdmin.from('contacts')
                .select('contact_id, user_id, created_at, updated_at, first_name, middle_name, last_name, nickname, email, phone, company, job_title, address, website, birthday, notes, google_contact_id, import_source, import_batch_id, imported_at, normalized_phone, street_address, street_address_2, city, state_province, postal_code, country, department, mobile_phone, work_phone, social_linkedin, social_twitter, tags, preferred_contact_method, timezone, language, formatted_address')
                .eq('user_id', userId)
                .not('birthday', 'is', null);

              switch (typedArgs.birthday_query_type) {
                case 'upcoming': {
                  // Always use the full 90-day window from config for birthdays unless explicitly specified with both range parameters
                  const upcomingDays = (typedArgs.date_range_start && typedArgs.date_range_end && 
                                      typedArgs.date_range_start !== typedArgs.date_range_end) ? 
                                      (new Date(typedArgs.date_range_end).getTime() - new Date(typedArgs.date_range_start).getTime()) / (1000 * 3600 * 24) : 
                                      config.upcomingBirthdayDays; // Use configurable days window
                  
                  console.log(`${logPrefix} Using upcoming birthday window of ${upcomingDays} days (default from config: ${config.upcomingBirthdayDays})`)
                  const endDate = new Date(today);
                  endDate.setDate(today.getDate() + upcomingDays);

                  // SQL to handle month/day comparison, including year wrap-around
                  // This is a simplified version. A more robust solution might use database functions or more complex date arithmetic.
                  // It extracts month and day and compares them.
                  // This example focuses on direct DB query capabilities. For complex date logic, a stored procedure might be better.
                  // For simplicity, we'll filter in code after fetching if direct SQL is too complex for this context.
                  // However, a common approach is to check if TO_CHAR(birthday, 'MM-DD') is between TO_CHAR(startDate, 'MM-DD') and TO_CHAR(endDate, 'MM-DD')
                  // potentially with adjustments for year boundaries.
                  
                  // supabase-js doesn't directly support complex date part extraction and comparison in a way that easily handles year rollovers
                  // across a dynamic range like "next 7 days". We'll fetch contacts with birthdays and filter in JS.
                  // A more optimized query would be needed for very large datasets.
                  break;
                }
                case 'on_date':
                  if (typedArgs.date_range_start) {
                    const targetDate = new Date(typedArgs.date_range_start + 'T00:00:00'); // Ensure local time context if not UTC
                    const month = targetDate.getMonth() + 1; // JS months are 0-indexed
                    const day = targetDate.getDate();
                    query = query.filter('birthday', 'like', `%-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`);
                  } else {
                    throw new Error("date_range_start is required for 'on_date' birthday query.");
                  }
                  break;
                case 'in_month':
                  if (typedArgs.month) {
                    query = query.filter('birthday', 'like', `%-${String(typedArgs.month).padStart(2, '0')}-%`);
                  } else {
                    throw new Error("month is required for 'in_month' birthday query.");
                  }
                  break;
                case 'in_range':
                  if (typedArgs.date_range_start && typedArgs.date_range_end) {
                    // This also requires careful handling of MM-DD across year boundaries if only MM-DD is considered.
                    // If full YYYY-MM-DD is used, it's simpler. The tool implies YYYY-MM-DD for these.
                    query = query.gte('birthday', typedArgs.date_range_start).lte('birthday', typedArgs.date_range_end);
                  } else {
                    throw new Error("date_range_start and date_range_end are required for 'in_range' birthday query.");
                  }
                  break;
                default:
                  throw new Error(`Unsupported birthday_query_type: ${typedArgs.birthday_query_type}`);
              }

              const { data: contacts, error } = await query.returns<Contact[]>(); // Use imported Contact[]

              if (error) {
                console.error(`${logPrefix} Supabase error fetching birthdays:`, error);
                throw error;
              }
              
              let processedContacts: Array<Contact | ContactWithCalculatedBirthdayInfo> = contacts || [];

              if (typedArgs.birthday_query_type === 'upcoming') {
                // Always use the full 90-day window from config for birthdays unless explicitly specified with both range parameters
                const upcomingDays = (typedArgs.date_range_start && typedArgs.date_range_end && 
                                    typedArgs.date_range_start !== typedArgs.date_range_end) ? 
                                    (new Date(typedArgs.date_range_end).getTime() - new Date(typedArgs.date_range_start).getTime()) / (1000 * 3600 * 24) : 
                                    config.upcomingBirthdayDays;
                
                processedContacts = (contacts || [])
                  .map((c: Contact) => { // Use imported Contact
                    if (!c.birthday) return null;
                    const birthDate = new Date(c.birthday + 'T00:00:00');
                    return { ...c, birthDate };
                  })
                  .filter((c): c is Contact & { birthDate: Date } => c !== null) // Type predicate uses Contact
                  .map((c: Contact & { birthDate: Date }): ContactWithCalculatedBirthdayInfo => { // Returns new extended type
                    const birthDate = c.birthDate;
                    const nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
                    if (nextBirthday < today) {
                      nextBirthday.setFullYear(today.getFullYear() + 1);
                    }
                    const diffTime = nextBirthday.getTime() - today.getTime();
                    const diffDays = diffTime / (1000 * 3600 * 24);
                    return { ...c, diffDays, nextBirthday };
                  })
                  .filter((c: ContactWithCalculatedBirthdayInfo) => c.diffDays >= 0 && c.diffDays <= upcomingDays)
                  .sort((a: ContactWithCalculatedBirthdayInfo, b: ContactWithCalculatedBirthdayInfo) => a.diffDays - b.diffDays);
              } else if (contacts && contacts.length > 0) {
                 processedContacts = [...contacts].sort((a: Contact, b: Contact) => { // Use imported Contact
                    if (!a.birthday || !b.birthday) return 0;
                    const dateA = new Date(a.birthday + 'T00:00:00');
                    const dateB = new Date(b.birthday + 'T00:00:00');
                    if (dateA.getMonth() === dateB.getMonth()) {
                        return dateA.getDate() - dateB.getDate();
                    }
                    return dateA.getMonth() - dateB.getMonth();
                });
              }

              if (processedContacts.length === 0) {
                toolResultContent = JSON.stringify({ success: true, message: "No contacts found with matching birthdays for your criteria.", contacts: [] });
              } else {
                const displayContacts = processedContacts.map((c: Contact | ContactWithCalculatedBirthdayInfo) => { // Uses union type
                  // Use the imported generateDisplayName function
                  return {
                    ...c, // Spread all properties from the contact object
                    name: generateDisplayName(c), // Use the comprehensive display name function
                    days_until_birthday: typedArgs.birthday_query_type === 'upcoming' && (c as ContactWithCalculatedBirthdayInfo).diffDays !== undefined ? Math.round((c as ContactWithCalculatedBirthdayInfo).diffDays) : undefined
                  };
                });
                toolResultContent = JSON.stringify({
                  success: true,
                  message: `Found ${displayContacts.length} contact(s) with birthdays matching your criteria.`,
                  contacts: displayContacts
                });
              }

            } catch (e) {
              const errorMsg = e instanceof Error ? e.message : String(e);
              console.error(`${logPrefix} Error processing birthday query: ${errorMsg}`);
              toolResultContent = JSON.stringify({ success: false, error: "BirthdayQueryError", message: `Failed to process birthday query: ${errorMsg}` });
            }
            break; // Break from find_contacts case after handling birthday query
          }
          // --- END BIRTHDAY QUERY LOGIC ---

          // Existing logic for search_term or contact_id
          if (typedArgs.search_term && !typedArgs.contact_id) {
            const apiUrl = `${internalApiBaseUrl}/.netlify/functions/contacts-search`;
            const requestBody: { 
              query: string | null; 
              limit: number; 
              offset: number; 
              currentUserEmail?: string | null; // Add here
            } = {
              query: typedArgs.search_term,
              limit: 50,
              offset: 0,
              currentUserEmail: currentUserEmail // Pass it in the body to contacts-search
            };
            
            console.log(`${logPrefix} Using optimized search for term: "${typedArgs.search_term}", excluding user: ${currentUserEmail || 'N/A'}`);
            console.log(`${logPrefix} Making API call to: ${apiUrl} with method: POST`);
            const requestStartTime = Date.now();
            response = await fetch(apiUrl as RequestInfo, {
              method: 'POST',
              headers: {
                ...internalHeaders,
                'Content-Type': 'application/json'
              } as HeadersInit,
              body: JSON.stringify(requestBody)
            } as RequestInit);
            const requestEndTime = Date.now();
            console.log(`${logPrefix} API call to ${apiUrl} completed in ${requestEndTime - requestStartTime}ms with status: ${response.status}`);
            responseBody = await response.text();
            
            if (response.ok) {
              // Parse the optimized search response format
              // Define a type for the expected search response structure
              // MOVED to _shared/types.ts: interface OptimizedSearchResponse {...}
              // Now using ContactSearchApiResponse from _shared/types
              const searchResponse = JSON.parse(responseBody) as ContactSearchApiResponse;
              const { contacts: searchResults, total } = searchResponse;
              
              if (searchResults.length === 0) {
                const noResultsMessage = typedArgs.search_term
                  ? `No exact contacts found matching your search for "${typedArgs.search_term}".`
                  : "No contacts were found.";
                toolResultContent = JSON.stringify({ 
                  success: true, 
                  message: noResultsMessage, 
                  contacts: [],
                  summary: { // Include summary structure even for no results for consistency
                    totalFound: 0,
                    displaying: 0,
                    searchPerformed: typedArgs.search_term || "all_contacts"
                  }
                });
              } else if (searchResults.length > contactSummaryThreshold && searchResults.length < total) {
                // This case implies we have exact matches (searchResults) but also other related matches (total > searchResults.length)
                // And the exact matches exceed the summary threshold.
                const summaryMessage = typedArgs.search_term
                  ? `Found ${searchResults.length} exact contact(s) matching "${typedArgs.search_term}". Displaying the first ${contactSummaryThreshold}. (Total related: ${total})`
                  : `Found ${searchResults.length} exact contact(s). Displaying the first ${contactSummaryThreshold}. (Total related: ${total})`;
                toolResultContent = JSON.stringify({
                  success: true,
                  message: summaryMessage,
                  contacts: searchResults.slice(0, contactSummaryThreshold),
                  summary: {
                    totalExactFound: searchResults.length,
                    totalRelatedFound: total,
                    displaying: contactSummaryThreshold,
                    searchPerformed: typedArgs.search_term
                  }
                });
              } else if (searchResults.length <= contactSummaryThreshold && searchResults.length < total) {
                // Exact matches found, within threshold, but more related contacts exist.
                const foundMessage = typedArgs.search_term
                  ? `Found ${searchResults.length} exact contact(s) matching "${typedArgs.search_term}". (Total related: ${total})`
                  : `Found ${searchResults.length} exact contact(s). (Total related: ${total})`;
                toolResultContent = JSON.stringify({ 
                  success: true, 
                  message: foundMessage,
                  contacts: searchResults,
                  summary: {
                    totalExactFound: searchResults.length,
                    totalRelatedFound: total,
                    displaying: searchResults.length,
                    searchPerformed: typedArgs.search_term
                  }
                });
              } else { 
                // This 'else' covers:
                // 1. searchResults.length === total (all found are exact)
                // 2. searchResults.length > contactSummaryThreshold AND searchResults.length === total (all found are exact, but exceeds threshold)
                // 3. searchResults.length <= contactSummaryThreshold AND searchResults.length === total (all found are exact, within threshold)
                // Effectively, searchResults contains all "relevant" contacts, and there are no "other related" ones beyond these.
                // Given the preceding `if (searchResults.length === 0)` check, searchResults.length > 0 here.
                
                let message: string;
                // typedArgs.search_term is guaranteed to be a non-empty string here because of the
                // `if (typedArgs.search_term && !typedArgs.contact_id)` condition for this optimized path.
                if (searchResults.length === 1) {
                    message = `Here is the contact found matching "${typedArgs.search_term}":`;
                } else { // searchResults.length > 1
                    message = `Found ${searchResults.length} exact contacts matching "${typedArgs.search_term}".`;
                }

                toolResultContent = JSON.stringify({
                  success: true,
                  message: message,
                  contacts: searchResults,
                  summary: {
                    totalExactFound: searchResults.length,
                    totalRelatedFound: total, // In this branch, total is expected to be equal to searchResults.length
                    displaying: searchResults.length, // FAST_PATH will handle actual display count based on threshold
                    searchPerformed: typedArgs.search_term
                  }
                });
              }
            }
          } else {
            // Use the regular contacts-api for specific ID or listing all
            let apiUrl = `${internalApiBaseUrl}/.netlify/functions/contacts-api`;
            const queryParams = new URLSearchParams();

            if (typedArgs.contact_id && isValidUUID(typedArgs.contact_id)) {
              apiUrl += `/${typedArgs.contact_id}`; // API expects ID in path
              console.log(`${logPrefix} Finding contact by specific ID: ${typedArgs.contact_id}`);
            } else {
              console.log(`${logPrefix} No specific ID or search term provided, listing all contacts.`);
            }
            
            const queryString = queryParams.toString();
            if (queryString) {
              apiUrl += `?${queryString}`;
            }

            console.log(`${logPrefix} Calling internal contacts-api (GET) at: ${apiUrl}`);
            const getRequestStartTime = Date.now();
            response = await fetch(apiUrl as RequestInfo, {
              method: 'GET',
              headers: internalHeaders as HeadersInit,
            } as RequestInit);
            const getRequestEndTime = Date.now();
            console.log(`${logPrefix} GET request to ${apiUrl} completed in ${getRequestEndTime - getRequestStartTime}ms with status: ${response.status}`);
            responseBody = await response.text();

            if (!response.ok) {
              console.error(`${logPrefix} Error from internal contacts-api call: ${response.status} ${response.statusText}`, responseBody);
              let errorDetail: ApiErrorResponseBody = { message: `API error: ${response.statusText}` };
              try {
                const parsedError = JSON.parse(responseBody);
                if (parsedError && typeof parsedError.message === 'string') {
                  errorDetail = parsedError as ApiErrorResponseBody;
                }
              } catch (parseError) {
                console.error(`${logPrefix} Failed to parse error response:`, parseError);
              }
              toolResultContent = JSON.stringify({
                success: false,
                error: `APIError_${response.status}`,
                message: errorDetail.message || `Failed to find contacts. API responded with ${response.status}.`,
                details: responseBody
              });
            } else {
              // Expecting an array of contacts or a single contact object
              // It's safer to parse and then check the type if it can be ambiguous
              const parsedData = JSON.parse(responseBody);
              let contacts: (CreateContactToolArgs & { id: string })[] | (CreateContactToolArgs & { id: string });

              // Basic check, can be improved with more robust type guards if structure is complex
              if (Array.isArray(parsedData)) {
                contacts = parsedData as (CreateContactToolArgs & { id: string })[];
              } else if (typeof parsedData === 'object' && parsedData !== null) {
                contacts = parsedData as (CreateContactToolArgs & { id: string });
              } else {
                // Should not happen if API behaves, but good to handle
                console.error(`${logPrefix} Unexpected data format from contacts-api:`, parsedData);
                contacts = []; 
              }

              const contactsLog = Array.isArray(contacts) && contacts.length > contactSummaryThreshold ? `${contacts.length} contacts (summary)` : contacts;
              console.log(`${logPrefix} Successfully found contacts:`, contactsLog);
              if (Array.isArray(contacts) && contacts.length === 0) {
                toolResultContent = JSON.stringify({ 
                  success: true, 
                  message: "No contacts found.", 
                  contacts: [] 
                });
              } else if (Array.isArray(contacts) && contacts.length > contactSummaryThreshold) {
                toolResultContent = JSON.stringify({
                  success: true,
                  message: `Found ${contacts.length} contacts. Displaying the first ${contactSummaryThreshold} as a summary.`,
                  contacts: contacts.slice(0, contactSummaryThreshold),
                  summary: {
                    totalFound: contacts.length,
                    displaying: contactSummaryThreshold
                  }
                });
              } else {
                // If contacts is not an array, or length <= THRESHOLD, or it's a single object (contact by ID)
                toolResultContent = JSON.stringify({ success: true, contacts });
              }
            }
          }
        }
        break;

      case "confirm_delete_contact": // This tool is called by the LLM to signal user's confirmation
        {
          if (!isConfirmDeleteContactToolArgs(functionArgs)) {
            toolResultContent = JSON.stringify({
              success: false,
              error: "InvalidArguments",
              message: "Invalid arguments for confirm_delete_contact. contact_id, contact_name, and confirm boolean are required."
            });
            break;
          }
          
          const typedArgs = functionArgs; // Now type-safe
          console.log(`${logPrefix} Executing confirm_delete_contact with args:`, typedArgs);

          // If the user didn't confirm, handle early
          if (typedArgs.confirm !== true) {
            console.log(`${logPrefix} User did not confirm deletion`);
            toolResultContent = JSON.stringify({
              success: false,
              message: "Contact was not deleted because you did not confirm the action."
            });
            break;
          }

          // User confirmed, proceed with deletion
          console.log(`${logPrefix} User confirmed deletion, proceeding...`);

          // Create the appropriate contact identifier based on the input
          let contactIdentifier: ContactIdentifier;
          const isPlaceholder = typedArgs.contact_id === 'contact_id_placeholder';
          const isValidId = !isPlaceholder && isValidUUID(typedArgs.contact_id);

          if (isPlaceholder || !isValidId) {
            // Use name-based resolution if ID is a placeholder or invalid
            contactIdentifier = { 
              type: 'name', 
              name: typedArgs.contact_name 
            };
            console.log(`${logPrefix} Using name-based identifier for '${typedArgs.contact_name}'`);
          } else {
            // Otherwise use the valid UUID
            contactIdentifier = { 
              type: 'id', 
              contact_id: typedArgs.contact_id 
            };
            console.log(`${logPrefix} Using UUID-based identifier: ${typedArgs.contact_id}`);
          }

          // Use the contact service to delete the contact
          try {
            // Ensure userId is string (not null) before proceeding
            if (!userId) {
              throw new Error('User ID is required for contact deletion');
            }

            // Use our contactService to handle the deletion
            const deleteResult = await contactService.deleteContact(userId, contactIdentifier);
            
            if (!deleteResult.success) {
              // Handle deletion failure
              console.error(`${logPrefix} Contact deletion failed:`, deleteResult.error);
              toolResultContent = JSON.stringify({
                success: false,
                error: deleteResult.error?.code || "DELETION_FAILED",
                message: deleteResult.error?.message || `Failed to delete contact ${typedArgs.contact_name}.`
              });
              break;
            }
            
            // Deletion successful
            console.log(`${logPrefix} Contact deleted successfully:`, deleteResult.data);
            
            // Formulate success message using the data from service
            const contactName = deleteResult.data?.name || typedArgs.contact_name;
            toolResultContent = JSON.stringify({
              success: true,
              message: `Contact "${contactName}" has been deleted successfully.`,
              contact_id: deleteResult.data?.contact_id
            });
          } catch (error) {
            // Handle unexpected errors
            console.error(`${logPrefix} Unexpected error during contact deletion:`, error);
            toolResultContent = JSON.stringify({
              success: false,
              error: "UNEXPECTED_ERROR",
              message: `An unexpected error occurred while trying to delete the contact: ${error instanceof Error ? error.message : 'Unknown error'}`
            });
          }
        }
        break;

      case "find_duplicate_contacts":
        {
          console.log(`${logPrefix} ENTERING find_duplicate_contacts case - EXECUTION CHECKPOINT 1`);
          const typedArgs = functionArgs as FindDuplicateContactsToolArgs;
          console.log(`${logPrefix} Executing find_duplicate_contacts with args:`, JSON.stringify(typedArgs));
          
          // Parse all parameters with appropriate defaults
          const providedThreshold = typedArgs.threshold !== undefined && typedArgs.threshold !== null 
            ? typedArgs.threshold 
            : 0.6;
          const providedIncludeArchived = typedArgs.include_archived !== undefined && typedArgs.include_archived !== null 
            ? typedArgs.include_archived 
            : false;
          const providedPage = typedArgs.page !== undefined && typedArgs.page !== null && typedArgs.page > 0
            ? typedArgs.page
            : 1;
          const providedLimit = typedArgs.limit !== undefined && typedArgs.limit !== null && typedArgs.limit > 0
            ? Math.min(typedArgs.limit, 25) // Cap at 25 to prevent timeouts
            : 10;
          const providedSortBy = typedArgs.sort_by !== undefined && typedArgs.sort_by !== null
            ? typedArgs.sort_by as 'confidence' | 'name' | 'email'
            : 'confidence';
          
          console.log(`${logPrefix} Parsed parameters: threshold=${providedThreshold}, includeArchived=${providedIncludeArchived}, page=${providedPage}, limit=${providedLimit}, sortBy=${providedSortBy}`);
          
          if (!userId) {
            console.error(`${logPrefix} User ID is required for finding duplicate contacts`);
            toolResultContent = JSON.stringify({
              success: false,
              error: "MissingUserId",
              message: "User ID is required for finding duplicate contacts."
            });
            break;
          }
          
          console.log(`${logPrefix} CHECKPOINT 2: About to call contactService.findDuplicateContacts`);
          try {
            // Create options with explicit type
            const options: {
              threshold?: number;
              includeArchived?: boolean;
              page?: number;
              limit?: number;
              sortBy?: 'confidence' | 'name' | 'email';
            } = {
              threshold: providedThreshold,
              includeArchived: providedIncludeArchived,
              page: providedPage,
              limit: providedLimit,
              sortBy: providedSortBy
            };
            
            console.log(`${logPrefix} Calling contactService.findDuplicateContacts with userId=${userId}, options=`, JSON.stringify(options));
            
            const result = await contactService.findDuplicateContacts(userId, options);
            console.log(`${logPrefix} CHECKPOINT 3: findDuplicateContacts returned result with success=${result.success}`);
            
            if (!result.success || !result.data) {
              console.error(`${logPrefix} Error finding duplicate contacts:`, 
                result.error ? JSON.stringify(result.error) : 'No error details');
              toolResultContent = JSON.stringify({
                success: false,
                error: result.error?.code || "FIND_DUPLICATES_FAILED",
                message: result.error?.message || "Failed to find duplicate contacts."
              });
              break;
            }
            
            // Safely access the paginated data
            const { groups, pagination } = result.data;
            
            console.log(`${logPrefix} CHECKPOINT 4: Processing successful result with ${groups.length} items on page ${pagination.currentPage} of ${pagination.totalPages}`);
            
            if (groups.length === 0 && pagination.totalGroups === 0) {
              console.log(`${logPrefix} No duplicate contacts found`);
              toolResultContent = JSON.stringify({
                success: true,
                message: "No duplicate contacts found in your contact list.",
                duplicate_groups: [],
                pagination: {
                  current_page: pagination.currentPage,
                  total_pages: pagination.totalPages,
                  total_groups: pagination.totalGroups,
                  limit: pagination.limit,
                  has_more: pagination.hasMore
                }
              });
              break;
            }
            
            console.log(`${logPrefix} Found ${pagination.totalGroups} total groups, showing ${groups.length} on this page`);
            console.log(`${logPrefix} CHECKPOINT 5: Formatting response for assistant`);
            
            // Format the response for the assistant
            const duplicateGroups = groups.map(group => ({
              contact: {
                id: group.contact.contact_id,
                name: `${group.contact.first_name || ''} ${group.contact.last_name || ''}`.trim() || 'Unknown',
                email: group.contact.email || 'No email',
                phone: group.contact.phone || 'No phone'
              },
              duplicates: group.duplicates.map(dup => ({
                id: dup.contact.contact_id,
                name: `${dup.contact.first_name || ''} ${dup.contact.last_name || ''}`.trim() || 'Unknown',
                email: dup.contact.email || 'No email',
                phone: dup.contact.phone || 'No phone',
                confidence: parseFloat(dup.confidence.toFixed(2)),
                match_reasons: dup.matchReason.join(', ')
              }))
            }));
            
            // Count total duplicates across all groups on this page
            const totalDuplicatesOnPage = groups.reduce((sum, group) => sum + group.duplicates.length, 0);
            
            console.log(`${logPrefix} CHECKPOINT 6: Preparing JSON response`);
            
            // Create message text based on pagination context
            let message: string;
            if (pagination.totalPages > 1) {
              if (pagination.currentPage === 1) {
                message = `Found ${pagination.totalGroups} groups of potential duplicate contacts. Showing page ${pagination.currentPage} of ${pagination.totalPages}. Use the same command with page=2 to see more.`;
              } else if (pagination.currentPage < pagination.totalPages) {
                message = `Showing page ${pagination.currentPage} of ${pagination.totalPages} of duplicate contacts. ${pagination.totalGroups} total groups found.`;
              } else {
                message = `Showing the final page (${pagination.currentPage} of ${pagination.totalPages}) of duplicate contacts. ${pagination.totalGroups} total groups found.`;
              }
            } else {
              message = `Found ${pagination.totalGroups} group${pagination.totalGroups === 1 ? '' : 's'} of potential duplicate contacts.`;
            }
            
            toolResultContent = JSON.stringify({
              success: true,
              message,
              duplicate_groups: duplicateGroups,
              total_groups: pagination.totalGroups,
              total_duplicates: totalDuplicatesOnPage,
              pagination: {
                current_page: pagination.currentPage,
                total_pages: pagination.totalPages,
                limit: pagination.limit,
                has_more: pagination.hasMore
              }
            });
            console.log(`${logPrefix} CHECKPOINT 7: JSON response prepared successfully`);
          } catch (error) {
            console.error(`${logPrefix} Unexpected error finding duplicates:`, 
              error instanceof Error ? `${error.name}: ${error.message}\n${error.stack || 'No stack trace'}` : error);
            toolResultContent = JSON.stringify({
              success: false,
              error: "UNEXPECTED_ERROR",
              message: `An unexpected error occurred while finding duplicate contacts: ${error instanceof Error ? error.message : 'Unknown error'}`
            });
          }
        }
        break;
        
      case "find_contacts_with_improper_phone_formats":
        {
          console.log(`${logPrefix} Executing find_contacts_with_improper_phone_formats`);
          const typedArgs = functionArgs as FindContactsWithImproperPhoneFormatsToolArgs;
          console.log(`${logPrefix} Executing find_contacts_with_improper_phone_formats with args:`, JSON.stringify(typedArgs));
          
          if (!userId) {
            console.error(`${logPrefix} User ID is required for finding contacts with improper phone formats`);
            toolResultContent = JSON.stringify({
              success: false,
              error: "MissingUserId",
              message: "User ID is required for finding contacts with improper phone formats."
            });
            break;
          }
          
          try {
            // Parse parameters with appropriate defaults
            const options = {
              includeEmpty: typedArgs.include_empty ?? false,
              page: typedArgs.page ? Math.max(1, typedArgs.page) : 1,
              limit: typedArgs.limit ? Math.min(Math.max(1, typedArgs.limit), 50) : 20
            };
            
            console.log(`${logPrefix} Calling contactService.findContactsWithImproperPhoneFormats with options:`, options);
            
            const result = await contactService.findContactsWithImproperPhoneFormats(userId, options);
            
            if (!result.success || !result.data) {
              console.error(`${logPrefix} Error finding contacts with improper phone formats:`, 
                result.error ? JSON.stringify(result.error) : 'No error details');
              toolResultContent = JSON.stringify({
                success: false,
                error: result.error?.code || "FIND_IMPROPER_FORMATS_FAILED",
                message: result.error?.message || "Failed to find contacts with improper phone formats."
              });
              break;
            }
            
            const { contacts, pagination } = result.data;
            
            if (contacts.length === 0) {
              console.log(`${logPrefix} No contacts with improper phone formats found`);
              toolResultContent = JSON.stringify({
                success: true,
                message: "No contacts with improper phone formats found in your database.",
                contacts: [],
                pagination: {
                  current_page: pagination.currentPage,
                  total_pages: pagination.totalPages,
                  total_contacts: pagination.totalContacts,
                  limit: pagination.limit,
                  has_more: pagination.hasMore
                }
              });
              break;
            }
            
            console.log(`${logPrefix} Found ${pagination.totalContacts} contacts with improper phone formats`);
            
            // Format contacts for display
            const formattedContacts = contacts.map(contact => ({
              contact_id: contact.contact_id,
              name: `${contact.first_name || ''} ${contact.last_name || ''}`.trim() || 'Unknown',
              email: contact.email || 'No email',
              phone: contact.phone || 'No phone number',
              company: contact.company || 'No company',
              format_issue: contact.formatIssue,
              suggested_format: contact.suggestedFormat || 'No suggestion available'
            }));
            
            // Create page navigation message
            let pageNavMessage = '';
            if (pagination.totalPages > 1) {
              if (pagination.currentPage < pagination.totalPages) {
                pageNavMessage = ` Use the same command with page=${pagination.currentPage + 1} to see more.`;
              }
            }
            
            // Recommendations for fixing phone numbers
            const recommendations = `
Recommended phone number formats:
- US/Canada: +1 (123) 456-7890 or (123) 456-7890
- International: +[country code] [area code] [local number]
- Avoid letters and special characters (except +, -, (), spaces)
`;
            
            toolResultContent = JSON.stringify({
              success: true,
              message: `Found ${pagination.totalContacts} contacts with improper phone formats. Showing page ${pagination.currentPage} of ${pagination.totalPages}.${pageNavMessage}`,
              contacts: formattedContacts,
              pagination: {
                current_page: pagination.currentPage,
                total_pages: pagination.totalPages,
                total_contacts: pagination.totalContacts,
                limit: pagination.limit,
                has_more: pagination.hasMore
              },
              recommendations
            });
          } catch (error) {
            console.error(`${logPrefix} Unexpected error finding contacts with improper phone formats:`, 
              error instanceof Error ? `${error.name}: ${error.message}\n${error.stack || 'No stack trace'}` : error);
            toolResultContent = JSON.stringify({
              success: false,
              error: "UNEXPECTED_ERROR",
              message: `An unexpected error occurred while finding contacts with improper phone formats: ${error instanceof Error ? error.message : 'Unknown error'}`
            });
          }
        }
        break;

      default:
        console.warn(`${logPrefix} Unknown tool function: ${functionName}`);
        toolResultContent = JSON.stringify({ success: false, error: "UnknownTool", message: `Unknown tool function: ${functionName}` });
    }
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "An unknown error occurred processing the request.";
    // Removed unused errorStack variable
    console.error(`${logPrefix} Error executing tool ${functionName} (ID: ${toolCallId}):`, error);
    toolResultContent = JSON.stringify({ 
        success: false, 
        error: "ToolExecutionError", 
        message: `Failed to execute tool ${functionName}: ${errorMsg}` 
    });
  }

  console.log(`${logPrefix} Tool result for ${functionName} (ID: ${toolCallId}):`, toolResultContent.substring(0, 200) + (toolResultContent.length > 200 ? "..." : ""));

  return {
    tool_call_id: toolCallId,
    role: "tool" as const,
    content: toolResultContent,
  };
}

// The main handler for the Netlify Function
export const handler: Handler = async (event: HandlerEvent, context: HandlerContext): Promise<HandlerResponse> => {
  const reqId = context.awsRequestId || `local-${Date.now()}`; // For logging
  const logPrefix = `[assistant-contacts.ts][ReqID:${reqId}]`;

  console.log(`${logPrefix} Function invoked ---`);
  console.log(`${logPrefix} HTTP Method: ${event.httpMethod}`);
  console.log(`${logPrefix} Path: ${event.path}`);
  
  // Enhanced logging for Netlify troubleshooting
  console.log(`${logPrefix} NETLIFY_LOGS_DEBUG: Function execution started`);
  console.log(`${logPrefix} NETLIFY_ENV: ${process.env.NETLIFY || 'not set'}`);
  console.log(`${logPrefix} NODE_ENV: ${process.env.NODE_ENV || 'not set'}`);
  
  const safeHeaders: Record<string, string | undefined> = {};
  for (const key in event.headers) {
    if (key.toLowerCase() === 'authorization') {
      safeHeaders[key] = 'Bearer ***';
    } else if (key.toLowerCase() === 'cookie') {
       safeHeaders[key] = '***';
    } else {
      safeHeaders[key] = event.headers[key];
    }
  }
  console.log(`${logPrefix} Headers (partial): ${JSON.stringify(safeHeaders)}`);
  console.log(`${logPrefix} Function version: ${new Date().toISOString()}`); // Add version timestamp for deployment tracking

  if (event.httpMethod !== 'POST') {
    console.warn(`${logPrefix} Method Not Allowed: ${event.httpMethod}`);
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method Not Allowed' }),
      headers: { 'Content-Type': 'application/json', 'Allow': 'POST' },
    };
  }

  const userId = getUserIdFromEvent(event, 'assistant-contacts.ts');
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: 'Authentication required. User ID could not be determined.' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }

  // Extract the user's email from the JWT token
  let userEmail: string | null = null;
  try {
    const authHeader = event.headers.authorization || event.headers.Authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const tokenParts = token.split('.');
      if (tokenParts.length === 3) {
        const payload = JSON.parse(Buffer.from(tokenParts[1], 'base64').toString('utf-8'));
        userEmail = payload.email || null;
        console.log(`${logPrefix} Extracted user email from token: ${userEmail ? userEmail : 'null'}`);
      }
    }
  } catch (error) {
    console.warn(`${logPrefix} Error extracting email from JWT:`, error);
    // Continue without the email rather than failing the request
  }

  let requestBody: AssistantRequestBody;
  try {
    if (!event.body) {
      console.warn(`${logPrefix} Request body is missing.`);
      throw new Error("Request body is missing.");
    }
    requestBody = JSON.parse(event.body);
    // Add the extracted email to the request body if not already present
    if (!requestBody.currentUserEmail && userEmail) {
      requestBody.currentUserEmail = userEmail;
    }
    console.log(`${logPrefix} Parsed requestBody (structure):`, { 
      hasMessages: !!requestBody.messages, 
      messageCount: requestBody.messages?.length,
      hasToolCall: !!requestBody.tool_call,
      toolCallName: requestBody.tool_call?.function?.name,
      hasToolResponse: !!requestBody.tool_response,
      toolResponseId: requestBody.tool_response?.tool_call_id,
      hasCurrentUserEmail: typeof requestBody.currentUserEmail !== 'undefined' // Log if email is present
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error parsing request body.";
    console.error(`${logPrefix} Failed to parse request body: ${errorMessage}. Body received (first 200 chars): ${event.body ? event.body.substring(0,200) : 'N/A'}`);
    return {
      statusCode: 400,
      body: JSON.stringify({ message: `Invalid request body: ${errorMessage}` }),
      headers: { 'Content-Type': 'application/json' },
    };
  }

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const config = getAssistantConfig(); // Get assistant configuration

  try {
    if (requestBody.tool_call && requestBody.tool_call.id && requestBody.tool_call.function) {
      console.log(`${logPrefix} Received direct tool call for execution: ${requestBody.tool_call.function.name}`);
      const openAIToolCall: OpenAI.Chat.Completions.ChatCompletionMessageToolCall = {
        id: requestBody.tool_call.id,
        type: 'function',
        function: {
          name: requestBody.tool_call.function.name,
          arguments: requestBody.tool_call.function.arguments
        }
      };
      // Pass config.contactSummaryThreshold for direct tool calls as well, if it's find_contacts
      const threshold = requestBody.tool_call.function.name === 'find_contacts' ? config.contactSummaryThreshold : 0; // 0 or a sensible default if not find_contacts
      
      // Pass currentUserEmail to executeSingleToolCall if available in requestBody
      const toolResult = await executeSingleToolCall(
        openAIToolCall, 
        event.headers, 
        userId, 
        threshold, 
        reqId,
        requestBody.currentUserEmail // This is string | null | undefined
      );
      const contentPreview = typeof toolResult.content === 'string' 
        ? toolResult.content.substring(0, 100) + '...'
        : 'Content is not a string';
      console.log(`${logPrefix} Direct tool call executed. Result content: ${contentPreview}`);
      return {
        statusCode: 200,
        body: JSON.stringify(toolResult),
        headers: { 'Content-Type': 'application/json' },
      };
    } 
    else if (requestBody.tool_response && requestBody.tool_response.tool_call_id) {
        if (!requestBody.messages || requestBody.messages.length === 0) {
            console.error(`${logPrefix} Tool response provided without prior messages array.`);
            return { 
                statusCode: 400, 
                body: JSON.stringify({ message: "Tool response must be accompanied by the conversation history (messages)."}),
                headers: { 'Content-Type': 'application/json' }
            };
        }
        console.log(`${logPrefix} Received tool response for tool_call_id: ${requestBody.tool_response.tool_call_id}. Appending to conversation.`);
        const toolResponseMessage: GenericChatMessage = {
            role: 'tool',
            tool_call_id: requestBody.tool_response.tool_call_id,
            content: typeof requestBody.tool_response.output === 'string' 
                       ? requestBody.tool_response.output 
                       : JSON.stringify(requestBody.tool_response.output),
        };
        requestBody.messages.push(toolResponseMessage);
    }
    
    if (!requestBody.messages || requestBody.messages.length === 0) {
      console.warn(`${logPrefix} No messages provided for OpenAI API call and not a direct tool call/response.`);
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'No messages provided for conversation.' }),
        headers: { 'Content-Type': 'application/json' },
      };
    }

    if (!validateMessages(requestBody.messages)) {
        console.error(`${logPrefix} Invalid messages structure in requestBody.`);
        try {
            console.error("Problematic messages array (stringified):", JSON.stringify(requestBody.messages, null, 2).substring(0, 1000));
        } catch {
            console.error("Problematic messages array could not be stringified.");
        }         
          return {
            statusCode: 400, 
            body: JSON.stringify({ message: "Invalid message structure. Please check roles, content, and tool call formats." }),
            headers: { 'Content-Type': 'application/json' }
        };
    } 
    
    const toolCallMap = new Map<string, number>();
    requestBody.messages.forEach((m, index) => {
      if (m.role === 'assistant' && m.tool_calls && m.tool_calls.length > 0) {
        m.tool_calls.forEach(tc => {
          if (tc.id) {
            toolCallMap.set(tc.id, index);
          }
        });
      }
    });

    const validMessages = requestBody.messages
      .filter(m => {
        if (m.role !== 'tool') return true;
        return m.tool_call_id && toolCallMap.has(m.tool_call_id);
      });

    console.log(`${logPrefix} Original message count: ${requestBody.messages.length}`);
    console.log(`${logPrefix} Valid message count: ${validMessages.length}`);
    console.log(`${logPrefix} Tool call map size: ${toolCallMap.size}`);
    console.log(`${logPrefix} Message roles sequence: ${validMessages.map(m => m.role).join(', ')}`);

    const processedMessagesForOpenAI = validMessages.map(msg => {
      if (msg.role === 'tool' && msg.tool_call_id) {
        const assistantMessageIndex = toolCallMap.get(msg.tool_call_id);
        if (assistantMessageIndex !== undefined) {
          const originalAssistantMessage = requestBody.messages?.[assistantMessageIndex];
          if (originalAssistantMessage && originalAssistantMessage.role === 'assistant' && originalAssistantMessage.tool_calls) {
            const originalToolCall = originalAssistantMessage.tool_calls.find(tc => tc.id === msg.tool_call_id);
            if (originalToolCall && originalToolCall.function && originalToolCall.function.name === 'find_contacts') {
              try {
                const contactsData = JSON.parse(msg.content || '{}'); 
                type FoundContact = Partial<ContactData>;
                if (contactsData && Array.isArray(contactsData.contacts) && contactsData.contacts.length > config.contactSummaryThreshold) {
                  const summaryDetails = {
                    totalFound: contactsData.summary?.totalFound || contactsData.contacts.length,
                    displaying: contactsData.summary?.displaying || config.contactSummaryThreshold,
                    contacts: contactsData.contacts.slice(0, config.contactSummaryThreshold).map((c: FoundContact, index: number) => ({
                      contact_id: c.id,
                      name: `${c.first_name || ''} ${c.last_name || ''}`.trim() || c.email || c.company || `Contact ${index + 1}`,
                      email: c.email,
                      company: c.company,
                      ref_id_for_ai_display: index + 1 
                    }))
                  };
                  console.log(`${logPrefix} Summarizing find_contacts tool output for OpenAI.`);
                  let searchTermForDisplay = "your query";
                  try {
                    if (originalToolCall.function.arguments) {
                      const toolArgs = JSON.parse(originalToolCall.function.arguments);
                      if (toolArgs.search_term) {
                        searchTermForDisplay = `for "${toolArgs.search_term}"`;
                      } else if (toolArgs.contact_id) {
                        searchTermForDisplay = `for contact ID "${toolArgs.contact_id}"`;
                      }
                    }
                  } catch (e) {
                    console.warn(`${logPrefix} Could not parse arguments from find_contacts for summary: ${e instanceof Error ? e.message : String(e)}`);
                  }
                  const summaryMessage = `Found ${summaryDetails.totalFound} contacts related to your search ${searchTermForDisplay}. Displaying summary of the first ${summaryDetails.displaying}. IMPORTANT: For any operations like deletion or update, you MUST use the 'contact_id' (which is the UUID provided in the 'contact_id' field for each contact in this summary), not the 'ref_id_for_ai_display'.`;
                  return { ...msg, content: JSON.stringify({ success: true, message: summaryMessage, summary: summaryDetails }) };
                }
              } catch (e) {
                console.error(`${logPrefix} Failed to parse or process find_contacts tool content: ${e instanceof Error ? e.message : String(e)}. Using original content for OpenAI.`);
              }
            }
          }
        }
      }
      return msg;
    });

    const openAIMessages = processedMessagesForOpenAI.map(m => ({
        role: m.role as 'user' | 'assistant' | 'system' | 'tool',
        content: m.content === null ? '' : m.content,
        ...(m.tool_calls && { tool_calls: m.tool_calls }),
        ...(m.tool_call_id && { tool_call_id: m.tool_call_id }),
        ...(m.name && { name: m.name })
    })) as OpenAI.Chat.Completions.ChatCompletionMessageParam[];

    console.log(`${logPrefix} Making API call to OpenAI with model: ${process.env.OPENAI_MODEL || 'gpt-4o-mini'}`);
    console.log(`${logPrefix} Sending ${openAIMessages.length + 1} messages to OpenAI (including system prompt).`);
    
    const systemPromptText = `You are Elber, an AI assistant specializing in contact management. **You MUST follow ALL instructions in this prompt with absolute strictness and precision. Failure to do so is a critical error.**
Current date: ${new Date().toISOString()}

CRITICAL INSTRUCTION FOR TOOL USE:
When a list of contacts is presented to you (e.g., from a 'find_contacts' operation), each contact will have a 'contact_id' (a UUID string like "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx") and potentially a 'ref_id_for_ai_display' (a simple number like 1, 2, 3).
For ANY operation that requires identifying a specific contact (e.g., updating, deleting via 'confirm_delete_contact'), you MUST use the actual 'contact_id' (the UUID string).
The 'ref_id_for_ai_display' is ONLY for your textual reference when discussing contacts with the user (e.g., "Contact 1 is John Doe").
NEVER use the 'ref_id_for_ai_display' as the 'contact_id' argument in any tool call. Always use the UUID.

**Under NO circumstances are you to display internal UUIDs (such as 'contact_id', 'user_id', 'event_id', etc.) in your responses to the user.** These identifiers are for internal tool use ONLY and are confidential. When discussing a list of items (e.g., contacts) that you have presented with numerical references (like "1. Contact Name", "2. Other Contact"), you may use those numerical references (e.g., "item 1", "the first contact listed") in your conversation. However, the underlying UUIDs MUST NEVER be revealed to the user. Always refer to items by their user-understandable attributes like name, title, etc.

ABSOLUTE RULE: DATABASE-ONLY INFORMATION
You are STRICTLY FORBIDDEN from providing ANY information that is not explicitly found in the user's contacts database.

When handling information queries:
1. You MUST use the find_contacts tool to search the database for the requested information
2. You may ONLY return information that is directly retrieved from the database
3. If the information is NOT found in the database, you MUST respond clearly:
   - For company role queries (e.g., "Who is the CEO of Rexa?"): "I found some contacts at [Company] but none with that specific role. Would you like to see the contacts I found or add this information to your database?"
   - For person queries: "I don't have that contact in your database. Would you like me to help you add them?"
   - For general information: "I don't have that information in your contacts database. Would you like me to help you add it?"
4. You MUST NEVER generate, invent, or provide any information beyond what is explicitly returned by the find_contacts tool
5. Even if you believe you know the answer, you MUST pretend you don't if it's not in the database
6. For company role queries, if you find contacts associated with the company but not with the specific role, you should clearly indicate this

This is a zero-tolerance rule with no exceptions. Violating this rule would constitute a critical system failure.

IMPORTANT FORMATTING REQUIREMENTS
You MUST format ALL responses using proper Markdown formatting. Your responses will be rendered as markdown in the frontend, so this is CRITICAL for readability:
- Use **bold text** for important information like contact names, email addresses, and phone numbers.
- Use headings (## and ###) to organize sections of your response, especially when presenting contact details.
- Present contact details in a structured list or table when appropriate.
- Use bullet points or numbered lists for steps or multiple items (e.g., listing multiple contacts found).
- Use \`code formatting\` for technical values. Avoid displaying internal IDs (like \`contact_id\`) to the user; use names or other user-friendly identifiers instead for display purposes. Internal IDs are for tool use only.
- Use > blockquotes for important notes, warnings, or when asking for confirmation.

EVERY response you provide MUST follow these markdown formatting guidelines. If you don't use markdown properly, your responses will be difficult to read and understand.
**This applies to all responses, without exception, including very short messages, questions, or simple clarifications.** For example, if you need more information to find a contact, instead of "What is the name?", you should respond with Markdown, like: "Could you please provide the **name** or **email address** you're looking for?"

Core Capabilities:
- Create new contacts. **First Name** and **Last Name** are mandatory. Proactively attempt to gather all other relevant details (email, phone, company, notes, etc.) in your *first interaction* using a comprehensive list. This prevents unnecessary follow-up questions.
- Find existing contacts (by any name field, nickname, email, phone, company, job title, address, website, or specific contact_id).
- Update existing contacts. You *must* first identify the contact and get their \`contact_id\` (usually via \`find_contacts\`). Then, to update, provide this \`contact_id\` and *only* the fields that need to be changed.
- Delete contacts (always requires user confirmation specifying contact_id and name for internal tool use, but only confirm by name to the user).

Contact Fields:
- **Basic Information**: first_name (required), middle_name, last_name (required), nickname, birthday (in MM-DD-YYYY format)
- **Contact Information**: email, phone, address, website
- **Professional Information**: company, job_title
- **Additional Information**: notes

Clarification for Vague Queries:
- If a user's request to find a contact is vague or lacks specific identifiers (e.g., "find my friend", "show me that person I met last week"), you MUST ask for clarifying details BEFORE calling the \`find_contacts\` tool.
- Examples of clarifying questions:
    - "To help me find the right contact, could you please provide their **name**, **email**, **company**, or any other specific details you remember?"
    - "I need a bit more information to search for that contact. What is their **name** or **company**?"
- Do NOT attempt to guess or use the \`find_contacts\` tool with overly broad or empty search terms based on vague requests. Prioritize getting more specific information from the user.

Birthday Search Specifics for 'find_contacts':
- When a user asks for "upcoming birthdays" generally (e.g., "who has a birthday soon?", "any upcoming birthdays?"), you should use \`birthday_query_type: "upcoming"\`.
- For such general "upcoming" queries, **DO NOT** provide \`date_range_start\` or \`date_range_end\`. The system will use a default upcoming window (e.g., the next ${config.upcomingBirthdayDays} days, as configured).
- Only use \`date_range_start\` and \`date_range_end\` with \`birthday_query_type: "upcoming"\` if the user *explicitly specifies a narrower timeframe* (e.g., "upcoming birthdays in the next two weeks", "birthdays between next Monday and Friday"). In this case, calculate the dates based on the current date and the user's request.
- For \`birthday_query_type: "on_date"\`, \`date_range_start\` should be the specific date (YYYY-MM-DD).
- For \`birthday_query_type: "in_month"\`, \`month\` should be the month number (1-12).
- For \`birthday_query_type: "in_range"\`, both \`date_range_start\` and \`date_range_end\` (YYYY-MM-DD) are required.

Confirmation Flow for Deletion:
1. If the user asks to delete a contact, first use 'find_contacts' to locate the exact contact and get its ID and name. (The ID is for your internal use with tools).
2. If one or more contacts are found, present the options to the user by name if ambiguous (e.g., "I found John Doe and Jane Doe. Which one do you mean?"), or state the full name of the contact you intend to delete (e.g., "I found John Doe, is this the contact you'd like to delete?"). Do not state the Contact ID to the user.
3. Ask the user for explicit confirmation by name (e.g., "Are you sure you want to delete John Doe?").
4. If the user confirms (e.g., "Yes", "Confirm", "Do it"), then call the 'confirm_delete_contact' tool with 'confirm: true', the 'contact_id' (which you retrieved in step 1), and 'contact_name'.
5. If the user denies (e.g., "No", "Cancel"), then call 'confirm_delete_contact' with 'confirm: false', along with the 'contact_id' and 'contact_name'.
6. If the user's response is ambiguous, ask for clarification.

Tool Usage Guidelines:
- When finding contacts:
    - If the user provides sufficient details (e.g., full name, email, specific company), proceed with the \`find_contacts\` tool.
    - If the query is vague (see "Clarification for Vague Queries"), ask for more specific information BEFORE using the tool.
    - If multiple matches are found, list them clearly using Markdown (e.g., by name and other distinguishing details, but not ID).
    - If a unique ID is available from a previous step or user input, use that with find_contacts internally.
- For creating/updating, ensure all provided data seems reasonable. Email should look like an email.
- When calling 'confirm_delete_contact', you MUST provide the 'contact_id', the 'contact_name' (as presented to the user for confirmation by name), and the boolean 'confirm' status.

Error Handling by Tools:
- If a tool call results in an error (e.g., contact not found, validation error), this will be returned in the 'content' of the tool's response message. Inform the user clearly about the issue, using Markdown to highlight key error details if appropriate, without revealing internal IDs.
- Do not retry a failed tool call unless the error suggests a temporary issue or you have new information from the user.

Interaction Style:
- Be concise and clear.
- When action is taken (create, update, delete), confirm this back to the user (e.g., "Okay, I've deleted John Doe.").
- If you need more information, ask specific questions.
- When asking for contact details for creation, ALWAYS include **First Name** and **Last Name** as the first items, clearly marked as required. Then, list other common optional fields (email, phone, company, notes etc.) and ask the user to provide any they have.
- You MUST format your contact field request for creation like this:
\`\`\`
Please provide me with the following details for the new contact:

- **First Name** (required)
- **Last Name** (required) 
- Email
- Phone
- Company
- Notes
- (and any other details like middle name, nickname, job title, address, website, birthday)
\`\`\`
- Do not perform actions with side effects (create, update, delete) without the user explicitly asking for it or confirming it. If a user says "jay poe is now at new company inc", this is a statement, not a request to update. Ask "Would you like me to update Jay Poe's company to New Company Inc?".
- When searching, if a search term like "Poe" yields "Jay Poe" and "Edgar Allan Poe", present both using Markdown lists (by name and other relevant details, not ID) and ask which one the user means before proceeding with actions like update/delete.
- For updates, if the user provides partial information (e.g., "update Jay's email to new@example.com"), find "Jay", confirm if it's the correct "Jay" (e.g. "I found Jay Poe, is that who you mean?"), then call 'update_contact' with only the email field (and the internal contact_id).
- DO NOT invent contact_ids. They are UUIDs and come from the 'find_contacts' tool or previous interactions and are for your internal use only.
- Strive to use the exact contact_name (first and last if available) when confirming actions like deletion with the user.

**Precision in Responding to Specific Queries:**
- If the user asks for a specific named contact (e.g., "Find a specific contact by name", "Show me a specific contact's details"), you MUST prioritize returning ONLY contacts that EXACTLY match the requested name.
- If the underlying search tool (\`find_contacts\`) returns contacts with similar but not identical names (e.g., user asks for "Contact A" and the tool finds "Contact A" and "Contact AB"), you should:
    1. First, present ONLY the exact match(es) for "Contact A".
    2. THEN, you may optionally ask if the user is interested in other similar contacts found, like "Contact AB". For example: "I found Contact A. I also found Contact AB, are you interested in that contact as well?"
- Do NOT proactively display details for contacts that are merely *related* to the specific name requested unless the user explicitly asks for broader results or confirms interest in the related contacts. Your primary goal is to answer the user's specific query first and foremost.
- If the \`find_contacts\` tool returns multiple exact matches for the requested name (e.g., two different contacts both named "Contact A"), you should present all exact matches and ask the user for clarification if an action needs to be taken on a single specific contact.`;
    const systemPrompt: OpenAI.Chat.Completions.ChatCompletionSystemMessageParam = {
      role: "system",
      content: systemPromptText
    };

    const response = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [systemPrompt, ...openAIMessages],
      tools: tools,
      tool_choice: "auto",
    });

    const responseMessage = response.choices[0].message;
    console.log(`${logPrefix} OpenAI response received. Finish reason: ${response.choices[0].finish_reason}`);
    console.log(`${logPrefix} OpenAI model used: ${response.model}, completion_tokens: ${response.usage?.completion_tokens || 'unknown'}, prompt_tokens: ${response.usage?.prompt_tokens || 'unknown'}`);

    if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0) {
      console.log(`${logPrefix} OpenAI response includes ${responseMessage.tool_calls.length} tool call(s).`);
      console.log(`${logPrefix} Tool calls: ${JSON.stringify(responseMessage.tool_calls)}`);

      if (responseMessage.tool_calls.length === 1 && responseMessage.tool_calls[0].function.name === 'find_contacts') {
        const toolCall = responseMessage.tool_calls[0];
        console.log(`${logPrefix} Attempting FAST PATH for single find_contacts tool call ID: ${toolCall.id}`);
        try {
          const toolExecutionResult = await executeSingleToolCall(
            toolCall, 
            event.headers, 
            userId, 
            config.contactSummaryThreshold, 
            reqId,
            requestBody.currentUserEmail || userEmail // Use email from requestBody or extracted from JWT
          );
          const toolOutput = JSON.parse((toolExecutionResult.content as string) ?? 'null'); 

          if (toolOutput && toolOutput.success && typeof toolOutput.contacts !== 'undefined') {
            const returnedContactsFromTool: Contact | Contact[] = toolOutput.contacts;
            let finalAssistantMessage = '';
            let searchTermForDisplay = "your query";
            try {
                const toolArgs = JSON.parse(toolCall.function.arguments || '{}');
                if (toolArgs.search_term) {
                    searchTermForDisplay = `for "${toolArgs.search_term}"`;
                } else if (toolArgs.contact_id) {
                    searchTermForDisplay = `for contact ID "${toolArgs.contact_id}"`;
                }
            } catch (e) {
                console.warn(`${logPrefix} Could not parse arguments from find_contacts for fast path summary: ${e instanceof Error ? e.message : String(e)}`);
            }

            if (toolOutput.message) {
                finalAssistantMessage = toolOutput.message;
            } else {
                if (Array.isArray(returnedContactsFromTool)) {
                    if (returnedContactsFromTool.length === 0) {
                        finalAssistantMessage = `I couldn't find any contacts matching ${searchTermForDisplay}.`;
                    }
                } else if (typeof returnedContactsFromTool === 'object' && returnedContactsFromTool !== null) {
                    finalAssistantMessage = `Here is the contact I found matching ${searchTermForDisplay}:`;
                } else {
                    finalAssistantMessage = `I processed your request regarding ${searchTermForDisplay}, but there are no specific contacts to display.`;
                }
            }

            const contactsArrayToFormat: Contact[] = Array.isArray(returnedContactsFromTool) 
                ? returnedContactsFromTool 
                : (typeof returnedContactsFromTool === 'object' && returnedContactsFromTool !== null ? [returnedContactsFromTool] : []);

            if (contactsArrayToFormat.length > 0) {
                const formattedContactList = FastContactFormatter.formatContactsForDisplay(contactsArrayToFormat, searchTermForDisplay);
                if (finalAssistantMessage && !finalAssistantMessage.endsWith('\n\n') && finalAssistantMessage.length > 0) {
                    finalAssistantMessage += "\n\n";
                }
                finalAssistantMessage += formattedContactList;
            } else if (!toolOutput.message && Array.isArray(returnedContactsFromTool) && returnedContactsFromTool.length === 0) {
                 finalAssistantMessage = `I couldn't find any exact contacts matching ${searchTermForDisplay}.`;
            }

            // Append question about other related contacts if they exist
            if (toolOutput.summary && 
                typeof toolOutput.summary.totalExactFound === 'number' &&
                typeof toolOutput.summary.totalRelatedFound === 'number' &&
                toolOutput.summary.totalRelatedFound > toolOutput.summary.totalExactFound &&
                contactsArrayToFormat.length > 0) { // Only ask if we actually showed some exact matches

                const otherCount = toolOutput.summary.totalRelatedFound - toolOutput.summary.totalExactFound;
                if (finalAssistantMessage && !finalAssistantMessage.endsWith('\n\n') && !finalAssistantMessage.endsWith('\n')) {
                    finalAssistantMessage += "\n\n";
                } else if (finalAssistantMessage && !finalAssistantMessage.endsWith('\n\n') && finalAssistantMessage.endsWith('\n')) {
                    finalAssistantMessage += "\n";
                }
                finalAssistantMessage += `I also found ${otherCount} other contact(s) related to your search. Would you like to see them?`;
            }

            const formattedContent = finalAssistantMessage.trim();

            if (formattedContent) {
                 console.log(`${logPrefix} FAST PATH successful. Sending formatted response directly.`);
                 return {
                    statusCode: 200,
                    body: JSON.stringify({ role: 'assistant', content: formattedContent }),
                    headers: { 'Content-Type': 'application/json' },
                };
            } 
            console.warn(`${logPrefix} FAST PATH: formattedContent was empty. Falling back.`);
          } else {
            console.warn(`${logPrefix} FAST PATH: Tool execution for find_contacts failed, no contacts, or toolOutput was null. Message: ${toolOutput?.message}. Falling back.`);
          }
        } catch (fastPathError) {
          console.error(`${logPrefix} Error during FAST PATH execution: ${fastPathError instanceof Error ? fastPathError.message : String(fastPathError)}. Falling back.`);
        }
      }
      
      console.log(`${logPrefix} Standard path: OpenAI response includes tool_calls. Returning to client.`);
      return {
        statusCode: 200,
        body: JSON.stringify(responseMessage),
        headers: { 'Content-Type': 'application/json' },
      };

    } else {
      console.log(`${logPrefix} Standard path: OpenAI response is a direct message. Returning to client.`);
      return {
        statusCode: 200,
        body: JSON.stringify(responseMessage),
        headers: { 'Content-Type': 'application/json' },
      };
    }

  } catch (error: unknown) {
    const errorMsg = error instanceof Error ? error.message : "An unknown error occurred processing the request.";
    const errorStack = error instanceof Error ? error.stack : undefined; // Keep this since it's used in the error log
    console.error(`${logPrefix} Error in handler: ${errorMsg}`, errorStack);
    if (error instanceof OpenAI.APIError) {
        console.error(`${logPrefix} OpenAI API Error: status=${error.status}, type=${error.type}, code=${error.code}, param=${error.param}`);
        return {
            statusCode: error.status || 500,
            body: JSON.stringify({ 
                message: `OpenAI API Error: ${error.message}`,
                type: error.type,
                code: error.code
            }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "An internal server error occurred.", details: errorMsg }),
      headers: { 'Content-Type': 'application/json' },
    };
  } finally {
    // Log function completion regardless of success or failure
    console.log(`${logPrefix} ==== Function execution completed ====`);
  }
};
import { Handler, HandlerEvent, HandlerContext, HandlerResponse } from "@netlify/functions";
import { getUserIdFromEvent } from './_shared/utils';
import { supabaseAdmin } from '../services/supabaseAdmin';
import type { Contact } from '../types/domain';
import {
  ContactSearchParams,
  ContactSearchResponse,
  SearchMatchType,
  determineMatchType
} from '../types/search';

// For backward compatibility
type SearchRequest = ContactSearchParams; // This will now correctly refer to the augmented type
// type SearchResponse = ContactSearchResponse;
// type OptimizedSearchResult = RankedContact;

// Add forceRefresh to the ContactSearchParams type via module augmentation
declare module '../types/search' {
  interface ContactSearchParams {
    forceRefresh?: boolean;
    currentUserEmail?: string | null; // Added to filter out the current user
  }
}

// Type for contacts returned by the fallback search, including a calculated match_score
interface FallbackRankedContact extends Contact {
  match_score: number | null; 
}

// Simple in-memory cache with TTL
interface CacheEntry {
  data: Contact[];
  timestamp: number;
  total: number;
}

const searchCache = new Map<string, CacheEntry>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

// Add a CORS headers constant near other constants
const COMMON_HEADERS = {
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store, max-age=0',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, apikey, x-client-info'
};

function getCacheKey(userId: string, query: string, limit: number, offset: number): string {
  return `${userId}:${query}:${limit}:${offset}`;
}

function isValidCache(entry: CacheEntry | undefined): boolean {
  if (!entry) return false;
  return Date.now() - entry.timestamp < CACHE_TTL;
}

// Add a timeout constant
const QUERY_TIMEOUT_MS = 10000; // 10 seconds

// Add a helper function to create a timeout promise
function createTimeoutPromise(timeoutMs: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => {
      reject(new Error(`Operation timed out after ${timeoutMs}ms`));
    }, timeoutMs);
  });
}

// Modify the main search logic to include timeouts
async function _searchContacts( // This function is kept for future use
  userId: string,
  query: string,
  limit: number,
  offset: number,
  logPrefix: string
): Promise<{ data: Contact[]; total: number }> {
  console.log(`${logPrefix} Executing search with query: "${query}" for user ${userId}, limit: ${limit}, offset: ${offset}`);
  
  // Add a timeout to prevent hanging queries
  const timeoutPromise = new Promise<never>((_, reject) => {
    setTimeout(() => {
      reject(new Error(`Search query timeout after ${QUERY_TIMEOUT_MS}ms`));
    }, QUERY_TIMEOUT_MS);
  });
  
  try {
    // Create a promise for the actual query
    const queryPromise = supabaseAdmin.rpc('search_contacts_optimized', {
      p_user_id: userId,
      p_query: query,
      p_limit: limit,
      p_offset: offset
    }).then(async (response) => {
      if (response.error) {
        console.error(`${logPrefix} Database error:`, response.error);
        throw new Error(`Database error: ${response.error.message}`);
      }
      
      const { data: contacts } = response;
      console.log(`${logPrefix} Search found ${contacts?.length || 0} contacts`);
      
      // Get total count with a separate query
      const { count: totalCount, error: countError } = await supabaseAdmin
        .from('contacts')
        .select('contact_id', { count: 'exact', head: true })
        .eq('user_id', userId);
        
      if (countError) {
        console.warn(`${logPrefix} Error getting total count:`, countError);
        // Don't fail the whole query for a count error
      }
      
      return {
        data: contacts || [],
        total: totalCount || (contacts?.length || 0) + offset // Fallback estimate if count fails
      };
    });
    
    // Race the query against the timeout
    return await Promise.race([queryPromise, timeoutPromise]);
  } catch (error) {
    console.error(`${logPrefix} Search error:`, error);
    // Include more context in the thrown error
    throw new Error(`Search failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export const handler: Handler = async (event: HandlerEvent, context: HandlerContext): Promise<HandlerResponse> => {
  const reqId = context.awsRequestId || `local-${Date.now()}`;
  const logPrefix = `[contacts-search.ts][ReqID:${reqId}]`;
  
  console.log(`${logPrefix} Function invoked`);
  console.log(`${logPrefix} HTTP Method: ${event.httpMethod}`);
  
  // Handle CORS preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: COMMON_HEADERS,
      body: ''
    };
  }
  
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method Not Allowed' }),
      headers: { ...COMMON_HEADERS, 'Allow': 'POST, OPTIONS' },
    };
  }
  
  // Authenticate the user
  const userId = getUserIdFromEvent(event, 'contacts-search');
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: 'Authentication required' }),
      headers: COMMON_HEADERS,
    };
  }
  
  try {
    // Parse request body
    const body: SearchRequest = JSON.parse(event.body || '{}'); // SearchRequest refers to ContactSearchParams
    const query = body.query || '';
    const limit = Math.min(body.limit || 50, 100); // Cap at 100
    const offset = body.offset || 0;
    const forceRefresh = body.forceRefresh || false;
    const currentUserEmail = body.currentUserEmail || null; // Extract currentUserEmail
    
    console.log(`${logPrefix} Search params: query="${query}", limit=${limit}, offset=${offset}, forceRefresh=${forceRefresh}, currentUserEmail=${currentUserEmail || 'N/A'}`);
    
    // Check cache first, unless forceRefresh is true or currentUserEmail is present (to avoid caching user-specific filtered results incorrectly)
    const cacheKey = getCacheKey(userId, query, limit, offset); // Cache key should NOT include currentUserEmail if results are filtered post-cache
    const cachedEntry = searchCache.get(cacheKey);
    
    if (!forceRefresh && !currentUserEmail && isValidCache(cachedEntry)) { // Only use cache if not filtering by currentUserEmail
      console.log(`${logPrefix} Cache hit for query: "${query}"`);
      const cacheData = cachedEntry as CacheEntry; 
      return {
        statusCode: 200,
        body: JSON.stringify({
          contacts: cacheData.data,
          total: cacheData.total,
          hasMore: offset + limit < cacheData.total,
          cached: true
        } as ContactSearchResponse),
        headers: COMMON_HEADERS,
      };
    }
    
    console.log(`${logPrefix} Cache ${forceRefresh ? 'bypassed' : (currentUserEmail ? 'bypassed (has currentUserEmail)' : 'miss')}, searching database for: "${query}"`);
    
    // Set up a timeout for the entire operation
    const timeoutPromise = createTimeoutPromise(QUERY_TIMEOUT_MS);
    
    // Create the main operation promise
    const operationPromise = (async (): Promise<HandlerResponse> => {
      // Type for the result of search_contacts_optimized RPC
      type OptimizedSearchResult = Contact & { match_score?: number }; 

      const { data: rpcResults, error: searchError } = await supabaseAdmin
        .rpc('search_contacts_optimized', {
          p_user_id: userId,
          p_query: query,
          p_limit: limit,
          p_offset: offset
        });
      
      let searchResults: OptimizedSearchResult[] = rpcResults || [];

      // Filter out current user if email is provided (for RPC results)
      if (currentUserEmail && searchResults.length > 0) {
        searchResults = searchResults.filter(contact => contact.email?.toLowerCase() !== currentUserEmail.toLowerCase());
      }

      if (searchError) {
        console.error(`${logPrefix} Search error from RPC:`, searchError);
        
        // Fallback to basic search if the function doesn't exist
        if (searchError.message.includes('function') && searchError.message.includes('does not exist')) {
          console.log(`${logPrefix} Optimized search function not found, using basic search`);
          
          let basicQuery = supabaseAdmin
            .from('contacts')
            .select('*', { count: 'exact' }); // Fetch plain Contact data
          
          basicQuery = basicQuery.eq('user_id', userId); // Apply filters on the typed query builder

          if (currentUserEmail) {
            basicQuery = basicQuery.not('email', 'ilike', currentUserEmail);
          }

          if (query.trim()) {
            basicQuery = basicQuery.or(`first_name.ilike.%${query}%,last_name.ilike.%${query}%,email.ilike.%${query}%,company.ilike.%${query}%,phone.ilike.%${query}%`);
          }
          
          const queryResponse = await basicQuery
            .order('updated_at', { ascending: false })
            .range(offset, offset + limit - 1);

          const basicContactsData = queryResponse.data as Contact[] | null; // Assert type after fetching
          const basicError = queryResponse.error;
          const _count = queryResponse.count; // Unused but could be needed for future enhancements

          const contactsForRanking: Contact[] = basicContactsData || [];
          let rankedFallbackContacts: FallbackRankedContact[] = [];
          
          if (contactsForRanking.length > 0 && query.trim()) {
            rankedFallbackContacts = contactsForRanking.map((contact: Contact) => {
              const fullName = `${contact.first_name || ''} ${contact.last_name || ''}`.trim().toLowerCase();
              const queryLower = query.toLowerCase();
              let score = 0.1;
              if (fullName.includes(queryLower)) score = 0.8;
              else if (contact.email && contact.email.toLowerCase().includes(queryLower)) score = 0.6;
              else if (contact.phone && contact.phone.includes(queryLower)) score = 0.5;
              
              return { ...contact, match_score: score }; 
            });
            
            rankedFallbackContacts.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0));
          } else if (contactsForRanking.length > 0) {
            // If no query, assign a default score or keep as null, sort by updated_at (already done)
            rankedFallbackContacts = contactsForRanking.map(contact => ({...contact, match_score: null }));
          }
          
          if (basicError) {
            console.error(`${logPrefix} Basic search error:`, basicError);
            return {
              statusCode: 500,
              body: JSON.stringify({ message: 'Search failed', error: basicError.message }),
              headers: COMMON_HEADERS,
            };
          }
          
          // Cache the results (with our manual sorting by similarity applied)
          // Ensure that if currentUserEmail was used for filtering, these filtered results are not cached under the general key
          if (!currentUserEmail) {
            searchCache.set(cacheKey, {
              data: rankedFallbackContacts.map(({match_score: _ms, ...contactFields}) => contactFields as Contact), // Cache plain Contacts
              timestamp: Date.now(),
              total: _count || 0
            });
          }
          
          return {
            statusCode: 200,
            body: JSON.stringify({
              contacts: rankedFallbackContacts.map(({match_score: _ms, ...contactFields}) => contactFields as Contact), // Return plain Contacts
              total: _count || 0,
              hasMore: offset + limit < (_count || 0),
              cached: false
            } as ContactSearchResponse),
            headers: COMMON_HEADERS,
          };
        }
        
        return {
          statusCode: 500,
          body: JSON.stringify({ message: 'Search failed', error: searchError.message }),
          headers: COMMON_HEADERS,
        };
      }
      
      // Transform the results and apply enhanced sorting logic
      const rankedContacts: OptimizedSearchResult[] = searchResults; // searchResults already filtered if currentUserEmail was present
      
      // Apply sorting and additional ranking based on match type
      if (rankedContacts.length > 0 && query.trim()) {
        // Log original ranking from database
        console.log(`${logPrefix} Original database ranking:`);
        rankedContacts.slice(0, Math.min(3, rankedContacts.length)).forEach((contact, idx) => {
          console.log(`${logPrefix} [${idx+1}] ${contact.first_name} ${contact.last_name || ''} (score: ${contact.match_score ?? 'N/A'})`);
        });
        
        // Analyze match types for each contact
        const contactsWithMatchTypes = rankedContacts.map(contact => {
          const matchType = determineMatchType(contact, query);
          return { contact, matchType };
        });
        
        // Exact name matches should always come first
        const exactFullNameMatches = contactsWithMatchTypes
          .filter(item => item.matchType === SearchMatchType.EXACT_FULL_NAME)
          .map(item => item.contact);
          
        const exactFirstNameMatches = contactsWithMatchTypes
          .filter(item => item.matchType === SearchMatchType.EXACT_FIRST_NAME)
          .map(item => item.contact);
          
        const exactLastNameMatches = contactsWithMatchTypes
          .filter(item => item.matchType === SearchMatchType.EXACT_LAST_NAME)
          .map(item => item.contact);
          
        const partialNameMatches = contactsWithMatchTypes
          .filter(item => item.matchType === SearchMatchType.PARTIAL_NAME)
          .map(item => item.contact);
          
        const otherMatches = contactsWithMatchTypes
          .filter(item => [
            SearchMatchType.CONTACT_INFO,
            SearchMatchType.COMPANY_INFO,
            SearchMatchType.GENERAL_INFO,
            SearchMatchType.NO_MATCH
          ].includes(item.matchType))
          .map(item => item.contact);
        
        // Prioritize exact matches in final results
        if (exactFullNameMatches.length > 0) {
          console.log(`${logPrefix} Found ${exactFullNameMatches.length} exact full name matches`);
          // Prioritize exact full name matches but still respect match_score within this group
          exactFullNameMatches.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0));
        }
        
        // Create the final ordered list, starting with exact matches
        const orderedRankedContacts = [
          ...exactFullNameMatches,
          ...exactFirstNameMatches.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0)),
          ...exactLastNameMatches.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0)),
          ...partialNameMatches.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0)),
          ...otherMatches.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0))
        ];
        
        // MODIFICATION: If exact full name matches are found, return ONLY those for the primary 'contacts' list.
        // The 'total' can still reflect the broader search if needed for UI context.
        if (exactFullNameMatches.length > 0) {
          console.log(`${logPrefix} Prioritizing ${exactFullNameMatches.length} exact full name match(es) in the returned contact list.`);
          rankedContacts.length = 0;
          rankedContacts.push(...exactFullNameMatches);
        } else {
          // If no exact full name matches, use the broader ordered list
          rankedContacts.length = 0;
          rankedContacts.push(...orderedRankedContacts);
        }
      } else {
        // Still sort by match_score for empty queries
        rankedContacts.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0));
      }
      
      // Log total number of contacts found
      console.log(`${logPrefix} Total contacts found: ${rankedContacts.length}`);
      
      // Log the final ordering after our enhanced sorting
      if (rankedContacts.length > 0) {
        console.log(`${logPrefix} Final ordering after enhanced sorting:`);
        rankedContacts.slice(0, Math.min(3, rankedContacts.length)).forEach((contact, idx) => {
          console.log(`${logPrefix} [${idx+1}] ${contact.first_name} ${contact.last_name || ''} (score: ${contact.match_score ?? 'N/A'})`);
        });
      }
      
      // Extract the contacts for the response (without the match_score for the standard API)
      const contacts: Contact[] = rankedContacts.map(({ match_score: _ignoredScore, ...contactFields }) => contactFields as Contact);
      
      // Get total count for pagination (this count should reflect pre-filtered results for consistency if possible or be clearly documented)
      // For simplicity here, this count might not reflect the currentUserEmail filter if the main query was RPC.
      // A more accurate total would require another query or the RPC to return total before filtering.
      const countQuery = supabaseAdmin
        .from('contacts')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId);
      
      // This or-clause for count is broad and may not perfectly match the RPC's logic or the fallback's filtered logic.
      // Ideally, the count should come from the primary search method (RPC or fallback's count).
      if (query.trim()) {
        countQuery.or(`first_name.ilike.%${query}%,last_name.ilike.%${query}%,email.ilike.%${query}%,company.ilike.%${query}%,phone.ilike.%${query}%`);
      }
      
      const { count: totalCountFromQuery } = await countQuery;
      const finalTotal = totalCountFromQuery || rankedContacts.length; // Fallback if count query fails

      // Cache successful results with the properly sorted contacts
      // Ensure that if currentUserEmail was used for filtering, these filtered results are not cached under the general key
      if (!currentUserEmail) {
        searchCache.set(cacheKey, {
          data: rankedContacts.map(({ match_score: _ignoredScore, ...contactFields }) => contactFields as Contact), // Cache plain Contacts
          timestamp: Date.now(),
          total: finalTotal
        });
      }
      
      // Clean up old cache entries periodically
      if (Math.random() < 0.1) { // 10% chance to clean up
        const now = Date.now();
        for (const [key, entry] of searchCache.entries()) {
          if (now - entry.timestamp > CACHE_TTL) {
            searchCache.delete(key);
          }
        }
      }
      
      // Log the first contact to help debug ordering issues
      if (contacts.length > 0) {
        console.log(`${logPrefix} Returning first contact: ${contacts[0].first_name} ${contacts[0].last_name || ''}`);
        if (contacts.length > 1) {
          console.log(`${logPrefix} Second contact: ${contacts[1].first_name} ${contacts[1].last_name || ''}`);
        }
      }
      
      return {
        statusCode: 200,
        body: JSON.stringify({
          contacts: contacts, // This is now (Contact & {match_score?: number})[] stripped of match_score by the map
          total: finalTotal, 
          hasMore: offset + limit < finalTotal,
          cached: false
        } as ContactSearchResponse),
        headers: COMMON_HEADERS,
      };
    })();
    
    // Race the operation against the timeout
    return await Promise.race([operationPromise, timeoutPromise]);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error(`${logPrefix} Error in handler:`, error);
    
    return {
      statusCode: error instanceof Error && error.message.includes('timed out') ? 408 : 500,
      body: JSON.stringify({ 
        message: error instanceof Error && error.message.includes('timed out') ? 
          'Search request timed out. Try a more specific search term.' : 
          'Internal server error', 
        error: errorMessage 
      }),
      headers: COMMON_HEADERS,
    };
  }
};
import type { Contact } from '../types/domain';

/**
 * Filters out erroneous "Google" named contacts that were created during import
 * These contacts typically have first_name="Google", empty last_name, and import_source="google"
 */
export const filterImportedGoogleContacts = (contacts: Contact[], logPrefix: string): Contact[] => {
  if (!contacts) return [];
  
  const originalCount = contacts.length;
  const filtered = contacts.filter(contact => {
    const isErroneousGoogleContact = 
      contact.first_name === 'Google' && 
      (contact.last_name === null || contact.last_name === '') && 
      contact.import_source === 'google';
    
    if (isErroneousGoogleContact) {
      console.log(`${logPrefix} Filtering out erroneous 'Google' contact: ID ${contact.contact_id}`);
    }
    
    return !isErroneousGoogleContact;
  });
  
  if (originalCount > filtered.length) {
    console.log(`${logPrefix} Filtered out ${originalCount - filtered.length} 'Google' named contacts due to import error.`);
  }
  
  return filtered;
};

/**
 * Additional contact quality filters can be added here
 * This provides a centralized location for all contact data quality operations
 */

/**
 * Apply all quality filters to a contact array
 * This is the main function that should be used throughout the application
 */
export const applyContactQualityFilters = (contacts: Contact[], logPrefix: string): Contact[] => {
  let filteredContacts = contacts;
  
  // Apply Google contact filter
  filteredContacts = filterImportedGoogleContacts(filteredContacts, logPrefix);
  
  // Future filters can be added here
  // filteredContacts = filterOtherIssues(filteredContacts, logPrefix);
  
  return filteredContacts;
}; 
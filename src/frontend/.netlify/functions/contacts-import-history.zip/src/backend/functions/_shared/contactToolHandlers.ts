import fetch from 'node-fetch';
import type { Response as FetchResponse, RequestInit, HeadersInit, RequestInfo } from 'node-fetch';
import type { CreateContactToolArgs, UpdateContactToolArgs } from './types'; // Assuming types are in _shared/types.ts
// isValidUUID is imported in types.ts and already validated in the type guards

// Type for generic API error objects parsed from response bodies
interface ApiErrorResponseBody {
  message?: string;
  // Add other potential error properties if known
}

/**
 * Handles the 'create_contact' tool call.
 * @param args - The parsed arguments for the create_contact tool.
 * @param userId - The ID of the user performing the action.
 * @param internalApiBaseUrl - The base URL for internal API calls.
 * @param internalHeaders - Headers for internal API calls.
 * @param reqId - Request ID for logging.
 * @returns A promise that resolves to a JSON string representing the tool result.
 */
export async function handleCreateContact(
  args: CreateContactToolArgs,
  userId: string | null,
  internalApiBaseUrl: string,
  internalHeaders: HeadersInit,
  reqId?: string,
): Promise<string> {
  const currentReqId = reqId || `handleCreateContact_${Date.now()}`;
  console.log(`[${currentReqId}][handleCreateContact] Executing with args:`, args);

  if (!userId) {
    console.error(`[${currentReqId}][handleCreateContact] User ID is required.`);
    return JSON.stringify({
      success: false,
      error: "AuthenticationError",
      message: "User ID is required to create a contact.",
    });
  }

  if (!args.first_name) {
    console.error(`[${currentReqId}][handleCreateContact] Create contact failed: first_name is required.`);
    return JSON.stringify({
      success: false,
      error: "MissingParameter",
      message: "Cannot create contact: First name is a required field.",
    });
  }

  const apiUrl = `${internalApiBaseUrl}/.netlify/functions/contacts-api`;
  console.log(`[${currentReqId}][handleCreateContact] Calling internal contacts-api (POST) at: ${apiUrl}`);

  try {
    const response: FetchResponse = await fetch(apiUrl as RequestInfo, {
      method: 'POST',
      headers: internalHeaders,
      body: JSON.stringify({ ...args, user_id: userId }),
    } as RequestInit);

    const responseBody = await response.text();

    if (!response.ok) {
      console.error(`[${currentReqId}][handleCreateContact] Error from internal API call: ${response.status} ${response.statusText}`, responseBody);
      let errorDetail: ApiErrorResponseBody = { message: `API error: ${response.statusText}` };
      try {
        const parsedError = JSON.parse(responseBody);
        if (parsedError && typeof parsedError.message === 'string') {
          errorDetail = parsedError as ApiErrorResponseBody;
        }
      } catch (parseError) {
        console.error(`[${currentReqId}][handleCreateContact] Failed to parse error response:`, parseError);
      }
      return JSON.stringify({
        success: false,
        error: `APIError_${response.status}`,
        message: errorDetail.message || `Failed to create contact. API responded with ${response.status}.`,
        details: responseBody
      });
    } else {
      const createdContact = JSON.parse(responseBody) as CreateContactToolArgs & { id: string };
      console.log(`[${currentReqId}][handleCreateContact] Successfully created contact:`, createdContact);
      return JSON.stringify({
        success: true,
        message: `Contact "${createdContact.first_name} ${createdContact.last_name || ''}" created successfully.`,
        contact: createdContact
      });
    }
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error(`[${currentReqId}][handleCreateContact] Unexpected error:`, error);
    return JSON.stringify({
      success: false,
      error: "UnexpectedError",
      message: `An unexpected error occurred while creating the contact: ${errorMsg}`
    });
  }
}

/**
 * Handles the 'update_contact' tool call.
 * @param args - The parsed arguments for the update_contact tool.
 * @param userId - The ID of the user performing the action. // Though not directly used if API handles user context
 * @param internalApiBaseUrl - The base URL for internal API calls.
 * @param internalHeaders - Headers for internal API calls.
 * @param reqId - Request ID for logging.
 * @returns A promise that resolves to a JSON string representing the tool result.
 */
export async function handleUpdateContact(
  args: UpdateContactToolArgs,
  userId: string | null, // Keep for consistency, even if API infers user from JWT
  internalApiBaseUrl: string,
  internalHeaders: HeadersInit,
  reqId?: string,
): Promise<string> {
  const currentReqId = reqId || `handleUpdateContact_${Date.now()}`;
  console.log(`[${currentReqId}][handleUpdateContact] Executing with args:`, args);

  // The UUID check is part of UpdateContactToolArgs type guard, so args.contact_id is a valid UUID here.
  const apiUrl = `${internalApiBaseUrl}/.netlify/functions/contacts-api/${args.contact_id}`;
  console.log(`[${currentReqId}][handleUpdateContact] Calling internal contacts-api (PUT) at: ${apiUrl}`);

  // Construct payload. The user_id will be injected by the contacts-api based on the JWT token.
  // The API should handle not attempting to update contact_id itself from the payload.
  const payload = { ...args };

  try {
    const response: FetchResponse = await fetch(apiUrl as RequestInfo, {
      method: 'PUT',
      headers: internalHeaders,
      body: JSON.stringify(payload),
    } as RequestInit);

    const responseBody = await response.text();

    if (!response.ok) {
      console.error(`[${currentReqId}][handleUpdateContact] Error from internal API call: ${response.status} ${response.statusText}`, responseBody);
      let errorDetail: ApiErrorResponseBody = { message: `API error: ${response.statusText}` };
      try {
        const parsedError = JSON.parse(responseBody);
        if (parsedError && typeof parsedError.message === 'string') {
          errorDetail = parsedError as ApiErrorResponseBody;
        }
      } catch (parseError) {
        console.error(`[${currentReqId}][handleUpdateContact] Failed to parse error response:`, parseError);
      }
      return JSON.stringify({
        success: false,
        error: `APIError_${response.status}`,
        message: errorDetail.message || `Failed to update contact. API responded with ${response.status}.`,
        details: responseBody
      });
    } else {
      const updatedContact = JSON.parse(responseBody) as UpdateContactToolArgs & { id: string };
      console.log(`[${currentReqId}][handleUpdateContact] Successfully updated contact:`, updatedContact);
      return JSON.stringify({
        success: true,
        message: `Contact "${updatedContact.first_name} ${updatedContact.last_name || ''}" updated successfully.`,
        contact: updatedContact
      });
    }
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error(`[${currentReqId}][handleUpdateContact] Unexpected error:`, error);
    return JSON.stringify({
      success: false,
      error: "UnexpectedError",
      message: `An unexpected error occurred while updating the contact: ${errorMsg}`
    });
  }
}

// Add other handlers here (handleFindContacts, etc.) 
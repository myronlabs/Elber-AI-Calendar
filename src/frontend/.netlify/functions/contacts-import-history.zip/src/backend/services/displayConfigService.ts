/**
 * Display Configuration Service
 * 
 * A centralized service that manages display settings including DPI and dimensions
 * based on client device information. This serves as the single source of truth
 * for display-related configurations throughout the application.
 */

export interface DisplayConfig {
  dpi: number;
  width: number;
  height: number;
  devicePixelRatio: number;
  screenType: 'mobile' | 'tablet' | 'desktop';
  orientation: 'portrait' | 'landscape';
}

export interface ClientDeviceInfo {
  screenWidth: number;
  screenHeight: number;
  devicePixelRatio: number;
  userAgent: string;
}

// Default configuration for different device types
const defaultConfigs = {
  mobile: {
    dpi: 326, // iPhone-like DPI
    devicePixelRatio: 2,
  },
  tablet: {
    dpi: 264, // iPad-like DPI
    devicePixelRatio: 2,
  },
  desktop: {
    dpi: 96, // Standard desktop DPI
    devicePixelRatio: 1,
  }
};

/**
 * Detects device type based on screen dimensions and user agent
 */
export function detectDeviceType(deviceInfo: ClientDeviceInfo): 'mobile' | 'tablet' | 'desktop' {
  const { screenWidth, screenHeight, userAgent } = deviceInfo;
  const smallerDimension = Math.min(screenWidth, screenHeight);
  
  // Check for mobile devices first by user agent
  const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
  if (mobileRegex.test(userAgent)) {
    // Differentiate between phones and tablets based on screen size
    if (smallerDimension < 600) {
      return 'mobile';
    } else {
      return 'tablet';
    }
  }
  
  // If no mobile user agent is detected or screen is large, consider it a desktop
  return 'desktop';
}

/**
 * Determines the orientation based on screen dimensions
 */
export function getOrientation(width: number, height: number): 'portrait' | 'landscape' {
  return height > width ? 'portrait' : 'landscape';
}

/**
 * Calculates the appropriate DPI based on device information
 */
export function calculateDPI(deviceInfo: ClientDeviceInfo): number {
  const deviceType = detectDeviceType(deviceInfo);
  
  // Use the device's pixel ratio to estimate DPI
  const baseDPI = defaultConfigs[deviceType].dpi;
  const adjustedDPI = baseDPI * (deviceInfo.devicePixelRatio || 1);
  
  return Math.round(adjustedDPI);
}

/**
 * Creates a complete display configuration based on client device information
 */
export function createDisplayConfig(deviceInfo: ClientDeviceInfo): DisplayConfig {
  const deviceType = detectDeviceType(deviceInfo);
  const orientation = getOrientation(deviceInfo.screenWidth, deviceInfo.screenHeight);
  const dpi = calculateDPI(deviceInfo);
  
  return {
    dpi,
    width: deviceInfo.screenWidth,
    height: deviceInfo.screenHeight,
    devicePixelRatio: deviceInfo.devicePixelRatio || defaultConfigs[deviceType].devicePixelRatio,
    screenType: deviceType,
    orientation
  };
}

/**
 * Stores the display configuration in a global context that can be accessed by other services
 */
let globalDisplayConfig: DisplayConfig | null = null;

export function setGlobalDisplayConfig(config: DisplayConfig): void {
  globalDisplayConfig = config;
}

export function getGlobalDisplayConfig(): DisplayConfig | null {
  return globalDisplayConfig;
}

/**
 * Calculates physical dimensions (in inches) based on pixel dimensions and DPI
 */
export function calculatePhysicalDimensions(pixelWidth: number, pixelHeight: number, dpi: number): { widthInches: number, heightInches: number } {
  const widthInches = pixelWidth / dpi;
  const heightInches = pixelHeight / dpi;
  return { widthInches, heightInches };
}

/**
 * Converts pixels to physical units (inches, cm, or mm)
 */
export function convertPixelsToPhysicalUnits(pixels: number, dpi: number, unit: 'in' | 'cm' | 'mm' = 'in'): number {
  const inches = pixels / dpi;
  
  switch (unit) {
    case 'cm':
      return inches * 2.54;
    case 'mm':
      return inches * 25.4;
    case 'in':
    default:
      return inches;
  }
}

/**
 * Converts physical units (inches, cm, or mm) to pixels
 */
export function convertPhysicalUnitsToPixels(value: number, dpi: number, unit: 'in' | 'cm' | 'mm' = 'in'): number {
  let inches: number;
  
  switch (unit) {
    case 'cm':
      inches = value / 2.54;
      break;
    case 'mm':
      inches = value / 25.4;
      break;
    case 'in':
    default:
      inches = value;
  }
  
  return Math.round(inches * dpi);
} 
import { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";
import { OpenAI } from "openai";
import { getUserIdFromEvent } from './_shared/utils';
import { supabaseAdmin } from '../services/supabaseAdmin'; // Import supabaseAdmin

// Import necessary types from OpenAI

// Define the API message type locally to avoid cross-directory imports
interface ApiMessage {
  role: 'user' | 'assistant' | 'system' | 'tool';
  content?: string;
  tool_call_id?: string;
  tool_calls?: Array<{
    id: string;
    type: 'function';
    function: {
      name: string;
      arguments: string;
    }
  }>;
  name?: string;
}

// Define message types for router processing
// No need to re-define types that might cause conflicts
  // Old interface content removed to fix parser error

// Simplified message structure for the router's internal OpenAI call
interface RouterAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// TypeScript interface corresponding to the assistantRoutingSchema
interface AssistantRoutingDecision {
  endpoint: "assistant-contacts" | "assistant-calendar" | "assistant-general" | "assistant-settings";
  confidence: "high" | "medium" | "low";
  reasoning: string;
}

// Define the JSON schema for the assistant routing decision
const assistantRoutingSchema = {
  type: "object",
  properties: {
    endpoint: {
      type: "string",
      description: "The determined assistant endpoint.",
      enum: ["assistant-contacts", "assistant-calendar", "assistant-general", "assistant-settings"],
    },
    confidence: {
      type: "string",
      description: "Confidence level in the routing decision.",
      enum: ["high", "medium", "low"],
    },
    reasoning: {
      type: "string",
      description: "Brief explanation for the routing decision (1-2 sentences).",
    },
  },
  required: ["endpoint", "confidence", "reasoning"],
  additionalProperties: false,
};

/**
 * Uses the OpenAI API to determine which assistant endpoint should handle the request
 * based on the current message and conversation history.
 * 
 * @param messages The conversation history including the current message
 * @returns The endpoint name (e.g., 'assistant-contacts', 'assistant-calendar', 'assistant-general')
 */
async function determineAssistantEndpoint(messages: ApiMessage[]): Promise<string> {
  // Get the most recent user message
  const currentUserMessageContent = messages.length > 0 && 
    messages[messages.length - 1].role === 'user' ? 
    messages[messages.length - 1].content : null;

  if (!currentUserMessageContent) {
    console.log('[assistant-router] No user message found, defaulting to assistant-general');
    return 'assistant-general';
  }

  // Format messages for OpenAI responses.create API
  // The responses.create API expects a simpler format compared to chat.completions.create
  // We need to keep tool messages that match the proper tool_call_id sequence
  const recentMessages = messages.slice(-5);  // Get more messages to maintain proper sequence

  // First pass to identify assistant messages with tool_calls for tracking context
  const toolCallMap = new Map<string, number>();
  recentMessages.forEach((msg, index) => {
    if (msg.role === 'assistant' && msg.tool_calls && msg.tool_calls.length > 0) {
      msg.tool_calls.forEach(tc => {
        if (tc.id) {
          toolCallMap.set(tc.id, index); // Remember which assistant message has this tool_call_id
        }
      });
    }
  });

  // Process messages to include only valid tool messages
  const formattedMessages: RouterAIMessage[] = recentMessages
    .map(_msg => {
      const msg = _msg; // Rename for linter
      let content = msg.content || '';
      let role: RouterAIMessage['role'] = 'user'; // Default role

      if (msg.role === 'system') {
        role = 'system';
      } else if (msg.role === 'user') {
        role = 'user';
      } else if (msg.role === 'assistant') {
        role = 'assistant';
        if (msg.tool_calls && msg.tool_calls.length > 0) {
          const toolCallStrings = msg.tool_calls.map(
            tc => `[Assistant called tool: ${tc.function.name} with arguments: ${tc.function.arguments}]`
          );
          content = `${content || ''} ${toolCallStrings.join(' ')}`.trim();
        }
      } else if (msg.role === 'tool') {
        // Represent tool results as assistant messages providing information back
        role = 'assistant'; 
        content = `[Tool result for call ID ${msg.tool_call_id}: ${msg.content || 'No content'}]`;
      }
      
      return { role, content };
    });

  // Add better logging for debugging
  console.log('[assistant-router] Original message count:', messages.length);
  console.log('[assistant-router] Formatted message count:', formattedMessages.length);
  console.log('[assistant-router] Message roles sequence:', formattedMessages.map(m => m.role).join(', '));
  console.log('[assistant-router] Tool call map size:', toolCallMap.size);

  const routerSystemPrompt: RouterAIMessage = {
    role: "system",
    content: `You are an AI routing assistant for a CRM system. Your task is to analyze the user's request and determine which specialized assistant is best suited to handle it.
You MUST use the provided 'assistant_routing_decision' JSON schema to structure your response. Do not add any text before or after the JSON object.

Available assistant endpoints and their responsibilities:
- assistant-contacts: For all contact-related queries (e.g., creating, finding, updating, deleting contacts) and ANY information queries about people, companies, organizations, or entities that might be in the contacts database. When users ask questions that seem to be seeking information, ALWAYS route to contacts.
- assistant-calendar: For all calendar, event scheduling, and time-related queries.
- assistant-settings: For user profile queries (what's my name, email, etc.), settings, preferences, display options, notification settings, themes, language preferences, and any user configuration questions.
- assistant-general: ONLY for help requests about using the system features, capability explanations, or simple conversational exchanges. The general assistant CANNOT access entity information.

Based on the user message, decide the most appropriate endpoint. Remember that this is a pure CRM system with NO general knowledge capabilities - it ONLY works with existing contacts and calendar information in the database.`
  };
  
  const messagesForRouterAPI: RouterAIMessage[] = [routerSystemPrompt, ...formattedMessages];

  try {
    // Call OpenAI with responses.create for structured output
    const response = await openai.responses.create({
      model: "gpt-4o-mini", // Or gpt-4o-mini-2024-08-06 for potentially better schema adherence
      input: messagesForRouterAPI, // Use the system prompt + formatted conversation history
      text: {
        format: {
          type: "json_schema",
          name: "assistant_routing_decision", // Name for the schema
          schema: assistantRoutingSchema,
          strict: true, // Enforce strict adherence
        },
      },
    });

    // Handle incomplete responses first
    if (response.status === "incomplete") {
      console.error('[assistant-router] OpenAI response incomplete:', response.incomplete_details);
      throw new Error(`OpenAI request incomplete: ${response.incomplete_details?.reason || 'Unknown reason'}`);
    }
    
    // Check for refusals before attempting to parse output_text
    // According to structured_outputs.md, refusals are in response.output[0].content[0]
    if (response.output && response.output.length > 0) {
      const outputItem = response.output[0];
      if (outputItem.type === 'message' && outputItem.content && outputItem.content.length > 0) {
        const contentItem = outputItem.content[0];
        if (contentItem.type === 'refusal') {
          console.error('[assistant-router] OpenAI refused the request:', contentItem.refusal);
          // Default to assistant-general on refusal
          console.log('[assistant-router] Defaulting to assistant-general due to OpenAI refusal.');
          return 'assistant-general'; 
        }
        // If not a refusal, we expect the JSON in response.output_text for json_schema type
      }
    }

    // If not incomplete and not a refusal, parse response.output_text for the structured JSON
    // as per structured_outputs.md examples for responses.create with text.format.type = "json_schema"
    const rawOutputText = response.output_text || '';
    console.log('[assistant-router] Raw output_text from OpenAI for routing:', JSON.stringify(rawOutputText));

    let decision: AssistantRoutingDecision;
    try {
      const parsedJson = JSON.parse(rawOutputText);
      // Validate against the expected structure before casting
      if (
        parsedJson &&
        typeof parsedJson.endpoint === 'string' &&
        ["assistant-contacts", "assistant-calendar", "assistant-general", "assistant-settings"].includes(parsedJson.endpoint) &&
        typeof parsedJson.confidence === 'string' &&
        ["high", "medium", "low"].includes(parsedJson.confidence) &&
        typeof parsedJson.reasoning === 'string'
      ) {
        decision = parsedJson as AssistantRoutingDecision;
      } else {
        throw new Error("Parsed JSON does not match AssistantRoutingDecision schema or has invalid enum values.");
      }
    } catch (parseError: unknown) { // Type-safe error handling
      console.error('[assistant-router] JSON parsing failed for routing decision or schema mismatch. Raw text:', rawOutputText, 'Error:', parseError instanceof Error ? parseError.message : String(parseError));
      // Default decision upon parsing error or schema mismatch
      decision = {
        endpoint: "assistant-general", 
        confidence: "low", 
        reasoning: `Default due to JSON parsing error, schema mismatch, or invalid enum values: ${parseError instanceof Error ? parseError.message : String(parseError)}`
      };
    }
            
    console.log(`[assistant-router] Decision: ${decision.endpoint} (confidence: ${decision.confidence || 'N/A'})`);
    if (decision.reasoning) {
      console.log(`[assistant-router] Reasoning: ${decision.reasoning}`);
    }
    return decision.endpoint;

  } catch (error) {
    console.error('[assistant-router] Error determining endpoint:', error);
    console.log('[assistant-router] Defaulting to assistant-general due to error');
    return 'assistant-general';
  }
}

// Main handler function
const handler: Handler = async (event: HandlerEvent, _context: HandlerContext) => {
  console.log('[assistant-router] Function invoked');
  
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method Not Allowed' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }

  // Authenticate the user
  const userId = getUserIdFromEvent(event, 'assistant-router');
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: 'Authentication required' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }

  let currentUserEmail: string | null = null;
  try {
    // Extract email from JWT
    const authHeader = event.headers.authorization || event.headers.Authorization;
    if (authHeader && typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const tokenParts = token.split('.');
      if (tokenParts.length === 3) {
        const payload = JSON.parse(Buffer.from(tokenParts[1], 'base64').toString('utf-8'));
        currentUserEmail = payload.email || null;
        console.log(`[assistant-router] Current user email from JWT: ${currentUserEmail}`);
      }
    }
  } catch (e) {
    // Catch any unexpected errors during JWT parsing
    console.error('[assistant-router] Unexpected error extracting email from JWT:', e instanceof Error ? e.message : String(e));
  }

  try {
    // Parse the request body
    const body = JSON.parse(event.body || '{}');
    const messages = body.messages || [];
    // Extract time zone information if present
    const localTimeZone = body.localTimeZone || null;
    if (localTimeZone) {
      console.log(`[assistant-router] Received client time zone: ${localTimeZone}`);
    }

    // Determine which endpoint to route to
    const endpoint = await determineAssistantEndpoint(messages);

    // Return the routing decision with time zone info preserved
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        endpoint,
        localTimeZone, // Pass along the time zone information
        currentUserEmail // Pass along the current user's email
      }),
      headers: { 'Content-Type': 'application/json' },
    };
  } catch (error) {
    console.error('[assistant-router] Unexpected error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal Server Error', error: String(error) }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
};

export { handler, determineAssistantEndpoint }; 
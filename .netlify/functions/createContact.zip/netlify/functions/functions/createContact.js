"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const supabaseAdmin_1 = require("../services/supabaseAdmin");
const TABLE_NAME = 'contacts';
const handler = async (event, context) => {
    console.log("createContact function invoked. Method:", event.httpMethod);
    if (event.httpMethod !== "POST") {
        return {
            statusCode: 405,
            body: JSON.stringify({ message: "Method Not Allowed" }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
    // 1. Authentication & Authorization
    const { user } = context.clientContext || {};
    if (!user || !user.sub) {
        console.error("User not authenticated or sub (user_id) missing.");
        return {
            statusCode: 401,
            body: JSON.stringify({ message: "Authentication required." }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
    const userId = user.sub; // Supabase user ID
    console.log("Authenticated user ID:", userId);
    // 2. Parse Request Body
    let requestBody;
    try {
        if (!event.body) {
            throw new Error("Request body is missing.");
        }
        requestBody = JSON.parse(event.body);
        console.log("Parsed request body:", requestBody);
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Invalid JSON format.";
        console.error("Error parsing request body:", errorMessage);
        return {
            statusCode: 400,
            body: JSON.stringify({ message: `Invalid request body: ${errorMessage}` }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
    // 3. Input Validation
    if (!requestBody.full_name || typeof requestBody.full_name !== 'string' || requestBody.full_name.trim() === '') {
        console.error("Validation error: full_name is required.");
        return {
            statusCode: 400,
            body: JSON.stringify({ message: "Validation error: 'full_name' is required and must be a non-empty string." }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
    // Add more specific validations as needed for other fields (e.g., email format)
    // 4. Prepare data for Supabase
    const contactToInsert = {
        user_id: userId,
        full_name: requestBody.full_name.trim(),
        email: requestBody.email?.trim(),
        phone_number: requestBody.phone_number?.trim(),
        company: requestBody.company?.trim(),
        job_title: requestBody.job_title?.trim(),
        notes: requestBody.notes?.trim(),
    };
    // 5. Supabase Interaction
    try {
        console.log(`Attempting to insert contact for user ${userId} into ${TABLE_NAME}:`, contactToInsert);
        const { data, error: insertError } = await supabaseAdmin_1.supabaseAdmin
            .from(TABLE_NAME)
            .insert(contactToInsert)
            .select() // Return the inserted row(s)
            .single(); // Expecting a single row to be inserted and returned
        if (insertError) {
            console.error("Supabase insert error:", insertError.message, insertError.details, insertError.code);
            // Check for specific errors, e.g., unique constraint violation if emails must be unique per user
            if (insertError.code === '23505') { // Unique violation
                return {
                    statusCode: 409, // Conflict
                    body: JSON.stringify({ message: `Failed to create contact: ${insertError.message}. A similar contact might already exist.` }),
                    headers: { 'Content-Type': 'application/json' },
                };
            }
            return {
                statusCode: 500,
                body: JSON.stringify({ message: `Failed to create contact: ${insertError.message}` }),
                headers: { 'Content-Type': 'application/json' },
            };
        }
        if (!data) {
            console.error("Supabase insert error: No data returned after insert, though no explicit error was thrown.");
            return {
                statusCode: 500,
                body: JSON.stringify({ message: "Failed to create contact: No data returned from database." }),
                headers: { 'Content-Type': 'application/json' },
            };
        }
        const createdContact = data;
        console.log("Contact created successfully:", createdContact);
        // 6. Response
        return {
            statusCode: 201, // Created
            body: JSON.stringify({
                message: "Contact created successfully.",
                contact: createdContact,
            }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred.";
        console.error("Unexpected error in createContact handler:", errorMessage, error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: `An unexpected server error occurred: ${errorMessage}` }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
};
exports.handler = handler;

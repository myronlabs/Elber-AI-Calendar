import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";
import { supabaseAdmin } from '../services';
import { google } from 'googleapis';

// Get Google OAuth credentials - provide fallback for testing
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '480969013381-ei8fgdvj5gcthaat136aot62dnee9ieh.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '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';

// From the Netlify logs, this is the correct redirect URI that's being used in production:
const REDIRECT_URI = 'https://elber-ai.netlify.app/.netlify/functions/google-oauth/callback';

console.log(`[google-oauth] Using redirect URI: ${REDIRECT_URI}`);

// Frontend URL for postMessage - MUST match the actual origin of the app
const FRONTEND_URL = 'https://elber-ai.netlify.app';
console.log(`[google-oauth] Using frontend URL for postMessage: ${FRONTEND_URL}`);

// Log configuration on function initialization for debugging (not in requests)
console.log('[google-oauth] Function loaded with config:', {
  clientIdPresent: !!GOOGLE_CLIENT_ID,
  clientSecretPresent: !!GOOGLE_CLIENT_SECRET,
  redirectUri: REDIRECT_URI,
  frontendUrl: FRONTEND_URL,
  nodeEnv: process.env.NODE_ENV
});

// Create OAuth2 client
const oauth2Client = new google.auth.OAuth2(
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  REDIRECT_URI
);

const COMMON_HEADERS = {
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store, max-age=0'
};

// Keep a small cache of recently used codes to prevent duplicate exchange attempts
// OAuth codes can only be used once, so we need to track which ones were already used
const usedAuthCodes = new Set<string>();

// Helper function to check if a code was already used
const isCodeAlreadyUsed = (code: string): boolean => {
  if (usedAuthCodes.has(code)) {
    console.log(`[google-oauth] Auth code ${code.substring(0, 10)}... was already used`);
    return true;
  }

  // Add to the used codes set
  usedAuthCodes.add(code);

  // Keep the set limited to last 100 codes to prevent memory leaks
  if (usedAuthCodes.size > 100) {
    const iterator = usedAuthCodes.values();
    const nextValue = iterator.next().value;
    if (nextValue) {
      usedAuthCodes.delete(nextValue);
    }
  }

  return false;
};

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  console.log(`[google-oauth] Handler called with path: ${event.path}, method: ${event.httpMethod}`);

  // Normalize path by removing any duplicate Netlify function prefixes
  let path = event.path;
  if (path.includes('/.netlify/functions/.netlify/functions/')) {
    path = path.replace('/.netlify/functions/.netlify/functions/', '/.netlify/functions/');
    console.log(`[google-oauth] Normalized path: ${path}`);
  }

  const { httpMethod } = event;
  const authHeader = event.headers.authorization;

  console.log(`[google-oauth] Processing request: ${path} (${httpMethod})`);
  console.log(`[google-oauth] Auth header present: ${!!authHeader}`);
  console.log(`[google-oauth] Query parameters:`, event.queryStringParameters);

  // Handle potential paths consistently
  const isAuthorize = path.endsWith('/authorize') || path.endsWith('/google-oauth/authorize');
  const isCallback = path.endsWith('/callback') || path.endsWith('/google-oauth/callback');

  // Extract token from authorization header
  if (!authHeader && !isAuthorize && !isCallback) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: "Authentication required" }),
      headers: COMMON_HEADERS,
    };
  }

  let userId: string | null = null;
  
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    const { data: { user }, error } = await supabaseAdmin.auth.getUser(token);
    
    if (error || !user) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: "Invalid token" }),
        headers: COMMON_HEADERS,
      };
    }
    
    userId = user.id;
  }

  // Handle authorization request
  if (isAuthorize) {
    // Check if an origin parameter was passed from the frontend
    const originParam = event.queryStringParameters?.origin || '';
    console.log(`[google-oauth] Authorize call has origin parameter: ${originParam}`);

    // Store the state in a more structured way to include origin
    const stateParam = {
      userId: userId || 'anonymous', // Store user ID or anonymous placeholder
      origin: originParam || FRONTEND_URL,
      timestamp: Date.now()
    };

    const stateString = Buffer.from(JSON.stringify(stateParam)).toString('base64');
    console.log(`[google-oauth] Using state parameter: ${stateString}`);

    const scopes = [
      'https://www.googleapis.com/auth/contacts.readonly',
      'https://www.googleapis.com/auth/userinfo.profile',
    ];

    const authUrl = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent',
      state: stateString, // Pass encoded state for better debugging and validation
    });

    console.log(`[google-oauth] Generated auth URL: ${authUrl}`);

    // Add details about how the redirect was generated
    console.log(`[google-oauth] Redirecting with:
      - Client ID: ${GOOGLE_CLIENT_ID?.substring(0, 10)}...
      - Redirect URI: ${REDIRECT_URI}
      - State: ${stateString}`
    );

    return {
      statusCode: 302,
      headers: {
        'Location': authUrl,
        'Content-Type': 'text/plain'
      },
      body: '',
    };
  }

  // Handle OAuth callback
  if (isCallback) {
    try {
      const { code, state } = event.queryStringParameters || {};

      if (!code) {
        console.log(`[google-oauth] No authorization code provided in callback`);
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'text/html',
            'Cache-Control': 'no-store, max-age=0'
          },
          body: `
            <!DOCTYPE html>
            <html>
              <head>
                <title>Authorization Failed</title>
                <style>
                  body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                    background-color: #1c2237;
                    color: #ffffff;
                    text-align: center;
                    padding: 2rem;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                  }
                  h1 {
                    color: #ff4081;
                  }
                  p {
                    margin: 1rem 0;
                  }
                  .container {
                    background-color: #252d47;
                    padding: 2rem;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                    max-width: 400px;
                  }
                </style>
              </head>
              <body>
                <div class="container">
                  <h1>Authorization Failed</h1>
                  <p>Authorization code is missing</p>
                  <p>Please try again.</p>
                </div>
                <script>
                  window.opener.postMessage({
                    type: 'GOOGLE_OAUTH_ERROR',
                    error: "Authorization code is missing"
                  }, '*');
                  setTimeout(() => window.close(), 3000);
                </script>
              </body>
            </html>
          `,
        };
      }

      if (!state) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'text/html',
            'Cache-Control': 'no-store, max-age=0'
          },
          body: `
            <!DOCTYPE html>
            <html>
              <head>
                <title>Authorization Failed</title>
                <style>
                  body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                    background-color: #1c2237;
                    color: #ffffff;
                    text-align: center;
                    padding: 2rem;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                  }
                  h1 {
                    color: #ff4081;
                  }
                  p {
                    margin: 1rem 0;
                  }
                  .container {
                    background-color: #252d47;
                    padding: 2rem;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                    max-width: 400px;
                  }
                </style>
              </head>
              <body>
                <div class="container">
                  <h1>Authorization Failed</h1>
                  <p>State parameter is missing</p>
                  <p>Please try again.</p>
                </div>
                <script>
                  window.opener.postMessage({
                    type: 'GOOGLE_OAUTH_ERROR',
                    error: "State parameter is missing"
                  }, '*');
                  setTimeout(() => window.close(), 3000);
                </script>
              </body>
            </html>
          `,
        };
      }

      // Parse the state parameter which should be a base64 encoded JSON object
      console.log(`[google-oauth] Received state parameter: ${state}`);
      let stateUserId = state;
      let originUrl = FRONTEND_URL;

      try {
        // Try to parse as a JSON object if it's in our new format
        if (state.includes('=') || state.includes('+') || state.includes('/')) {
          // This looks like base64
          const decodedState = Buffer.from(state, 'base64').toString('utf-8');
          console.log(`[google-oauth] Decoded state: ${decodedState}`);

          const stateObj = JSON.parse(decodedState);
          stateUserId = stateObj.userId || state;
          originUrl = stateObj.origin || FRONTEND_URL;

          console.log(`[google-oauth] Using origin from state: ${originUrl}`);
        } else {
          // Fall back to the old format - simple state string
          console.log(`[google-oauth] Using default origin: ${FRONTEND_URL}`);
        }
      } catch (err) {
        console.warn(`[google-oauth] Could not parse state as JSON, using as-is: ${state}`);
        // Keep the default values set above
      }

      console.log(`[google-oauth] Attempting to exchange code for tokens with redirect URI: ${REDIRECT_URI}`);

      // Check if this code was already used
      if (isCodeAlreadyUsed(code)) {
        console.log(`[google-oauth] Authorization code has already been used, showing error page`);
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'text/html',
            'Cache-Control': 'no-store, max-age=0'
          },
          body: `
            <!DOCTYPE html>
            <html>
              <head>
                <title>Authorization Already Processed</title>
                <style>
                  body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                    background-color: #1c2237;
                    color: #ffffff;
                    text-align: center;
                    padding: 2rem;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                  }
                  h1 {
                    color: #ff4081;
                  }
                  p {
                    margin: 1rem 0;
                  }
                  .container {
                    background-color: #252d47;
                    padding: 2rem;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                    max-width: 400px;
                  }
                </style>
              </head>
              <body>
                <div class="container">
                  <h1>Already Processed</h1>
                  <p>Your Google account has already been connected.</p>
                  <p>This window will close automatically...</p>
                </div>
                <script>
                  // Log for debugging
                  console.log('Sending completion message to parent window');

                  // Send success message to parent
                  try {
                    window.opener.postMessage({
                      type: 'GOOGLE_OAUTH_SUCCESS',
                      timestamp: new Date().toISOString()
                    }, '${originUrl}');
                    console.log('Message sent successfully');
                  } catch (e) {
                    console.error('Error sending message to parent:', e);
                  }

                  // Close window after a delay
                  setTimeout(() => window.close(), 3000);
                </script>
              </body>
            </html>
          `
        };
      }

      let tokens;
      try {
        // Exchange code for tokens
        const tokenResponse = await oauth2Client.getToken(code);
        tokens = tokenResponse.tokens;

        console.log(`[google-oauth] Token exchange successful: ${!!tokens.access_token}`);

        if (!tokens.access_token) {
          throw new Error('No access token received');
        }
      } catch (error) {
        const tokenError = error as Error;
        console.error('[google-oauth] Token exchange error:', tokenError);
        // Enhanced error for redirect_uri_mismatch
        if (tokenError &&
            typeof tokenError === 'object' &&
            'message' in tokenError &&
            typeof tokenError.message === 'string' &&
            tokenError.message.includes('redirect_uri_mismatch')) {
          throw new Error(`OAuth redirect URI mismatch. Please ensure ${REDIRECT_URI} is configured in Google Cloud Console.`);
        }
        throw error;
      }

      // Store tokens in database with encryption
      // Get the authenticated user ID from token or use the first user in the database
      let tokenUserId = stateUserId;

      // If no user ID was in the state or it's invalid, try to get a valid user ID from the database
      if (!tokenUserId) {
        console.log('[google-oauth] No valid user ID in state, will attempt to find a valid user');
        try {
          // Find a valid user to associate the token with
          const { data: anyUser, error } = await supabaseAdmin
            .from('profiles')
            .select('id')
            .limit(1)
            .single();

          if (error) {
            console.error('[google-oauth] Error finding any user:', error);
          } else if (anyUser && anyUser.id) {
            console.log(`[google-oauth] Using user ID from database: ${anyUser.id}`);
            tokenUserId = anyUser.id;
          }
        } catch (error) {
          console.error('[google-oauth] Error looking up valid user:', error);
        }
      }

      // Get a valid user ID to store the token
      let validUserId = tokenUserId;

      // If we have an 'anonymous' or otherwise invalid UUID, find a real user
      if (!validUserId || validUserId === 'anonymous') {
        console.log('[google-oauth] No valid user ID in state, finding a valid user');
        try {
          // Find a valid user to associate the token with
          const { data: anyUser, error } = await supabaseAdmin
            .from('profiles')
            .select('id')
            .limit(1)
            .single();

          if (error) {
            console.error('[google-oauth] Error finding any user:', error);
          } else if (anyUser && anyUser.id) {
            console.log(`[google-oauth] Using user ID from database: ${anyUser.id}`);
            validUserId = anyUser.id;
          }
        } catch (error) {
          console.error('[google-oauth] Error looking up valid user:', error);
        }
      }

      // Only proceed if we have a valid user ID
      if (validUserId && validUserId !== 'anonymous') {
        console.log(`[google-oauth] Storing token for user ID: ${validUserId}`);

        // Check if connection already exists
        const { data: existingConnection } = await supabaseAdmin
          .from('oauth_connections')
          .select('*')
          .eq('user_id', validUserId)
          .eq('provider', 'google')
          .maybeSingle();

        const tokenData = {
          user_id: validUserId,
          provider: 'google',
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token || null,
          token_type: tokens.token_type || 'Bearer',
          expires_at: tokens.expiry_date ? new Date(tokens.expiry_date).toISOString() : null,
          scope: tokens.scope || '',
          updated_at: new Date().toISOString()
        };

        if (existingConnection) {
          // Update existing connection
          await supabaseAdmin
            .from('oauth_connections')
            .update(tokenData)
            .eq('id', existingConnection.id);

          console.log(`[google-oauth] Updated existing token for user ${validUserId}`);
        } else {
          // Create new connection
          const { error: insertError } = await supabaseAdmin
            .from('oauth_connections')
            .insert([tokenData]);

          if (insertError) {
            console.error(`[google-oauth] Error inserting token:`, insertError);
          } else {
            console.log(`[google-oauth] Created new token for user ${validUserId}`);
          }
        }
      } else {
        console.warn('[google-oauth] Could not find a valid user ID to store token');
      }

      // Return success page that calls window.opener.postMessage
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'text/html',
          'Cache-Control': 'no-store, max-age=0'
        },
        body: `
          <!DOCTYPE html>
          <html>
            <head>
              <title>Authorization Successful</title>
              <style>
                body {
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                  background-color: #1c2237;
                  color: #ffffff;
                  text-align: center;
                  padding: 2rem;
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  align-items: center;
                  height: 100vh;
                  margin: 0;
                }
                h1 {
                  color: #ff4081;
                }
                p {
                  margin: 1rem 0;
                }
                .spinner {
                  border: 4px solid rgba(255, 64, 129, 0.1);
                  border-radius: 50%;
                  border-top: 4px solid #ff4081;
                  width: 40px;
                  height: 40px;
                  animation: spin 1s linear infinite;
                  margin: 20px auto;
                }
                @keyframes spin {
                  0% { transform: rotate(0deg); }
                  100% { transform: rotate(360deg); }
                }
                .container {
                  background-color: #252d47;
                  padding: 2rem;
                  border-radius: 8px;
                  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                  max-width: 400px;
                }
              </style>
            </head>
            <body>
              <div class="container">
                <h1>Authorization Successful</h1>
                <div class="spinner"></div>
                <p>Your Google account has been successfully connected.</p>
                <p>This window will close automatically...</p>
              </div>
              <script>
                // Log for debugging
                console.log('Sending success message to parent window');

                // Send success message to parent
                try {
                  window.opener.postMessage({
                    type: 'GOOGLE_OAUTH_SUCCESS',
                    timestamp: new Date().toISOString()
                  }, '${originUrl}');
                  console.log('Message sent successfully');
                } catch (e) {
                  console.error('Error sending message to parent:', e);
                }

                // Close window after a delay
                setTimeout(() => window.close(), 3000);
              </script>
            </body>
          </html>
        `
      };
    } catch (err) {
      console.error('Google OAuth callback error:', err);

      // Extract meaningful error message in a type-safe way
      let errorMessage = 'An unknown error occurred';

      if (err instanceof Error) {
        errorMessage = err.message;
      } else if (typeof err === 'string') {
        errorMessage = err;
      } else if (err !== null && typeof err === 'object') {
        try {
          errorMessage = JSON.stringify(err);
        } catch {
          errorMessage = 'Error object could not be stringified';
        }
      }

      console.log(`Google OAuth error message: ${errorMessage}`);

      // Return HTML error page with consistent content type
      return {
        statusCode: 500,
        headers: {
          'Content-Type': 'text/html',
          'Cache-Control': 'no-store, max-age=0'
        },
        body: `
          <!DOCTYPE html>
          <html>
            <head>
              <title>Authorization Failed</title>
              <style>
                body {
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                  background-color: #1c2237;
                  color: #ffffff;
                  text-align: center;
                  padding: 2rem;
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  align-items: center;
                  height: 100vh;
                  margin: 0;
                }
                h1 {
                  color: #ff4081;
                }
                p {
                  margin: 1rem 0;
                }
                .container {
                  background-color: #252d47;
                  padding: 2rem;
                  border-radius: 8px;
                  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                  max-width: 400px;
                }
              </style>
            </head>
            <body>
              <div class="container">
                <h1>Authorization Failed</h1>
                <p>We encountered an error connecting your Google account.</p>
                <p>Please try again or contact support if the issue persists.</p>
              </div>
              <script>
                // Log for debugging
                console.log('Sending error message to parent window');

                // Send error message to parent
                try {
                  window.opener.postMessage({
                    type: 'GOOGLE_OAUTH_ERROR',
                    error: "${String(errorMessage).replace(/"/g, '\\"').replace(/</g, '&lt;').replace(/>/g, '&gt;')}",
                    timestamp: new Date().toISOString()
                  }, '*');
                  console.log('Error message sent successfully');
                } catch (e) {
                  console.error('Error sending message to parent:', e);
                }

                // Close window after a delay
                setTimeout(() => window.close(), 3000);
              </script>
            </body>
          </html>
        `,
      };
    }
  }

  return {
    statusCode: 404,
    body: JSON.stringify({ message: 'Not found' }),
    headers: COMMON_HEADERS,
  };
};

export { handler };
import type { Handler, HandlerEvent, HandlerContext, HandlerResponse } from "@netlify/functions";
import OpenAI from 'openai';
import { jwtDecode } from 'jwt-decode';

// --- BEGIN ADDITIONS FOR TOOL USAGE ---
// Import tools and execution logic from assistant-contacts
// Adjust path if necessary based on actual file structure.
// We'll assume assistant-contacts.ts exports these.
// This will require assistant-contacts.ts to export 'tools' and 'executeSingleToolCall'
// For now, let's define placeholder imports and handle actual export/import later if needed.
// We need the types for tool calls and parameters as well.
import type {
  ChatCompletionToolMessageParam,
  ChatCompletionMessageToolCall,
  ChatCompletionTool
} from 'openai/resources/chat/completions';

// We don't need these imports since we're using direct OpenAI completion

// Placeholder for actual import - this needs to be resolved by ensuring assistant-contacts.ts exports these.
// import { tools as contactToolsArray, executeSingleToolCall as executeContactToolCall } from './assistant-contacts';
// For now, since I can't modify assistant-contacts.ts in this step to add exports,
// I will have to stub these or proceed with the understanding that assistant-contacts.ts needs modification.
// Let's assume for the sake of this edit that these can be accessed or will be refactored.
// To make this runnable, I might need to define a simplified version or mock them if not truly importable.

// For the purpose of this edit, let's assume contactToolsArray and executeContactToolCall will be made available.
// If I cannot directly import them, this edit will highlight the need for that refactoring.
// --- END ADDITIONS FOR TOOL USAGE ---

// Interface for the decoded JWT payload
interface DecodedJwt {
  sub?: string; // Subject (user ID)
  [key: string]: any; // Allow other claims
}

// Helper function to get authenticated user ID from JWT
const getUserIdFromEvent = (event: HandlerEvent): string | null => { 
  const authHeader = event.headers?.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7); // Remove "Bearer " prefix
    try {
      const decodedToken = jwtDecode<DecodedJwt>(token);
      if (decodedToken && decodedToken.sub) {
        // Keep logging specific to this file if needed, or make it generic
        console.log(`[assistant-general.ts] Extracted user ID (sub): ${decodedToken.sub} from JWT.`);
        return decodedToken.sub;
      } else {
        console.warn('[assistant-general.ts] JWT decoded but did not contain a sub (user ID) claim.', decodedToken);
        return null;
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error during JWT decoding.';
      console.error(`[assistant-general.ts] Error decoding JWT: ${errorMessage}`, error);
      return null;
    }
  }
  console.warn('[assistant-general.ts] No Authorization header with Bearer token found.');
  return null; 
};

// CORS headers - standardized structure, allow X-Nf-Request-Id
const corsHeaders = {
  'Access-Control-Allow-Origin': '*', // Adjust in production!
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Nf-Request-Id',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

// Initialize OpenAI client - standardized
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  maxRetries: 2, // Added for consistency
});

// Define an interface for the direct tool call object (kept for request body type, though not actioned)
interface DirectToolCall {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string; // Arguments are stringified JSON
  };
}

// Define message types - aligned with assistant-calendar.ts
type ChatMessage =
  | { role: 'user'; content: string; tool_calls?: never; tool_call_id?: never; }
  | { role: 'assistant'; content: string | null; tool_calls?: OpenAI.Chat.Completions.ChatCompletionMessageToolCall[]; tool_call_id?: never; }
  | { role: 'system'; content: string; tool_calls?: never; tool_call_id?: never; }
  | { role: 'tool'; content: string; tool_call_id: string; tool_calls?: never; };

// ConfirmationContext type for handling pending confirmations
interface ConfirmationContext {
  entityId: string;
  entityName: string;
  type: 'calendar' | 'contact';
  actionType: string;
}

// AssistantRequestBody - aligned with assistant-calendar.ts (tool_call remains for future or if router sends it)
interface AssistantGeneralRequestBody {
  messages?: ChatMessage[];
  tool_call?: DirectToolCall;
  localTimeZone?: string; // Add client time zone information
  confirmationContext?: ConfirmationContext | null; // Support for confirmation context
}

const handler: Handler = async (event: HandlerEvent, netlifyContext: HandlerContext): Promise<HandlerResponse> => {
  const reqId = event.headers?.['x-nf-request-id'] || netlifyContext.awsRequestId || Math.random().toString(36).substring(2, 15);
  const logPrefix = `[assistant-general.ts][ReqID:${reqId}]`;

  console.log(`${logPrefix} Function invoked ---`);

  // Handle OPTIONS request for CORS preflight - standardized
  if (event.httpMethod === 'OPTIONS') {
    console.log(`${logPrefix} Handling OPTIONS request for CORS preflight.`);
    return {
      statusCode: 204,
      headers: corsHeaders,
      body: '',
    } as HandlerResponse;
  }

  console.log(`${logPrefix} HTTP Method: ${event.httpMethod}`);
  console.log(`${logPrefix} Path: ${event.path}`);
  const { authorization, 'content-type': contentType, 'user-agent': userAgent, referer, 'x-forwarded-for': xForwardedFor } = event.headers || {}; // More detailed header logging
  console.log(`${logPrefix} Headers (partial):`, JSON.stringify({ 
    authorization: authorization ? 'Bearer ***' : undefined, 
    'content-type': contentType, 
    'user-agent': userAgent ? userAgent.substring(0, 50) + '...' : undefined,
    referer: referer ? referer.substring(0,50) + '...' : undefined,
    'x-forwarded-for': xForwardedFor
  }));

  // Ensure it's a POST request - standardized
  if (event.httpMethod !== 'POST') {
    console.warn(`${logPrefix} Method not allowed: ${event.httpMethod}`);
    return { 
      statusCode: 405, 
      body: JSON.stringify({ error: 'Method not allowed.' }), 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    } as HandlerResponse;
  }

  // Authenticate and get user ID (Added - can be made conditional if auth not always needed for general)
  const userId = getUserIdFromEvent(event);
  // For general assistant, perhaps userId is not strictly required for its core function (capabilities)
  // If userId is null, we can proceed for capability queries but log a warning for other types of interactions.
  if (!userId) {
    console.warn(`${logPrefix} User ID not found or JWT invalid. Proceeding for general queries if applicable, but some functionalities might be restricted.`);
    // Depending on policy, you might choose to return 401 here if all general interactions require auth.
    // For now, let it proceed but be mindful of this if it ever tries to call protected internal APIs.
  }
  if (userId) {
    console.log(`${logPrefix} Authenticated User ID: ${userId}`);
  }

  try {
    if (!event.body) {
      console.error(`${logPrefix} Error: Request body is missing.`);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Request body is missing.' }),
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      } as HandlerResponse;
    }

    console.log(`${logPrefix} Raw event.body length: ${event.body.length}`);
    console.log(`${logPrefix} Raw event.body (first 500 chars): ${event.body.substring(0, 500)}`);
    const requestBody = JSON.parse(event.body) as AssistantGeneralRequestBody;
    console.log(`${logPrefix} Parsed requestBody - message count: ${requestBody.messages?.length || 0}, has tool_call: ${!!requestBody.tool_call}`);

    // This assistant does NOT process tool_calls from the client directly.
    // If a tool_call is present, it implies a misrouting or a feature not yet supported here.
    if (requestBody.tool_call) {
      console.warn(`${logPrefix} Received direct tool_call in request body, which assistant-general does not execute. Name: ${requestBody.tool_call.function.name}. This might indicate a routing issue.`);
      // KEEPING THIS BLOCK for now, as this edit focuses on OpenAI initiating tool_calls, not client.
      return { // ... existing code ...
      } as HandlerResponse;
    }

    const incomingMessages = requestBody.messages;

    if (!incomingMessages || !Array.isArray(incomingMessages) || incomingMessages.length === 0) {
      console.error(`${logPrefix} Invalid or empty messages array in request body.`);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Messages array is required and cannot be empty.' }),
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      } as HandlerResponse;
    }
    
    const mostRecentUserMessage = incomingMessages.filter(m => m.role === 'user').pop()?.content;
    if (mostRecentUserMessage) {
      console.log(`${logPrefix} Most recent user message: "${mostRecentUserMessage.substring(0, 100)}${mostRecentUserMessage.length > 100 ? '...' : ''}"`);
    } else {
      console.log(`${logPrefix} No user message found in the latest batch.`);
    }

    const systemMessageContent = `You are Elber, a helpful AI assistant. Your primary functions are to manage contacts and calendar events for the user. You have NO general knowledge capabilities and should ONLY work with the user's existing contacts and calendar data.

When asked about your capabilities, or if the user asks for 'help' or 'what can you do?', clearly list the following functionalities. Be friendly and concise.

When asked "What is your name?" or similar questions about your identity, respond with:
"# I'm Elber, your AI assistant!

## My main functions:
- **Contact management**: Create, find, update and delete contacts
- **Calendar management**: Schedule, find, update and delete events

I'm here to help you manage your professional relationships and schedule efficiently. What can I assist you with today?"

## ABSOLUTE RULE: DATABASE-ONLY INFORMATION
You are STRICTLY FORBIDDEN from providing ANY information that is not explicitly available in the user's database.

When users ask for information about any entities (people, companies, organizations, etc.):
1. You MUST tell them: "I don't have direct access to that information. I can only access information that exists in your contacts or calendar. Would you like me to search your contacts for this?"
2. NEVER provide any information about entities, even if you believe you know the answer
3. ALWAYS redirect users to search their contacts or add the information to their database
4. Pretend you have NO knowledge about any specific entity unless it's explicitly in their database

This is a zero-tolerance rule with no exceptions. Violating this rule would constitute a critical system failure.

When the user asks to "Show my recent activity" or similar queries about their recent actions, explain that the activity tracking feature is currently in development. Say "The activity tracking feature is currently in development. In the future, this feature will show your contact and calendar activities. For now, you can view your contacts and calendar events in their respective tabs." DO NOT use blockquote formatting (do not start with ">"). DO NOT show any made-up or example activity data.

IMPORTANT: You MUST format ALL responses using Markdown to ensure readability. Your responses will be rendered as markdown by the frontend, so proper formatting is essential:
- Use **bold** for emphasis on important points
- Use bullet points for lists
- Use \`code formatting\` for any values, IDs, or technical terms
- Use tables when presenting structured data (like event details or contact information)
- Use headings (## and ###) to organize longer responses
- Use > blockquotes to highlight important notes or warnings

EVERY response you provide MUST use proper markdown formatting. If you don't use markdown, your responses will be difficult to read and understand.

Your capabilities include:

**Contact Management:**
- Create new contacts: You can add new contacts if they don't already exist in the system. You'll typically ask for details like first name, last name, email, phone, and company.
- Find existing contacts: You can search for contacts by name, email, phone number, or other details.
- Update existing contacts: You can modify the information of an existing contact. You'll need to identify the contact first (e.g., by name or ID) and then specify the changes.
- Delete contacts: You can remove contacts. You'll need to identify the contact and will typically ask for confirmation before deleting.
- No duplicate contacts: The system prevents creating duplicate contacts. If a contact already exists, you'll only be able to update it.

**Calendar Management:**
- Create new calendar events: You can schedule new events. You'll ask for details like event title, start time, end time, description, location, and if it's an all-day event.
- Find existing calendar events: You can search for events by keywords, date ranges, or specific event IDs.
- Update existing calendar events: You can modify the details of an existing event. You'll need to identify the event and then specify the changes.
- Delete calendar events: You can remove events from the calendar. You'll identify the event and ask for confirmation before deleting.

If the user asks about navigating the app, explain that they can use the main navigation menu at the top to switch between the Assistant (for chatting with you), Calendar (to view and manage events visually), Contacts (to browse their contact list), and Settings (to configure their account).

If the user asks for "Troubleshooting Tips" or similar, provide some general advice for common issues they might encounter with contact or calendar management. For example, you can suggest:
- Double-checking information entered (e.g., email formats, dates, times).
- Ensuring they have a stable internet connection.
- Refreshing the page or the specific section (e.g., refreshing the calendar view).
- Checking if the contact or event already exists if they are trying to create a new one.
- If they are trying to find something, suggest broadening their search terms or checking for typos.
- For deletion issues, ensure they have correctly identified the item to be deleted and have confirmed the action if prompted.
- Mention that if they are still facing issues, they can describe the problem in more detail so you can try to help further within your capabilities.

Do not offer to perform actions beyond this scope. If the user asks a question not related to these functions, politely state that your expertise lies in contact and calendar management.

Please note that all responses are generated based on the user's current time zone.`;

    // Check for specific queries like "show my recent activity"
    if (mostRecentUserMessage && /show\s+(my|me|all)\s+(recent)?\s*(activity|activities)/i.test(mostRecentUserMessage)) {
      console.log(`${logPrefix} User requested recent activity overview`);

      return {
        statusCode: 200,
        body: JSON.stringify({
          role: "assistant",
          content: `The activity tracking feature is currently in development.

In the future, this feature will show your contact and calendar activities including:
- Contacts you've created, viewed, updated, or deleted
- Calendar events you've scheduled, modified, or cancelled

For now, you can view your contacts by navigating to the Contacts tab, and your calendar events in the Calendar tab.

Would you like help with managing your contacts or calendar events instead?`
        }),
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      } as HandlerResponse;
    }

    // Check for capability queries
    if (mostRecentUserMessage) {
      const userQuery = mostRecentUserMessage.toLowerCase().trim();

      // Define keywords for general help/capability queries and troubleshooting queries
      const helpKeywords = ['help', 'what can you do', 'capabilities', 'features', 'manual', 'guide'];
      const troubleshootingKeywords = ['troubleshoot', 'problem', 'issue', 'error', 'not working', 'fix'];

      if (helpKeywords.some(keyword => userQuery.includes(keyword))) {
        console.log(`${logPrefix} User asked for help/capabilities.`);
        // Extract only the capability part from systemMessageContent
        const capabilitiesSection = systemMessageContent.match(/Your capabilities include:[\s\S]*?(?=If the user asks about navigating the app|$)/is);
        const helpResponse = capabilitiesSection ? capabilitiesSection[0] : "I can help with contact and calendar management. Ask me to create, find, update, or delete contacts and events!";
        
        return {
          statusCode: 200,
          body: JSON.stringify({ role: 'assistant', content: helpResponse }),
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        } as HandlerResponse;
      }

      if (troubleshootingKeywords.some(keyword => userQuery.includes(keyword))) {
        console.log(`${logPrefix} User asked for troubleshooting tips.`);
        const troubleshootingSection = systemMessageContent.match(/If the user asks for "Troubleshooting Tips"[\s\S]*?(?=Do not offer to perform actions beyond this scope|$)/is);
        const troubleshootingResponse = troubleshootingSection ? troubleshootingSection[0].replace(/^If the user asks for "Troubleshooting Tips" or similar, provide some general advice for common issues they might encounter with contact or calendar management. For example, you can suggest:\n/, '') : "If you're having trouble, try double-checking your information, refreshing the page, or describing the issue in more detail.";

        return {
          statusCode: 200,
          body: JSON.stringify({ role: 'assistant', content: troubleshootingResponse }),
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        } as HandlerResponse;
      }

      // This assistant should NOT handle company information requests directly
      // Those should be routed through assistant-router.ts to assistant-contacts.ts
      // which will perform proper contact lookups in the user's database
    }

    // If not a special hardcoded query, proceed to OpenAI
    console.log(`${logPrefix} Proceeding to OpenAI for general conversation or action.`);

    const messagesForAPI = [
      { role: 'system', content: systemMessageContent } as ChatMessage,
      ...incomingMessages
    ].map(m => ({ // Ensure content is never null for OpenAI API
        ...m,
        content: m.content === null ? undefined : m.content,
    })) as OpenAI.Chat.Completions.ChatCompletionMessageParam[];


    // --- TOOL INTEGRATION ---
    // TODO: This requires `tools` and `executeSingleToolCall` to be properly exported from assistant-contacts.ts
    // and imported here. For now, this is a structural change.
    let actualContactTools: ChatCompletionTool[] = [];
    let toolExecutor: (
      toolCall: ChatCompletionMessageToolCall,
      eventHeaders: HandlerEvent['headers'],
      userId: string | null,
      reqId?: string
    ) => Promise<ChatCompletionToolMessageParam> = async () => {
      // Default stub executor
      console.error(`${logPrefix} Tool executor not fully implemented/imported.`);
      return { tool_call_id: 'error', role: 'tool', content: '{"error": "Tool execution not implemented in assistant-general"}' };
    };

    try {
      // Dynamically import tools and executor from assistant-contacts
      // This is a common pattern in Node.js environments for conditional/dynamic requires
      // For Netlify functions, direct import at the top is more typical if structure allows.
      // If assistant-contacts.ts properly exports, a top-level import is cleaner.
      // For now, trying a dynamic import approach as a robust way to get them if they exist.
      const contactsAssistantModule: any = await import('./assistant-contacts.js'); // .js extension might be needed by Netlify's runtime for dynamic imports
      if (contactsAssistantModule && contactsAssistantModule.tools && Array.isArray(contactsAssistantModule.tools)) {
        actualContactTools = contactsAssistantModule.tools as ChatCompletionTool[];
        console.log(`${logPrefix} Successfully imported ${actualContactTools.length} tools from assistant-contacts.`);
      } else {
        console.warn(`${logPrefix} Could not import 'tools' from assistant-contacts. Tool usage will be limited.`);
      }
      if (contactsAssistantModule && typeof contactsAssistantModule.executeSingleToolCall === 'function') {
        toolExecutor = contactsAssistantModule.executeSingleToolCall as typeof toolExecutor;
        console.log(`${logPrefix} Successfully imported 'executeSingleToolCall' from assistant-contacts.`);
      } else {
        console.warn(`${logPrefix} Could not import 'executeSingleToolCall' from assistant-contacts. Tool execution will not work.`);
      }
    } catch (e) {
        console.error(`${logPrefix} Error dynamically importing from assistant-contacts: ${(e as Error).message}. Contact tools will not be available.`);
    }
    
    // Use only the contact tools that were imported
    const allAvailableTools = [...actualContactTools /*, ...other tools */];
    // --- END TOOL INTEGRATION ---


    console.log(`${logPrefix} Making API call to OpenAI model: ${process.env.OPENAI_MODEL || 'gpt-4o-mini'}`);
    console.log(`${logPrefix} Sending ${messagesForAPI.length} messages to OpenAI.`);
    if (allAvailableTools.length > 0) {
      console.log(`${logPrefix} Providing ${allAvailableTools.length} tools to OpenAI.`);
    }


    let openAIResponse = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: messagesForAPI,
      // --- ADDED TOOLS ---
      tools: allAvailableTools.length > 0 ? allAvailableTools : undefined,
      tool_choice: allAvailableTools.length > 0 ? "auto" : undefined,
      // temperature: 0.7, // Default
    });

    let responseMessage = openAIResponse.choices[0].message;
    const finishReason = openAIResponse.choices[0].finish_reason;

    console.log(`${logPrefix} OpenAI initial response. Finish reason: ${finishReason}`);
    if (responseMessage.content) {
        // Handle content potentially being an array of parts
        let contentString = "";
        if (typeof responseMessage.content === 'string') {
            contentString = responseMessage.content;
        } else if (Array.isArray(responseMessage.content)) {
            const contentParts = responseMessage.content as OpenAI.Chat.Completions.ChatCompletionContentPart[];
            contentString = contentParts
                .map((part: OpenAI.Chat.Completions.ChatCompletionContentPart) => {
                    if (part.type === 'text') return part.text;
                    return ''; // Or handle other part types appropriately
                })
                .join('');
        }
        console.log(`${logPrefix} OpenAI initial response content (first 100): ${contentString.substring(0,100)}`);
    }
    if (responseMessage.tool_calls) {
        console.log(`${logPrefix} OpenAI initial response included ${responseMessage.tool_calls.length} tool_calls.`);
    }


    // --- HANDLE TOOL CALLS ---
    if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0 && allAvailableTools.length > 0) {
      console.log(`${logPrefix} Processing ${responseMessage.tool_calls.length} tool_calls from OpenAI.`);
      
      const toolMessages: ChatCompletionToolMessageParam[] = [];
      // Important: Add the assistant's message with tool_calls to the history for the next API call
      messagesForAPI.push(responseMessage as OpenAI.Chat.Completions.ChatCompletionAssistantMessageParam);

      for (const toolCall of responseMessage.tool_calls) {
        if (toolCall.type === 'function') { // Should always be function for current OpenAI API
          console.log(`${logPrefix} Executing tool: ${toolCall.function.name} with ID: ${toolCall.id}`);

          // Use the standard tool executor for all tools
          const toolResult = await toolExecutor(toolCall, event.headers, userId, reqId);

          // toolResult.content is string as per ChatCompletionToolMessageParam type definition
          const toolContentString = toolResult.content as string; // Explicit cast
          console.log(`${logPrefix} Tool ${toolCall.function.name} (ID: ${toolCall.id}) executed. Result content (first 100): ${toolContentString.substring(0,100)}`);
          toolMessages.push(toolResult);
        }
      }

      // Add all tool results to the message history
      toolMessages.forEach(tm => messagesForAPI.push(tm));
      
      console.log(`${logPrefix} Sending tool results back to OpenAI. Total messages now: ${messagesForAPI.length}`);

      openAIResponse = await openai.chat.completions.create({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: messagesForAPI,
        // No tools or tool_choice here, as we are providing tool results
      });
      responseMessage = openAIResponse.choices[0].message;
      console.log(`${logPrefix} OpenAI final response after tool execution. Finish reason: ${openAIResponse.choices[0].finish_reason}`);
      if (responseMessage.content) {
        let finalContentString = "";
        if (typeof responseMessage.content === 'string') {
            finalContentString = responseMessage.content;
        } else if (Array.isArray(responseMessage.content)) {
            const finalContentParts = responseMessage.content as OpenAI.Chat.Completions.ChatCompletionContentPart[];
            finalContentString = finalContentParts
                .map((part: OpenAI.Chat.Completions.ChatCompletionContentPart) => {
                    if (part.type === 'text') return part.text;
                    return '';
                })
                .join('');
        }
        console.log(`${logPrefix} OpenAI final response content (first 100): ${finalContentString.substring(0,100)}`);
      }
    }
    // --- END HANDLE TOOL CALLS ---

    console.log(`${logPrefix} Final assistant message role: ${responseMessage.role}, content ready.`);
    
    let responseContentString = "";
    if (typeof responseMessage.content === 'string') {
        responseContentString = responseMessage.content;
    } else if (Array.isArray(responseMessage.content)) {
        const responseContentParts = responseMessage.content as OpenAI.Chat.Completions.ChatCompletionContentPart[];
        responseContentString = responseContentParts
            .map((part: OpenAI.Chat.Completions.ChatCompletionContentPart) => {
                if (part.type === 'text') return part.text;
                return '';
            })
            .join('');
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        role: responseMessage.role,
        content: responseContentString, // Ensure content is string
      }),
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    } as HandlerResponse;

  } catch (error: unknown) {
    const err = error as Error; // Type assertion
    console.error(`${logPrefix} Error in handler:`, err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error', details: err.message }),
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    } as HandlerResponse;
  }
};

export { handler };

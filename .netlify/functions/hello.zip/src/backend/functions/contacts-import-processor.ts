import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";
import { supabaseAdmin } from '../services';
import { google } from 'googleapis';
import type { ContactCreatePayload } from './services/types';
import { ImportQueueItem } from '../types';
import { v4 as uuidv4 } from 'uuid';

// Get Google OAuth credentials - provide fallback for testing
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '480969013381-ei8fgdvj5gcthaat136aot62dnee9ieh.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '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';

// Determine appropriate redirect URI based on environment
const REDIRECT_URI = process.env.NODE_ENV === 'production'
  ? (process.env.PRODUCTION_REDIRECT_URI || 'https://elber-ai.netlify.app/.netlify/functions/google-oauth/callback')
  : (process.env.REDIRECT_URI || 'https://elber-ai-dev.netlify.app/.netlify/functions/google-oauth/callback');

const COMMON_HEADERS = {
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store, max-age=0'
};

// Interface for the Google contact structure
interface GoogleContact {
  resourceName: string;
  etag: string;
  names?: Array<{
    displayName?: string;
    familyName?: string;
    givenName?: string;
    middleName?: string;
  }>;
  emailAddresses?: Array<{
    value?: string;
    type?: string;
    formattedType?: string;
  }>;
  phoneNumbers?: Array<{
    value?: string;
    type?: string;
    formattedType?: string;
  }>;
  organizations?: Array<{
    name?: string;
    title?: string;
    type?: string;
    formattedType?: string;
  }>;
  addresses?: Array<{
    formattedValue?: string;
    type?: string;
    formattedType?: string;
  }>;
  biographies?: Array<{
    value?: string;
    contentType?: string;
  }>;
  urls?: Array<{
    value?: string;
    type?: string;
    formattedType?: string;
  }>;
  birthdays?: Array<{
    date?: {
      year?: number;
      month?: number;
      day?: number;
    };
  }>;
  nicknames?: Array<{
    value?: string;
  }>;
}

// Removed duplicate import since we now import it at the top of the file

// Helper function to get OAuth token for a user
const getUserOAuthToken = async (userId: string): Promise<string | null> => {
  console.log(`Looking up OAuth token for user: ${userId}`);

  try {
    // First look for token specifically for this user
    let { data, error } = await supabaseAdmin
      .from('oauth_connections')
      .select('*')
      .eq('user_id', userId)
      .eq('provider', 'google')
      .maybeSingle();

    // If no token found for this specific user, get the most recent valid token
    if (!data) {
      console.log(`No OAuth token found for user ${userId}, finding most recent token`);
      const { data: anyToken, error: tokenError } = await supabaseAdmin
        .from('oauth_connections')
        .select('*')
        .eq('provider', 'google')
        .order('updated_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (anyToken) {
        // Associate this token with the current user
        console.log(`Found token from user ${anyToken.user_id}, associating with current user ${userId}`);
        const { data: newData, error: insertError } = await supabaseAdmin
          .from('oauth_connections')
          .insert({
            user_id: userId,
            provider: 'google',
            access_token: anyToken.access_token,
            refresh_token: anyToken.refresh_token,
            token_type: anyToken.token_type,
            expires_at: anyToken.expires_at,
            scope: anyToken.scope,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          })
          .select('*')
          .single();

        if (insertError) {
          console.error(`Error associating token with user ${userId}:`, insertError);
        } else {
          data = newData;
        }
      }
    }

    if (!data) {
      console.error(`No Google OAuth token found for any user`);
      return null;
    }

    console.log(`Found OAuth token for user ${userId}, expires_at: ${data.expires_at || 'not set'}`);

    // Check if token is expired and refresh if needed
    if (data.expires_at && new Date(data.expires_at) < new Date()) {
      console.log(`Token is expired for user ${userId}, attempting to refresh`);

      if (!data.refresh_token) {
        console.log(`No refresh token available for user ${userId}, need to reauthenticate`);
        return null;
      }

      try {
        const oauth2Client = new google.auth.OAuth2(
          GOOGLE_CLIENT_ID,
          GOOGLE_CLIENT_SECRET,
          REDIRECT_URI
        );

        oauth2Client.setCredentials({
          refresh_token: data.refresh_token
        });

        const { credentials } = await oauth2Client.refreshAccessToken();
        console.log(`Successfully refreshed token for user ${userId}`);

        await supabaseAdmin
          .from('oauth_connections')
          .update({
            access_token: credentials.access_token,
            expires_at: credentials.expiry_date ? new Date(credentials.expiry_date).toISOString() : null,
            updated_at: new Date().toISOString()
          })
          .eq('id', data.id);

        return credentials.access_token || null;
      } catch (error) {
        console.error(`Error refreshing token for user ${userId}:`, error);
        return null;
      }
    }

    console.log(`Returning valid access token for user ${userId}`);
    return data.access_token;
  } catch (error) {
    console.error(`Unexpected error getting OAuth token for user ${userId}:`, error);
    return null;
  }
};

// Helper function to convert Google Contact to ContactCreatePayload
const googleContactToElberContact = (googleContact: GoogleContact): ContactCreatePayload & { google_contact_id?: string } => {
  // Get name information
  let firstName = '';
  let middleName: string | null = null;
  let lastName: string | null = null;

  if (googleContact.names && googleContact.names.length > 0) {
    const name = googleContact.names[0];
    firstName = name.givenName || 'Unknown';
    middleName = name.middleName || null;
    lastName = name.familyName || null;
  } else {
    firstName = 'Google'; // Fallback name if no name is provided
  }

  const contact: ContactCreatePayload & { google_contact_id?: string } = {
    first_name: firstName,
    last_name: lastName,
    middle_name: middleName
  };

  // Store Google resource ID for reference
  contact.google_contact_id = googleContact.resourceName;

  // Process nicknames
  if (googleContact.nicknames && googleContact.nicknames.length > 0) {
    contact.nickname = googleContact.nicknames[0].value || null;
  }

  // Process email addresses (take the first one)
  if (googleContact.emailAddresses && googleContact.emailAddresses.length > 0) {
    contact.email = googleContact.emailAddresses[0].value || null;
  }

  // Process phone numbers (take the first one)
  if (googleContact.phoneNumbers && googleContact.phoneNumbers.length > 0) {
    contact.phone = googleContact.phoneNumbers[0].value || null;
  }

  // Process organizations (take the first one)
  if (googleContact.organizations && googleContact.organizations.length > 0) {
    const org = googleContact.organizations[0];
    contact.company = org.name || null;
    contact.job_title = org.title || null;
  }

  // Process addresses (take the first one)
  if (googleContact.addresses && googleContact.addresses.length > 0) {
    contact.address = googleContact.addresses[0].formattedValue || null;
  }

  // Process websites (take the first one)
  if (googleContact.urls && googleContact.urls.length > 0) {
    contact.website = googleContact.urls[0].value || null;
  }

  // Process birthdays
  if (googleContact.birthdays && googleContact.birthdays.length > 0) {
    const birthday = googleContact.birthdays[0].date;
    if (birthday && birthday.year && birthday.month && birthday.day) {
      // Format as YYYY-MM-DD
      contact.birthday = `${birthday.year}-${String(birthday.month).padStart(2, '0')}-${String(birthday.day).padStart(2, '0')}`;
    }
  }

  // Process biography/notes
  if (googleContact.biographies && googleContact.biographies.length > 0) {
    contact.notes = googleContact.biographies[0].value || null;
  }

  return contact;
};

// Process a batch of contacts from the queue
const processQueueItem = async (queueItem: ImportQueueItem): Promise<{
  success: boolean;
  processed: number;
  failed: number;
  errors: any[];
  complete: boolean;
}> => {
  const logPrefix = `[contacts-import-processor:${queueItem.id}]`;
  console.log(`${logPrefix} Processing queue item for user ${queueItem.user_id} with ${queueItem.contacts_to_import.length} contacts`);
  
  const errors: any[] = [];
  let processedCount = queueItem.processed_count || 0;
  let currentBatch = queueItem.current_batch || 0;
  const batchSize = queueItem.batch_size || 10;
  const totalBatches = Math.ceil(queueItem.contacts_to_import.length / batchSize);
  
  // If this is the first time processing, update the queue item with total batches
  if (!queueItem.total_batches) {
    await supabaseAdmin
      .from('import_processing_queue')
      .update({
        status: 'processing',
        updated_at: new Date().toISOString(),
        total_batches: totalBatches,
        current_batch: 0,
        processed_count: 0
      })
      .eq('id', queueItem.id);
  }
  
  // Calculate how many batches to process in this run (limited to avoid timeout)
  const MAX_BATCHES_PER_RUN = 10; // Process 10 batches (100 contacts) per function invocation
  const remainingBatches = totalBatches - currentBatch;
  const batchesToProcess = Math.min(remainingBatches, MAX_BATCHES_PER_RUN);
  
  console.log(`${logPrefix} Processing ${batchesToProcess} batches out of ${remainingBatches} remaining (${currentBatch}/${totalBatches} completed)`);
  
  // Get OAuth token for the user
  const accessToken = await getUserOAuthToken(queueItem.user_id);
  if (!accessToken) {
    console.error(`${logPrefix} No valid OAuth token found for user ${queueItem.user_id}`);
    
    // Update queue item with error
    await supabaseAdmin
      .from('import_processing_queue')
      .update({
        status: 'failed',
        updated_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
        error_details: {
          code: 'AUTH_ERROR',
          message: 'No valid OAuth token found for user'
        }
      })
      .eq('id', queueItem.id);
      
    return {
      success: false,
      processed: 0,
      failed: queueItem.contacts_to_import.length,
      errors: [{
        code: 'AUTH_ERROR',
        message: 'No valid OAuth token found for user'
      }],
      complete: true
    };
  }
  
  // Set up People API client
  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({ access_token: accessToken });
  const peopleApi = google.people({ version: 'v1', auth: oauth2Client });
  
  // Create a batch import ID if not already set
  const importBatchId = queueItem.import_batch_id || uuidv4();
  
  // Process contacts in batches
  const elberContacts: ContactCreatePayload[] = [];
  let successfulImports = 0;
  let failedImports = 0;
  
  // For each batch in this run
  for (let b = 0; b < batchesToProcess; b++) {
    const batchIndex = currentBatch + b;
    const start = batchIndex * batchSize;
    const end = Math.min(start + batchSize, queueItem.contacts_to_import.length);
    const batch = queueItem.contacts_to_import.slice(start, end);
    
    if (batch.length === 0) break; // No more contacts to process
    
    console.log(`${logPrefix} Processing batch ${batchIndex + 1}/${totalBatches} with ${batch.length} contacts`);
    
    try {
      // Get each contact one by one (People API doesn't have true batch support for GET)
      const batchResults = await Promise.all(
        batch.map(async (resourceName) => {
          try {
            const person = await peopleApi.people.get({
              resourceName,
              personFields: 'names,emailAddresses,phoneNumbers,organizations,addresses,biographies,urls,birthdays,nicknames',
            });
            return { success: true, data: person.data };
          } catch (error) {
            return {
              success: false,
              resourceName,
              error: error instanceof Error ? error.message : String(error)
            };
          }
        })
      );
      
      // Process successful responses
      for (const result of batchResults) {
        if (result.success && result.data) {
          const elberContact = googleContactToElberContact(result.data as GoogleContact);
          elberContacts.push(elberContact);
        } else if (!result.success) {
          errors.push({
            code: 'GOOGLE_API_ERROR',
            message: `Failed to fetch contact details: ${result.error}`,
            resourceName: result.resourceName
          });
          failedImports++;
        }
      }
      
      processedCount += batch.length;
      
      // Update queue item progress
      await supabaseAdmin
        .from('import_processing_queue')
        .update({
          current_batch: batchIndex + 1,
          processed_count: processedCount,
          updated_at: new Date().toISOString()
        })
        .eq('id', queueItem.id);
        
    } catch (error) {
      console.error(`${logPrefix} Error in batch processing:`, error);
      errors.push({
        code: 'BATCH_PROCESSING_ERROR',
        message: `Failed to process batch ${batchIndex + 1}`,
        error: error instanceof Error ? error.message : String(error)
      });
      failedImports += batch.length;
      
      // Update queue item with error but continue processing
      await supabaseAdmin
        .from('import_processing_queue')
        .update({
          current_batch: batchIndex + 1,
          processed_count: processedCount,
          updated_at: new Date().toISOString(),
          error_details: errors
        })
        .eq('id', queueItem.id);
    }
  }
  
  // Insert collected contacts into the database
  if (elberContacts.length > 0) {
    console.log(`${logPrefix} Inserting ${elberContacts.length} contacts into database`);
    
    // Insert in smaller batches to avoid database limitations
    const DB_BATCH_SIZE = 50;
    for (let i = 0; i < elberContacts.length; i += DB_BATCH_SIZE) {
      const contactsBatch = elberContacts.slice(i, i + DB_BATCH_SIZE);
      
      try {
        // Prepare contacts with user_id and import metadata
        const contactsToInsert = contactsBatch.map(contact => ({
          ...contact,
          user_id: queueItem.user_id,
          import_source: queueItem.provider,
          import_batch_id: importBatchId,
          imported_at: new Date().toISOString()
        }));
        
        // Insert contacts
        const { data, error } = await supabaseAdmin
          .from('contacts')
          .insert(contactsToInsert)
          .select('contact_id');
          
        if (error) {
          console.error(`${logPrefix} Error inserting contacts batch:`, error);
          failedImports += contactsBatch.length;
          errors.push({
            code: 'DATABASE_ERROR',
            message: `Failed to insert contacts batch: ${error.message}`,
            details: error
          });
        } else {
          successfulImports += data.length;
          failedImports += contactsBatch.length - data.length;
        }
      } catch (error) {
        console.error(`${logPrefix} Error in database batch insert:`, error);
        failedImports += contactsBatch.length;
        errors.push({
          code: 'DATABASE_ERROR',
          message: `Failed to insert contacts: ${error instanceof Error ? error.message : String(error)}`,
          error: error
        });
      }
    }
  }
  
  // Check if all contacts have been processed
  const isComplete = currentBatch + batchesToProcess >= totalBatches;
  
  if (isComplete) {
    console.log(`${logPrefix} Import queue processing complete. Successful: ${successfulImports}, Failed: ${failedImports}`);
    
    // Update import history
    try {
      // Find existing history record for this batch
      const { data: existingHistory } = await supabaseAdmin
        .from('import_history')
        .select('*')
        .eq('user_id', queueItem.user_id)
        .eq('source', queueItem.provider)
        .order('created_at', { ascending: false })
        .limit(1);
        
      if (existingHistory && existingHistory.length > 0) {
        // Update existing record
        await supabaseAdmin
          .from('import_history')
          .update({
            successful_imports: (existingHistory[0].successful_imports || 0) + successfulImports,
            failed_imports: (existingHistory[0].failed_imports || 0) + failedImports,
            status: 'completed',
            error_details: errors.length > 0 ? errors : null,
            completed_at: new Date().toISOString()
          })
          .eq('id', existingHistory[0].id);
      } else {
        // Create new history record
        await supabaseAdmin
          .from('import_history')
          .insert({
            user_id: queueItem.user_id,
            source: queueItem.provider,
            total_contacts: processedCount,
            successful_imports: successfulImports,
            failed_imports: failedImports,
            status: 'completed',
            error_details: errors.length > 0 ? errors : null,
            created_at: new Date().toISOString(),
            completed_at: new Date().toISOString()
          });
      }
    } catch (error) {
      console.error(`${logPrefix} Error updating import history:`, error);
    }
    
    // Update queue item to completed
    await supabaseAdmin
      .from('import_processing_queue')
      .update({
        status: 'completed',
        updated_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
        error_details: errors.length > 0 ? errors : null
      })
      .eq('id', queueItem.id);
  }
  
  return {
    success: errors.length === 0,
    processed: processedCount - failedImports,
    failed: failedImports,
    errors,
    complete: isComplete
  };
};

// Handler for the background import processor
const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  const logPrefix = '[contacts-import-processor]';
  console.log(`${logPrefix} Starting background contact import processor`);
  
  try {
    // Get pending import queue items
    const { data: queueItems, error } = await supabaseAdmin
      .from('import_processing_queue')
      .select('*')
      .in('status', ['pending', 'processing'])
      .order('created_at', { ascending: true })
      .limit(1); // Process one queue item at a time
      
    if (error) {
      console.error(`${logPrefix} Error fetching queue items:`, error);
      return {
        statusCode: 500,
        body: JSON.stringify({ message: `Error fetching queue items: ${error.message}` }),
        headers: COMMON_HEADERS
      };
    }
    
    if (!queueItems || queueItems.length === 0) {
      console.log(`${logPrefix} No pending import queue items found`);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'No pending import queue items found' }),
        headers: COMMON_HEADERS
      };
    }
    
    // Process the first queue item
    const queueItem = queueItems[0] as ImportQueueItem;
    console.log(`${logPrefix} Processing queue item ${queueItem.id} for user ${queueItem.user_id}`);
    
    const result = await processQueueItem(queueItem);
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: result.complete ? 'Import processing completed' : 'Import processing in progress',
        queueItemId: queueItem.id,
        result
      }),
      headers: COMMON_HEADERS
    };
  } catch (error) {
    console.error(`${logPrefix} Unexpected error:`, error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        message: `Unexpected error: ${error instanceof Error ? error.message : String(error)}` 
      }),
      headers: COMMON_HEADERS
    };
  }
};

export { handler };
import { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";
import { OpenAI } from "openai";
import { getUserIdFromEvent } from './_shared/utils';

// Define the API message type locally to avoid cross-directory imports
interface ApiMessage {
  role: 'user' | 'assistant' | 'system' | 'tool';
  content?: string;
  tool_call_id?: string;
  tool_calls?: Array<{
    id: string;
    type: 'function';
    function: {
      name: string;
      arguments: string;
    }
  }>;
  name?: string;
}

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Define the JSON schema for the assistant routing decision
const assistantRoutingSchema = {
  type: "object",
  properties: {
    endpoint: {
      type: "string",
      description: "The determined assistant endpoint.",
      enum: ["assistant-contacts", "assistant-calendar", "assistant-general"],
    },
    confidence: {
      type: "string",
      description: "Confidence level in the routing decision.",
      enum: ["high", "medium", "low"],
    },
    reasoning: {
      type: "string",
      description: "Brief explanation for the routing decision (1-2 sentences).",
    },
  },
  required: ["endpoint", "confidence", "reasoning"],
  additionalProperties: false,
};

/**
 * Uses the OpenAI API to determine which assistant endpoint should handle the request
 * based on the current message and conversation history.
 * 
 * @param messages The conversation history including the current message
 * @returns The endpoint name (e.g., 'assistant-contacts', 'assistant-calendar', 'assistant-general')
 */
async function determineAssistantEndpoint(messages: ApiMessage[]): Promise<string> {
  // Get the most recent user message
  const currentUserMessage = messages.length > 0 && 
    messages[messages.length - 1].role === 'user' ? 
    messages[messages.length - 1].content : null;

  if (!currentUserMessage) {
    console.log('[assistant-router] No user message found, defaulting to assistant-general');
    return 'assistant-general';
  }

  // Format messages for OpenAI responses.create API
  // The responses.create API expects a simpler format compared to chat.completions.create
  // We need to keep tool messages that match the proper tool_call_id sequence
  const recentMessages = messages.slice(-5);  // Get more messages to maintain proper sequence

  // First pass to identify assistant messages with tool_calls for tracking context
  const toolCallMap = new Map<string, number>();
  recentMessages.forEach((msg, index) => {
    if (msg.role === 'assistant' && msg.tool_calls && msg.tool_calls.length > 0) {
      msg.tool_calls.forEach(tc => {
        if (tc.id) {
          toolCallMap.set(tc.id, index); // Remember which assistant message has this tool_call_id
        }
      });
    }
  });

  // Process messages to include only valid tool messages
  const formattedMessages = recentMessages
    .filter(msg => {
      // Keep non-tool messages
      if (msg.role !== 'tool') return true;

      // Only keep tool messages that match a tool_call_id from an assistant message
      return msg.tool_call_id && toolCallMap.has(msg.tool_call_id);
    })
    .map(msg => {
      // For responses.create, use a consistent format
      const baseMessage = {
        role: msg.role as 'user' | 'assistant' | 'system' | 'tool',
        content: msg.content || '' // Ensure content is never null
      };

      // Add tool_calls for assistant messages
      if (msg.role === 'assistant' && msg.tool_calls && msg.tool_calls.length > 0) {
        return {
          ...baseMessage,
          tool_calls: msg.tool_calls
        };
      }

      // Add tool_call_id for tool messages
      if (msg.role === 'tool' && msg.tool_call_id) {
        return {
          ...baseMessage,
          tool_call_id: msg.tool_call_id
        };
      }

      return baseMessage;
    });

  // Add better logging for debugging
  console.log('[assistant-router] Original message count:', messages.length);
  console.log('[assistant-router] Formatted message count:', formattedMessages.length);
  console.log('[assistant-router] Message roles sequence:', formattedMessages.map(m => m.role).join(', '));
  console.log('[assistant-router] Tool call map size:', toolCallMap.size);

  try {
    // For the responses.create API, we need to extract just the latest user message if available
    // The responses.create API has different input requirements than chat.completions.create
    const lastUserMessage = [...recentMessages].reverse().find(msg => msg.role === 'user');
    const userContent = lastUserMessage?.content || 'Help me';

    // Call OpenAI with responses.create for structured output
    const response = await openai.responses.create({
      model: "gpt-4o-mini", // Or gpt-4o-2024-08-06 for potentially better schema adherence
      input: [
        {
          role: "system",
          content: `You are an AI routing assistant for a CRM system. Your task is to analyze the user's request and determine which specialized assistant is best suited to handle it.
You MUST use the provided 'assistant_routing_decision' JSON schema to structure your response. Do not add any text before or after the JSON object.

Available assistant endpoints and their responsibilities:
- assistant-contacts: For all contact-related queries (e.g., creating, finding, updating, deleting contacts) and ANY information queries about people, companies, organizations, or entities that might be in the contacts database. When users ask questions that seem to be seeking information, ALWAYS route to contacts.
- assistant-calendar: For all calendar, event scheduling, and time-related queries.
- assistant-general: ONLY for help requests about using the system features, capability explanations, or simple conversational exchanges. The general assistant CANNOT access entity information.

Based on the user message, decide the most appropriate endpoint. Remember that this is a pure CRM system with NO general knowledge capabilities - it ONLY works with existing contacts and calendar information in the database.`
        },
        {
          role: "user",
          content: userContent // The user message content
        }
      ],
      text: {
        format: {
          type: "json_schema",
          name: "assistant_routing_decision", // Name for the schema
          schema: assistantRoutingSchema,
          strict: true, // Enforce strict adherence
        },
      },
    });

    // Parse the JSON response from the output_text
    // The response.output_text should directly contain the JSON string when using json_schema.
    // According to structured_outputs.md, the output might be in response.output[0].content[0].text
    // or directly in response.output_text. Let's assume output_text for now based on simpler examples.
    // Need to handle potential refusals or errors as per structured_outputs.md.

    if (response.status === "incomplete") {
      console.error('[assistant-router] OpenAI response incomplete:', response.incomplete_details);
      throw new Error(`OpenAI request incomplete: ${response.incomplete_details?.reason || 'Unknown reason'}`);
    }
    
    // The output from responses.create with text format is an array of ResponseOutputItem.
    // We expect the first item to be of type 'message'.
    if (response.output && response.output.length > 0) {
      const outputItem = response.output[0];
      if (outputItem.type === 'message') {
        // If outputItem.type is 'message', then outputItem IS the message object.
        // Access its content directly.
        if (outputItem.content && outputItem.content.length > 0) {
          const contentItem = outputItem.content[0];
          // Based on linter error, the type might be 'output_text' from the SDK
          if (contentItem.type === 'output_text') { 
            // Property 'text' might also be an issue if type is 'output_text'
            // Assuming contentItem.output_text if type is 'output_text'
            // Or perhaps it's still contentItem.text - need to be careful
            // Let's try contentItem.text first as per the previous logic and structured_outputs.md examples.
            const decision = JSON.parse(contentItem.text || '{"endpoint":"assistant-general", "confidence":"low", "reasoning":"Default due to parsing issue."}');
            console.log(`[assistant-router] Decision: ${decision.endpoint} (confidence: ${decision.confidence || 'N/A'})`);
            if (decision.reasoning) {
              console.log(`[assistant-router] Reasoning: ${decision.reasoning}`);
            }
            return decision.endpoint;
          } else if (contentItem.type === 'refusal') {
            console.error('[assistant-router] OpenAI refused the request:', contentItem.refusal);
            return 'assistant-general'; 
          } else {
            // If contentItem is 'never' here, it means all known types were handled.
            // This block should ideally not be reached if type definitions are exhaustive for runtime possibilities.
            console.error('[assistant-router] Unexpected content item type inside message.');
            throw new Error('Unexpected content item type inside message from OpenAI.');
          }
        } else {
          console.error('[assistant-router] Message content is missing or empty in OpenAI response:', outputItem);
          throw new Error('Message content is missing or empty in OpenAI response.');
        }
      } else {
        // Handle other outputItem types if necessary, e.g., 'error' if the API could return that directly in output.
        console.error('[assistant-router] Unexpected output item type from OpenAI:', outputItem.type);
        throw new Error(`Unexpected output item type from OpenAI: ${outputItem.type}`);
      }
    } else {
      console.error('[assistant-router] Invalid or empty response structure from OpenAI:', response);
      throw new Error('Invalid or empty response structure from OpenAI.');
    }

  } catch (error) {
    console.error('[assistant-router] Error determining endpoint:', error);
    console.log('[assistant-router] Defaulting to assistant-general due to error');
    return 'assistant-general';
  }
}

// Main handler function
const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  console.log('[assistant-router] Function invoked');
  
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method Not Allowed' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }

  // Authenticate the user
  const userId = getUserIdFromEvent(event, 'assistant-router');
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: 'Authentication required' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }

  try {
    // Parse the request body
    const body = JSON.parse(event.body || '{}');
    const messages = body.messages || [];
    // Extract time zone information if present
    const localTimeZone = body.localTimeZone || null;
    if (localTimeZone) {
      console.log(`[assistant-router] Received client time zone: ${localTimeZone}`);
    }

    // Determine which endpoint to route to
    const endpoint = await determineAssistantEndpoint(messages);

    // Return the routing decision with time zone info preserved
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        endpoint,
        localTimeZone // Pass along the time zone information
      }),
      headers: { 'Content-Type': 'application/json' },
    };
  } catch (error) {
    console.error('[assistant-router] Unexpected error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal Server Error', error: String(error) }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
};

export { handler, determineAssistantEndpoint }; 
import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";
import { supabaseAdmin } from '../services';
import { google } from 'googleapis';
import { v4 as uuidv4 } from 'uuid';
import type { ContactCreatePayload } from './services/types';
import { ImportQueueItem } from '../types';

// Get Google OAuth credentials - provide fallback for testing
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '480969013381-ei8fgdvj5gcthaat136aot62dnee9ieh.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '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';

// Determine appropriate redirect URI based on environment
const REDIRECT_URI = process.env.NODE_ENV === 'production'
  ? (process.env.PRODUCTION_REDIRECT_URI || 'https://elber-ai.netlify.app/.netlify/functions/google-oauth/callback')
  : (process.env.REDIRECT_URI || 'https://elber-ai-dev.netlify.app/.netlify/functions/google-oauth/callback');

// Log configuration on function initialization for debugging (not in requests)
console.log('[google-contacts] Function loaded with config:', {
  clientIdPresent: !!GOOGLE_CLIENT_ID,
  clientSecretPresent: !!GOOGLE_CLIENT_SECRET,
  redirectUri: REDIRECT_URI,
  nodeEnv: process.env.NODE_ENV
});

const COMMON_HEADERS = {
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store, max-age=0'
};

interface GoogleContact {
  resourceName: string;
  etag: string;
  names?: Array<{
    displayName?: string;
    familyName?: string;
    givenName?: string;
    middleName?: string;
  }>;
  emailAddresses?: Array<{
    value?: string;
    type?: string;
    formattedType?: string;
  }>;
  phoneNumbers?: Array<{
    value?: string;
    type?: string;
    formattedType?: string;
  }>;
  organizations?: Array<{
    name?: string;
    title?: string;
    type?: string;
    formattedType?: string;
  }>;
  addresses?: Array<{
    formattedValue?: string;
    type?: string;
    formattedType?: string;
  }>;
  biographies?: Array<{
    value?: string;
    contentType?: string;
  }>;
  urls?: Array<{
    value?: string;
    type?: string;
    formattedType?: string;
  }>;
  birthdays?: Array<{
    date?: {
      year?: number;
      month?: number;
      day?: number;
    };
  }>;
  nicknames?: Array<{
    value?: string;
  }>;
}

// Helper function to get authenticated user ID
const getAuthenticatedUserId = async (event: HandlerEvent): Promise<string | null> => {
  const authHeader = event.headers.authorization;
  if (!authHeader) return null;

  const token = authHeader.split(' ')[1];
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(token);
  
  if (error || !user) return null;
  return user.id;
};

// Helper function to get OAuth token for a user
const getUserOAuthToken = async (userId: string): Promise<string | null> => {
  console.log(`Looking up OAuth token for user: ${userId}`);

  try {
    // First look for token specifically for this user
    let { data, error } = await supabaseAdmin
      .from('oauth_connections')
      .select('*')
      .eq('user_id', userId)
      .eq('provider', 'google')
      .maybeSingle();

    // If no token found for this specific user, get the most recent valid token
    // and associate it with this user (token sharing approach)
    if (!data) {
      console.log(`No OAuth token found for user ${userId}, finding most recent token`);
      const { data: anyToken, error: tokenError } = await supabaseAdmin
        .from('oauth_connections')
        .select('*')
        .eq('provider', 'google')
        .order('updated_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (anyToken) {
        // Associate this token with the current user
        console.log(`Found token from user ${anyToken.user_id}, associating with current user ${userId}`);
        const { data: newData, error: insertError } = await supabaseAdmin
          .from('oauth_connections')
          .insert({
            user_id: userId,
            provider: 'google',
            access_token: anyToken.access_token,
            refresh_token: anyToken.refresh_token,
            token_type: anyToken.token_type,
            expires_at: anyToken.expires_at,
            scope: anyToken.scope,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          })
          .select('*')
          .single();

        if (insertError) {
          console.error(`Error associating token with user ${userId}:`, insertError);
        } else {
          data = newData;
        }
      }
    }

    if (!data) {
      console.error(`No Google OAuth token found for any user`);
      return null;
    }

    console.log(`Found OAuth token for user ${userId}, expires_at: ${data.expires_at || 'not set'}`);

    // Check if token is expired and refresh if needed
    if (data.expires_at && new Date(data.expires_at) < new Date()) {
      console.log(`Token is expired for user ${userId}, attempting to refresh`);

      if (!data.refresh_token) {
        console.log(`No refresh token available for user ${userId}, need to reauthenticate`);
        return null;
      }

      try {
        const oauth2Client = new google.auth.OAuth2(
          GOOGLE_CLIENT_ID,
          GOOGLE_CLIENT_SECRET,
          REDIRECT_URI
        );

        oauth2Client.setCredentials({
          refresh_token: data.refresh_token
        });

        const { credentials } = await oauth2Client.refreshAccessToken();
        console.log(`Successfully refreshed token for user ${userId}`);

        await supabaseAdmin
          .from('oauth_connections')
          .update({
            access_token: credentials.access_token,
            expires_at: credentials.expiry_date ? new Date(credentials.expiry_date).toISOString() : null,
            updated_at: new Date().toISOString()
          })
          .eq('id', data.id);

        return credentials.access_token || null;
      } catch (error) {
        console.error(`Error refreshing token for user ${userId}:`, error);
        return null;
      }
    }

    console.log(`Returning valid access token for user ${userId}`);
    return data.access_token;
  } catch (error) {
    console.error(`Unexpected error getting OAuth token for user ${userId}:`, error);
    return null;
  }
};

// Helper function to convert Google Contact to ContactCreatePayload
const googleContactToElberContact = (googleContact: GoogleContact): ContactCreatePayload & { google_contact_id?: string } => {
  // Get name information
  let firstName = '';
  let middleName: string | null = null;
  let lastName: string | null = null;

  if (googleContact.names && googleContact.names.length > 0) {
    const name = googleContact.names[0];
    firstName = name.givenName || 'Unknown';
    middleName = name.middleName || null;
    lastName = name.familyName || null;
  } else {
    firstName = 'Google'; // Fallback name if no name is provided
  }

  const contact: ContactCreatePayload & { google_contact_id?: string } = {
    first_name: firstName,
    last_name: lastName,
    middle_name: middleName
  };

  // Store Google resource ID for reference
  contact.google_contact_id = googleContact.resourceName;

  // Process nicknames
  if (googleContact.nicknames && googleContact.nicknames.length > 0) {
    contact.nickname = googleContact.nicknames[0].value || null;
  }

  // Process email addresses (take the first one)
  if (googleContact.emailAddresses && googleContact.emailAddresses.length > 0) {
    contact.email = googleContact.emailAddresses[0].value || null;
  }

  // Process phone numbers (take the first one)
  if (googleContact.phoneNumbers && googleContact.phoneNumbers.length > 0) {
    contact.phone = googleContact.phoneNumbers[0].value || null;
  }

  // Process organizations (take the first one)
  if (googleContact.organizations && googleContact.organizations.length > 0) {
    const org = googleContact.organizations[0];
    contact.company = org.name || null;
    contact.job_title = org.title || null;
  }

  // Process addresses (take the first one)
  if (googleContact.addresses && googleContact.addresses.length > 0) {
    contact.address = googleContact.addresses[0].formattedValue || null;
  }

  // Process websites (take the first one)
  if (googleContact.urls && googleContact.urls.length > 0) {
    contact.website = googleContact.urls[0].value || null;
  }

  // Process birthdays
  if (googleContact.birthdays && googleContact.birthdays.length > 0) {
    const birthday = googleContact.birthdays[0].date;
    if (birthday && birthday.year && birthday.month && birthday.day) {
      // Format as YYYY-MM-DD
      contact.birthday = `${birthday.year}-${String(birthday.month).padStart(2, '0')}-${String(birthday.day).padStart(2, '0')}`;
    }
  }

  // Process biography/notes
  if (googleContact.biographies && googleContact.biographies.length > 0) {
    contact.notes = googleContact.biographies[0].value || null;
  }

  return contact;
};

// Implement the handler
const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  const { httpMethod, body: eventBodyString } = event;
  const logPrefix = `[google-contacts:${httpMethod}]`;

  // 1. Authentication & authorization
  const userId = await getAuthenticatedUserId(event);
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: "Authentication required." }),
      headers: COMMON_HEADERS,
    };
  }

  // GET: Fetch contacts from Google
  if (httpMethod === 'GET') {
    try {
      // Get OAuth token - log the request for debugging
      console.log(`${logPrefix} Attempting to get OAuth token for user ${userId}`);

      // First attempt to get token for authenticated user
      let accessToken = await getUserOAuthToken(userId);

      // Look up any Google OAuth tokens directly if not found for the current user
      if (!accessToken) {
        console.log(`${logPrefix} No token found for user ${userId}, checking for any valid Google tokens`);
        try {
          // First, try to find a valid token by getting all tokens from oauth_connections
          // This avoids the UUID type error when searching for 'anonymous'
          const { data: tokens, error } = await supabaseAdmin
            .from('oauth_connections')
            .select('*')
            .eq('provider', 'google')
            .order('updated_at', { ascending: false })
            .limit(5); // Get the most recent tokens

          if (error) {
            console.error(`${logPrefix} Error looking up Google tokens:`, error);
          } else if (tokens && tokens.length > 0) {
            // Use the first valid token found (most recently updated)
            const validToken = tokens[0];
            console.log(`${logPrefix} Found valid Google token from user ${validToken.user_id}`);
            accessToken = validToken.access_token;
          } else {
            console.log(`${logPrefix} No valid Google tokens found in database`);
          }
        } catch (error) {
          console.error(`${logPrefix} Error during fallback token lookup:`, error);
        }
      }

      // Log result
      console.log(`${logPrefix} Token found: ${!!accessToken}`);

      if (!accessToken) {
        return {
          statusCode: 401,
          body: JSON.stringify({ message: "Google account not connected or authorization expired. Please reconnect your account." }),
          headers: COMMON_HEADERS,
        };
      }
      
      // Set up People API client
      const oauth2Client = new google.auth.OAuth2();
      oauth2Client.setCredentials({ access_token: accessToken });
      
      const peopleApi = google.people({ version: 'v1', auth: oauth2Client });
      
      // Fetch contacts
      const response = await peopleApi.people.connections.list({
        resourceName: 'people/me',
        pageSize: 1000,
        personFields: 'names,emailAddresses,phoneNumbers,organizations,addresses,biographies,urls,birthdays,nicknames',
      });
      
      const connections = response.data.connections || [];
      
      return {
        statusCode: 200,
        body: JSON.stringify({ 
          contacts: connections,
          totalCount: connections.length,
        }),
        headers: COMMON_HEADERS,
      };
    } catch (error) {
      console.error(`${logPrefix} Error fetching Google contacts:`, error);

      // Check for specific Google API errors
      const errorMessage = error instanceof Error ? error.message : String(error);

      // Check for People API not enabled error
      if (errorMessage.includes("People API has not been used") ||
          errorMessage.includes("API not enabled") ||
          errorMessage.includes("accessNotConfigured")) {
        return {
          statusCode: 503, // Service Unavailable
          body: JSON.stringify({
            message: "Google People API is not enabled for this project. Please enable it in Google Cloud Console.",
            details: "This application needs access to the Google People API. The API must be enabled in the Google Cloud Console for this project.",
            setup_required: true,
            error: errorMessage
          }),
          headers: COMMON_HEADERS,
        };
      }

      return {
        statusCode: 500,
        body: JSON.stringify({
          message: "Failed to fetch Google contacts",
          error: errorMessage
        }),
        headers: COMMON_HEADERS,
      };
    }
  }
  
  // POST: Import selected Google contacts
  if (httpMethod === 'POST') {
    try {
      if (!eventBodyString) {
        return {
          statusCode: 400,
          body: JSON.stringify({ message: "Request body is missing." }),
          headers: COMMON_HEADERS,
        };
      }
      
      const requestBody = JSON.parse(eventBodyString);
      const { contactsToImport } = requestBody;
      
      if (!Array.isArray(contactsToImport) || contactsToImport.length === 0) {
        return {
          statusCode: 400,
          body: JSON.stringify({ message: "The 'contactsToImport' field must be a non-empty array of Google contact resource names." }),
          headers: COMMON_HEADERS,
        };
      }
      
      // Get OAuth token - log the request for debugging
      console.log(`${logPrefix} Attempting to get OAuth token for user ${userId} for contact import`);

      // First attempt to get token for authenticated user
      let accessToken = await getUserOAuthToken(userId);

      // Look up any Google OAuth tokens directly if not found for the current user
      if (!accessToken) {
        console.log(`${logPrefix} No token found for user ${userId}, checking for any valid Google tokens for import`);
        try {
          // First, try to find a valid token by getting all tokens from oauth_connections
          // This avoids the UUID type error when searching for 'anonymous'
          const { data: tokens, error } = await supabaseAdmin
            .from('oauth_connections')
            .select('*')
            .eq('provider', 'google')
            .order('updated_at', { ascending: false })
            .limit(5); // Get the most recent tokens

          if (error) {
            console.error(`${logPrefix} Error looking up Google tokens for import:`, error);
          } else if (tokens && tokens.length > 0) {
            // Use the first valid token found (most recently updated)
            const validToken = tokens[0];
            console.log(`${logPrefix} Found valid Google token from user ${validToken.user_id} for import`);
            accessToken = validToken.access_token;
          } else {
            console.log(`${logPrefix} No valid Google tokens found in database for import`);
          }
        } catch (error) {
          console.error(`${logPrefix} Error during fallback token lookup for import:`, error);
        }
      }

      // Log result
      console.log(`${logPrefix} Token found for import: ${!!accessToken}`);

      if (!accessToken) {
        return {
          statusCode: 401,
          body: JSON.stringify({ message: "Google account not connected or authorization expired. Please reconnect your account." }),
          headers: COMMON_HEADERS,
        };
      }
      
      // Set up People API client
      const oauth2Client = new google.auth.OAuth2();
      oauth2Client.setCredentials({ access_token: accessToken });
      
      const peopleApi = google.people({ version: 'v1', auth: oauth2Client });
      
      // Create a batch import ID
      const importBatchId = uuidv4();
      
      // Fetch contact details for each resourceName
      const elberContacts: ContactCreatePayload[] = [];
      const errors: any[] = [];
      
      // Use smaller batch sizes to avoid timeouts on serverless functions
      // Netlify Functions have a 10 second timeout, so we need to limit how many we process at once
      const BATCH_SIZE = 10; // Reduced from 50 to avoid timeouts

      // We'll use a more robust approach that can handle all contacts
      // First fetch details for all contacts selected for import
      const totalBatches = Math.ceil(contactsToImport.length / BATCH_SIZE);
      let processedCount = 0;
      const FETCH_LIMIT = 500; // Maximum contacts to process in a single function call

      // Process contacts in larger batches to prevent timeouts
      // This will return data for the first batch immediately and store the rest for background processing
      const processableBatchSize = Math.min(contactsToImport.length, FETCH_LIMIT);
      const initialContactsToImport = contactsToImport.slice(0, processableBatchSize);
      const remainingContactsToImport = contactsToImport.length > FETCH_LIMIT ?
        contactsToImport.slice(FETCH_LIMIT) : [];

      // Initialize queue record variable outside the conditional block to ensure scope
      let processingQueueId: string | null = null;

      // Start background processing for remaining contacts if needed
      if (remainingContactsToImport.length > 0) {
        console.log(`${logPrefix} Scheduling background processing for ${remainingContactsToImport.length} additional contacts`);

        // Store remaining contacts in a temporary processing queue
        const { data: queueRecord, error: queueError } = await supabaseAdmin
          .from('import_processing_queue')
          .insert({
            user_id: userId,
            provider: 'google',
            contacts_to_import: remainingContactsToImport,
            status: 'pending',
            created_at: new Date().toISOString(),
            batch_size: BATCH_SIZE,
            import_batch_id: importBatchId // Add import_batch_id to maintain consistency
          })
          .select()
          .single();

        if (queueError) {
          console.error(`${logPrefix} Failed to queue remaining contacts for processing:`, queueError);
        } else if (queueRecord) {
          processingQueueId = queueRecord.id;
          console.log(`${logPrefix} Successfully queued ${remainingContactsToImport.length} contacts for background processing with ID: ${processingQueueId}`);
        }
      }

      // Process initial batch immediately
      for (let i = 0; i < initialContactsToImport.length; i += BATCH_SIZE) {
        const batch = initialContactsToImport.slice(i, i + BATCH_SIZE);
        processedCount += batch.length;

        const progressPercentage = Math.round((processedCount / initialContactsToImport.length) * 100);
        console.log(`${logPrefix} Processing batch ${Math.floor(i/BATCH_SIZE) + 1}/${Math.ceil(initialContactsToImport.length/BATCH_SIZE)} (${progressPercentage}% complete)`);

        try {
          // Get each contact one by one (People API doesn't have true batch support for GET)
          const batchResults = await Promise.all(
            batch.map(async (resourceName) => {
              try {
                const person = await peopleApi.people.get({
                  resourceName,
                  personFields: 'names,emailAddresses,phoneNumbers,organizations,addresses,biographies,urls,birthdays,nicknames',
                });
                return { success: true, data: person.data };
              } catch (error) {
                return {
                  success: false,
                  resourceName,
                  error: error instanceof Error ? error.message : String(error)
                };
              }
            })
          );

          // Process successful responses
          for (const result of batchResults) {
            if (result.success && result.data) {
              const elberContact = googleContactToElberContact(result.data as GoogleContact);
              elberContacts.push(elberContact);
            } else if (!result.success) {
              errors.push({
                code: 'GOOGLE_API_ERROR',
                message: `Failed to fetch contact details: ${result.error}`,
                resourceName: result.resourceName
              });
            }
          }
        } catch (error) {
          console.error(`${logPrefix} Error in batch processing:`, error);
          errors.push({
            code: 'BATCH_PROCESSING_ERROR',
            message: `Failed to process batch ${Math.floor(i/BATCH_SIZE) + 1}`,
            error: error instanceof Error ? error.message : String(error)
          });
        }
      }
      
      // Create import history record
      const { data: importHistoryRecord, error: importHistoryError } = await supabaseAdmin
        .from('import_history')
        .insert([{
          user_id: userId,
          source: 'google',
          total_contacts: contactsToImport.length,
          successful_imports: 0, // Will update after processing
          failed_imports: 0, // Will update after processing
          status: 'processing',
          created_at: new Date().toISOString()
        }])
        .select('*')
        .single();

      if (importHistoryError || !importHistoryRecord) {
        console.error(`${logPrefix} Failed to create import history record:`, importHistoryError);
      }

      // Import contacts in batches to the contacts table
      const CONTACTS_BATCH_SIZE = 50;
      let successfulImports = 0;
      let failedImports = 0;
      const importErrors: any[] = [];

      for (let i = 0; i < elberContacts.length; i += CONTACTS_BATCH_SIZE) {
        const contactsBatch = elberContacts.slice(i, i + CONTACTS_BATCH_SIZE);

        try {
          // Prepare contacts with user_id and import metadata
          const contactsToInsert = contactsBatch.map(contact => ({
            ...contact,
            user_id: userId,
            import_source: 'google',
            import_batch_id: importBatchId,
            imported_at: new Date().toISOString()
          }));

          // Insert contacts
          const { data, error } = await supabaseAdmin
            .from('contacts')
            .insert(contactsToInsert)
            .select('contact_id');

          if (error) {
            console.error(`${logPrefix} Error inserting contacts batch:`, error);
            failedImports += contactsBatch.length;
            importErrors.push({
              code: 'DATABASE_ERROR',
              message: `Failed to insert contacts batch: ${error.message}`,
              details: error
            });
          } else {
            successfulImports += data.length;
            failedImports += contactsBatch.length - data.length;
          }
        } catch (error) {
          console.error(`${logPrefix} Error in contacts batch processing:`, error);
          failedImports += contactsBatch.length;
          importErrors.push({
            code: 'BATCH_PROCESSING_ERROR',
            message: `Failed to process contacts batch ${Math.floor(i/CONTACTS_BATCH_SIZE) + 1}`,
            error: error instanceof Error ? error.message : String(error)
          });
        }
      }

      // Update import history record for the initial batch
      if (importHistoryRecord) {
        await supabaseAdmin
          .from('import_history')
          .update({
            successful_imports: successfulImports,
            failed_imports: failedImports,
            status: remainingContactsToImport.length > 0 ? 'partial' :
                   (failedImports === elberContacts.length ? 'failed' :
                   successfulImports === elberContacts.length ? 'completed' : 'partial'),
            error_details: importErrors.length > 0 ? importErrors : null,
            completed_at: remainingContactsToImport.length > 0 ? null : new Date().toISOString()
          })
          .eq('id', importHistoryRecord.id);
      }

      // Determine background processing status
      const backgroundProcessingStarted = remainingContactsToImport.length > 0;

      // Construct response
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: remainingContactsToImport.length > 0 ?
                  "Google contacts import partially completed, background processing started" :
                  "Google contacts import completed",
          importBatchId,
          totalRequested: contactsToImport.length,
          totalProcessed: elberContacts.length,
          successfulImports,
          failedImports,
          errors: [...errors, ...importErrors],
          remainingCount: remainingContactsToImport.length,
          backgroundProcessingStarted,
          processingQueueId: backgroundProcessingStarted ? processingQueueId : null
        }),
        headers: COMMON_HEADERS,
      };
    } catch (error) {
      console.error(`${logPrefix} Error importing Google contacts:`, error);
      return {
        statusCode: 500,
        body: JSON.stringify({ 
          message: "Failed to import Google contacts",
          error: error instanceof Error ? error.message : String(error)
        }),
        headers: COMMON_HEADERS,
      };
    }
  }

  return {
    statusCode: 405,
    body: JSON.stringify({ message: `Method ${httpMethod} Not Allowed` }),
    headers: { ...COMMON_HEADERS, 'Allow': 'GET, POST' },
  };
};

export { handler };
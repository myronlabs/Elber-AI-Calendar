import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";
import OpenAI from 'openai';
import fetch from 'node-fetch'; // For making internal HTTP requests
import type { RequestInfo, RequestInit, Response } from 'node-fetch'; // Add this line for types
import { jwtDecode } from 'jwt-decode'; // Import jwt-decode
// Define CalendarEvent interface inline to avoid import issues
interface CalendarEvent {
  event_id: string;
  user_id: string;
  title: string;
  start_time: string;
  end_time: string;
  created_at: string;
  updated_at: string;
  is_all_day: boolean;
  description?: string | null;
  location?: string | null;
  google_event_id?: string | null;
  zoom_meeting_id?: string | null;
  // Recurring event fields
  is_recurring?: boolean;
  recurrence_pattern?: string | null;
  recurrence_interval?: number | null;
  recurrence_day_of_week?: number[] | null;
  recurrence_day_of_month?: number | null;
  recurrence_month?: number | null;
  recurrence_end_date?: string | null;
  recurrence_count?: number | null;
  recurrence_rule?: string | null;
  parent_event_id?: string | null;
  is_exception?: boolean;
  exception_date?: string | null;
  series_id?: string | null;
  recurrence_timezone?: string | null;
}

// Interface for the decoded JWT payload
interface DecodedJwt {
  sub?: string; // Subject (user ID)
  [key: string]: string | number | boolean | null | undefined; // More specific types for other claims
}

// Helper function to get authenticated user ID from JWT
const getUserIdFromEvent = (event: HandlerEvent): string | null => { 
  const authHeader = event.headers?.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7); // Remove "Bearer " prefix
    try {
      const decodedToken = jwtDecode<DecodedJwt>(token);
      if (decodedToken && decodedToken.sub) {
        console.log(`[assistant-calendar.ts] Extracted user ID (sub): ${decodedToken.sub} from JWT.`);
        return decodedToken.sub;
      } else {
        console.warn('[assistant-calendar.ts] JWT decoded but did not contain a sub (user ID) claim.', decodedToken);
        return null;
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error during JWT decoding.';
      console.error(`[assistant-calendar.ts] Error decoding JWT: ${errorMessage}`, error);
      return null;
    }
  }
  console.warn('[assistant-calendar.ts] No Authorization header with Bearer token found.');
  return null; 
};

// Helper function to validate UUID format
const isValidUUID = (uuid: string): boolean => {
  if (!uuid) return false;
  const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
  return uuidRegex.test(uuid);
};

// Helper function to process date strings
const processDate = (dateString: string, label: string): string | null => {
  console.log(`[assistant-calendar.ts] Processing date for ${label}: initial value = "${dateString}"`);
  if (!dateString || dateString.trim() === '') {
    console.warn(`[assistant-calendar.ts] processDate: Received empty or null date string for ${label}. Returning null.`);
    return null;
  }

  const currentYear = new Date().getFullYear(); // Define currentYear inside
  const currentDate = new Date(); // Define currentDate inside

  // If already in ISO format, check if year needs correction
  if (dateString.includes('T') || dateString.match(/^\d{4}-\d{2}-\d{2}/)) {
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      // Check if year is too far in the past or future (more than 1 year difference)
      if (Math.abs(date.getFullYear() - currentYear) > 1) {
        console.log(`[assistant-calendar.ts] ${label}: Year ${date.getFullYear()} seems incorrect, updating to ${currentYear}`);
        date.setFullYear(currentYear);
        return date.toISOString();
      }
      return dateString; // Already valid ISO with reasonable year
    }
  }

  // Not ISO format - convert from natural language
  console.log(`[assistant-calendar.ts] Converting natural language ${label} to ISO: "${dateString}"`);

  // Try to parse with special cases for relative dates
  let date;
  const lowerDate = dateString.toLowerCase();

  if (lowerDate.includes('tomorrow')) {
    date = new Date(currentDate);
    date.setDate(date.getDate() + 1);
  }
  else if (lowerDate.includes('next week')) {
    date = new Date(currentDate);
    date.setDate(date.getDate() + 7);
  }
  else if (lowerDate.includes('next month')) {
    date = new Date(currentDate);
    date.setMonth(date.getMonth() + 1);
  }
  else if (lowerDate.match(/next (mon|tues|wednes|thurs|fri|satur|sun)day/)) {
    // Parse "next Monday", "next Tuesday", etc.
    const dayMap: {[key: string]: number} = {
      'sunday': 0, 'sun': 0,
      'monday': 1, 'mon': 1,
      'tuesday': 2, 'tues': 2,
      'wednesday': 3, 'wednes': 3,
      'thursday': 4, 'thurs': 4,
      'friday': 5, 'fri': 5,
      'saturday': 6, 'satur': 6
    };

    let targetDay = -1;
    for (const [key, value] of Object.entries(dayMap)) {
      if (lowerDate.includes(key)) {
        targetDay = value;
        break;
      }
    }

    if (targetDay !== -1) {
      date = new Date(currentDate);
      const currentDay = date.getDay();
      let daysToAdd = targetDay - currentDay;
      if (daysToAdd <= 0) daysToAdd += 7; // Ensure we get next week
      date.setDate(date.getDate() + daysToAdd);
    } else {
      try { date = new Date(dateString); } catch (e) { /* ignore */ }
    }
  }
  else {
    // Standard parsing for other dates
    try { date = new Date(dateString); } catch (e) { /* ignore */ }
  }

  // Validate and fix the parsed date
  if (date && !isNaN(date.getTime())) {
    // If date is in the past or far future, adjust the year
    if (Math.abs(date.getFullYear() - currentYear) > 1) {
      console.log(`[assistant-calendar.ts] ${label}: Correcting year from ${date.getFullYear()} to ${currentYear}`);
      date.setFullYear(currentYear);
    }
    const result = date.toISOString();
    console.log(`[assistant-calendar.ts] Converted ${label}: ${result}`);
    return result;
  }

  // If we couldn't parse it, return null
  console.warn(`[assistant-calendar.ts] Couldn't convert ${label} to date: "${dateString}". Returning null.`);
  return null;
};

// Helper function to get the base URL for internal API calls
const getInternalApiBaseUrl = (): string => {
  const context = process.env.CONTEXT;
  // CONTEXT will be 'dev' for local development (netlify dev)
  //           'branch-deploy' for branch deploys
  //           'deploy-preview' for deploy previews
  //           'production' for the main production site
  if (context === 'dev') {
    return process.env.URL || 'http://localhost:8888'; 
  } else if (process.env.DEPLOY_PRIME_URL) {
    // DEPLOY_PRIME_URL is available for deploy previews and production deploys
    // It represents the primary URL for that deploy (e.g., unique-preview-url.netlify.app or your-production-site.netlify.app)
    return process.env.DEPLOY_PRIME_URL;
  } else if (process.env.URL) {
    // URL is the main canonical URL of the site (less specific than DEPLOY_PRIME_URL for previews)
    return process.env.URL;
  }
  // Fallback if context is somehow not one of the expected Netlify contexts
  console.warn('[assistant-calendar.ts] Could not robustly determine Netlify API base URL, defaulting to localhost. CONTEXT:', context);
  return 'http://localhost:8888'; 
};

// Helper function to prepare request headers
function getInternalHeaders(eventHeaders: {[key: string]: string | undefined} = {}): Record<string, string> {
  return {
    'Content-Type': 'application/json',
    'Authorization': eventHeaders.authorization || '' // Forward existing auth
  };
}

// Define message types based on OpenAI's message formats
type ChatMessage =
  | { role: 'user'; content: string; tool_calls?: never; tool_call_id?: never; }
  | { role: 'assistant'; content: string | null; tool_calls?: OpenAI.Chat.Completions.ChatCompletionMessageToolCall[]; tool_call_id?: never; }
  | { role: 'system'; content: string; tool_calls?: never; tool_call_id?: never; }
  | { role: 'tool'; content: string; tool_call_id: string; tool_calls?: never; };

interface AssistantRequestBody {
  messages?: ChatMessage[];
  tool_call?: DirectToolCall;
  localTimeZone?: string; // Add this field to receive client time zone
  confirmationContext?: ConfirmationContext; // Context for confirmations
}

// Calendar-specific tool function argument types
interface CreateCalendarEventToolArgs {
  title: string;
  start_time: string;
  end_time: string;
  description: string | null;
  location: string | null;
  is_all_day: boolean;
  // Recurring event fields
  is_recurring?: boolean;
  recurrence_pattern?: string;
  recurrence_interval?: number;
  recurrence_day_of_week?: number[];
  recurrence_day_of_month?: number;
  recurrence_month?: number;
  recurrence_end_date?: string;
  recurrence_count?: number;
  recurrence_timezone?: string;
}

interface FindCalendarEventsToolArgs {
  search_term?: string; // General search term for title, description, location
  start_date?: string;  // ISO format or natural language (e.g., 'today', 'next week')
  end_date?: string;    // ISO format or natural language
  event_id?: string;    // Specific event ID to find (can also be a title if ID is not known)
  // Recurring event options
  expand_recurring?: boolean; // Whether to expand recurring events into individual occurrences
  series_id?: string;   // Find all events in a given series
  include_recurring_only?: boolean; // Only include recurring events in results
}

interface UpdateCalendarEventToolArgs {
  event_id: string; // Mandatory: ID of the event to update. LLM should find it first if not provided by user.
  title?: string; // Optional: The new title of the event. Only provide if changing the title.
  start_time?: string | null; // Allow null to signify "no change" or "clear if applicable by backend"
  end_time?: string | null;   // Allow null
  description?: string | null;
  location?: string | null;
  is_all_day?: boolean;
  // Recurring event fields
  is_recurring?: boolean;
  recurrence_pattern?: string;
  recurrence_interval?: number;
  recurrence_day_of_week?: number[];
  recurrence_day_of_month?: number;
  recurrence_month?: number;
  recurrence_end_date?: string;
  recurrence_count?: number;
  recurrence_timezone?: string;
  // For updating recurring series
  update_scope?: 'single' | 'future' | 'all'; // Whether to update only this instance, this and future instances, or all instances
}

interface DeleteCalendarEventToolArgs {
  event_id: string; // Event ID or identifier like title
  search_term?: string; // Optional search term to use instead of event_id
  confirmed?: boolean; // Optional confirmation flag
  // For deleting recurring events
  delete_scope?: 'single' | 'future' | 'all'; // Whether to delete only this instance, this and future instances, or all instances
}

// All possible calendar tool function arguments
type ToolFunctionArgs = 
  CreateCalendarEventToolArgs |
  FindCalendarEventsToolArgs |
  UpdateCalendarEventToolArgs |
  DeleteCalendarEventToolArgs;

// Define an interface for the direct tool call object sent by AssistantPage.tsx
// This should match the structure of OpenAI.Chat.Completions.ChatCompletionMessageToolCall
interface DirectToolCall {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string; // Arguments are stringified JSON
  };
}

// Interface for confirmation context from frontend
interface ConfirmationContext {
  entityId: string;
  entityName: string;
  type: 'calendar' | 'contact';
  actionType: string;
  requiresFollowUp?: boolean;
}

// Define the calendar-specific tools for OpenAI
export const tools: OpenAI.Chat.Completions.ChatCompletionTool[] = [
  {
    type: "function",
    function: {
      name: "create_calendar_event",
      description: "Creates a new calendar event with the provided details. Always collect and provide ALL required details upfront to prevent follow-up questions.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          title: {
            type: "string",
            description: "Title of the calendar event."
          },
          start_time: {
            type: "string",
            description: "Start time of the event in ISO format or natural language (e.g., 'May 10th at 06:00 PM')."
          },
          end_time: {
            type: "string",
            description: "End time of the event in ISO format or natural language (e.g., 'May 10th at 09:00 PM')."
          },
          description: {
            type: ["string", "null"],
            description: "Optional: Description of the event."
          },
          location: {
            type: ["string", "null"],
            description: "Optional: Location of the event."
          },
          is_all_day: {
            type: "boolean",
            description: "Is this an all-day event?"
          },
          // Recurring event fields, only relevant if is_recurring is true
          is_recurring: {
            type: ["boolean", "null"], // Allow null to mean not specified
            description: "Optional: Is this a recurring event? If true, provide recurrence details."
          },
          recurrence_pattern: {
            type: ["string", "null"],
            enum: ["daily", "weekly", "monthly", "yearly", null],
            description: "Pattern for recurrence (daily, weekly, monthly, yearly). Required if is_recurring is true."
          },
          recurrence_interval: {
            type: ["integer", "null"],
            description: "Interval for recurrence (e.g., every 2 weeks if pattern is weekly). Required if is_recurring is true."
          },
          recurrence_day_of_week: {
            type: ["array", "null"],
            items: { type: "integer", minimum: 0, maximum: 6 }, // 0 for Sunday, 6 for Saturday
            description: "Days of the week for weekly recurrence (0-6). Required if pattern is weekly."
          },
          recurrence_day_of_month: {
            type: ["integer", "null"],
            description: "Day of the month for monthly recurrence. Required if pattern is monthly."
          },
          recurrence_month: {
            type: ["integer", "null"],
            description: "Month for yearly recurrence (1-12). Required if pattern is yearly."
          },
          recurrence_end_date: {
            type: ["string", "null"],
            description: "Optional: End date for recurrence in ISO format."
          },
          recurrence_count: {
            type: ["integer", "null"],
            description: "Optional: Number of occurrences for recurrence."
          },
          recurrence_timezone: {
            type: ["string", "null"],
            description: "Optional: Timezone for recurrence (e.g., 'America/New_York'). Defaults to user's local timezone if not provided."
          }
        },
        required: [
          "title", 
          "start_time", 
          "end_time", 
          "is_all_day", 
          "description", 
          "location", 
          "is_recurring", 
          "recurrence_pattern", 
          "recurrence_interval", 
          "recurrence_day_of_week", 
          "recurrence_day_of_month", 
          "recurrence_month", 
          "recurrence_end_date", 
          "recurrence_count", 
          "recurrence_timezone"
        ],
        additionalProperties: false
      },
    }
  },
  {
    type: "function",
    function: {
      name: "find_calendar_events",
      description: "Finds existing calendar events based on various criteria like search term, date range, or event ID. Provide at least one search criterion.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          search_term: {
            type: ["string", "null"],
            description: "Optional: General search term for event titles, descriptions, or locations."
          },
          start_date: {
            type: ["string", "null"],
            description: "Optional: Start date for the search range (ISO format or natural language like 'today', 'next week')."
          },
          end_date: {
            type: ["string", "null"],
            description: "Optional: End date for the search range (ISO format or natural language)."
          },
          event_id: {
            type: ["string", "null"],
            description: "Optional: Specific event ID (UUID) or a unique event title to find a single event."
          },
          // Recurring event options
          expand_recurring: {
            type: ["boolean", "null"],
            description: "Optional: Whether to expand recurring events into individual occurrences in the results. Defaults to false."
          },
          series_id: {
            type: ["string", "null"],
            description: "Optional: Find all events belonging to a specific recurrence series ID."
          },
          include_recurring_only: {
            type: ["boolean", "null"],
            description: "Optional: If true, only include events that are part of a recurring series. Defaults to false."
          }
        },
        required: ["search_term", "start_date", "end_date", "event_id", "expand_recurring", "series_id", "include_recurring_only"], // No single field is strictly required; at least one should be provided by the LLM based on context.
        additionalProperties: false
      },
    },
  },
  {
    type: "function",
    function: {
      name: "update_calendar_event",
      description: "Updates an existing calendar event with the provided details. The event_id is mandatory. Other fields are optional and only included if a change is intended for that field.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          event_id: {
            type: "string",
            description: "Mandatory: The unique ID (UUID) of the event to update. If the user provides a non-UUID identifier (like a title), the system will attempt to find the event, but this may fail if not unique."
          },
          title: {
            type: ["string", "null"],
            description: "Optional: The new title of the event. Only provide if changing the title."
          },
          start_time: {
            type: ["string", "null"],
            description: "Optional: The new start time (ISO format or natural language). Send null to explicitly clear the start time if the backend supports it, otherwise omit if no change."
          },
          end_time: {
            type: ["string", "null"],
            description: "Optional: The new end time (ISO format or natural language). Send null to explicitly clear the end time if the backend supports it, otherwise omit if no change."
          },
          description: {
            type: ["string", "null"],
            description: "Optional: The new description. Send null to clear the description."
          },
          location: {
            type: ["string", "null"],
            description: "Optional: The new location. Send null to clear the location."
          },
          is_all_day: {
            type: ["boolean", "null"],
            description: "Optional: Set to true or false to change the all-day status. Omit if no change."
          },
          // Recurring event fields - only provide if changing recurrence
          is_recurring: {
            type: ["boolean", "null"],
            description: "Optional: Set to true or false to change recurrence status. If setting to true, provide necessary recurrence_pattern etc."
          },
          recurrence_pattern: {
            type: ["string", "null"],
            enum: ["daily", "weekly", "monthly", "yearly", null],
            description: "Optional: New recurrence pattern."
          },
          recurrence_interval: {
            type: ["integer", "null"],
            description: "Optional: New recurrence interval."
          },
          recurrence_day_of_week: {
            type: ["array", "null"],
            items: { type: "integer", minimum: 0, maximum: 6 },
            description: "Optional: New days of the week for weekly recurrence."
          },
          recurrence_day_of_month: {
            type: ["integer", "null"],
            description: "Optional: New day of the month for monthly recurrence."
          },
          recurrence_month: {
            type: ["integer", "null"],
            description: "Optional: New month for yearly recurrence."
          },
          recurrence_end_date: {
            type: ["string", "null"],
            description: "Optional: New end date for recurrence."
          },
          recurrence_count: {
            type: ["integer", "null"],
            description: "Optional: New number of occurrences."
          },
          recurrence_timezone: {
            type: ["string", "null"],
            description: "Optional: New timezone for recurrence."
          },
          update_scope: { // For updating recurring series
            type: ["string", "null"],
            enum: ["single", "future", "all", null],
            description: "Optional (for recurring events): 'single' (this instance only), 'future' (this and future), or 'all' (entire series). Defaults to 'single' or behavior defined by backend if not specified."
          }
        },
        required: [
          "event_id",
          "title",
          "start_time",
          "end_time",
          "description",
          "location",
          "is_all_day",
          "is_recurring",
          "recurrence_pattern",
          "recurrence_interval",
          "recurrence_day_of_week",
          "recurrence_day_of_month",
          "recurrence_month",
          "recurrence_end_date",
          "recurrence_count",
          "recurrence_timezone",
          "update_scope"
        ],
        additionalProperties: false
      },
    },
  },
  {
    type: "function",
    function: {
      name: "delete_calendar_event",
      description: "Deletes a calendar event. Requires the event_id (UUID preferred). If a non-UUID identifier is given, it will be treated as a search term to find a unique event to delete. Confirmed flag can be used to bypass user confirmation prompts if already obtained.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          event_id: {
            type: "string",
            description: "The ID (UUID) of the event to delete. Alternatively, a unique title or other search term can be provided if the UUID is not known, and the system will attempt to find a single matching event."
          },
          search_term: { 
            type: ["string", "null"],
            description: "Optional: If event_id is not a UUID or to provide more context for deletion if ID is ambiguous. This is secondary to event_id if event_id is a valid UUID."
          },
          confirmed: { 
            type: ["boolean", "null"],
            description: "Optional: Flag to indicate if the user has already confirmed the deletion. If true, the deletion will proceed without further prompts from the assistant. Defaults to false."
          },
          delete_scope: {
            type: ["string", "null"],
            enum: ["single", "future", "all", null],
            description: "Optional (for recurring events): 'single' (this instance only), 'future' (this and future), or 'all' (entire series). Defaults to 'single' if not specified or if the event is not recurring."
          },
        },
        required: ["event_id", "search_term", "confirmed", "delete_scope"],
        additionalProperties: false
      },
    },
  }
];

// Main function to execute calendar tool calls
export async function executeSingleToolCall(
  toolCall: OpenAI.Chat.Completions.ChatCompletionMessageToolCall,
  eventHeaders: HandlerEvent['headers'],
  userId: string | null,
  reqId?: string // Added reqId as an optional parameter
): Promise<OpenAI.Chat.Completions.ChatCompletionToolMessageParam> {
  const functionName = toolCall.function.name;
  let functionArgs: ToolFunctionArgs;
  const toolCallId = toolCall.id; // Capture toolCallId here
  const currentReqId = reqId || `tool_exec_cal_${toolCallId.substring(0,8)}_${Date.now()}`; // Use reqId or generate a fallback
  const logPrefix = `[assistant-calendar.ts][ReqID:${currentReqId}][${functionName}]`; // Define logPrefix here

  try {
    functionArgs = JSON.parse(toolCall.function.arguments) as ToolFunctionArgs;
  } catch (e) {
    console.error(`${logPrefix} Error parsing arguments for tool ${functionName} (ID: ${toolCallId}): ${toolCall.function.arguments}`, e); // Used logPrefix and toolCallId
    return {
      tool_call_id: toolCallId, // Use toolCallId
      role: "tool" as const,
      content: JSON.stringify({ error: "Failed to parse function arguments.", details: (e instanceof Error ? e.message : String(e)) }),
    };
  }

  console.log(`${logPrefix} Executing tool call ID: ${toolCallId}, Args:`, functionArgs); // Used logPrefix and toolCallId

  let toolResultContent = "";
  const internalApiBaseUrl = getInternalApiBaseUrl();
  const internalHeaders = getInternalHeaders(eventHeaders);

  try {
    switch (functionName) {
      case "create_calendar_event":
        {
          console.log(`${logPrefix} Tool call execution with args:`, functionArgs);
          const typedArgs = functionArgs as CreateCalendarEventToolArgs;

          // Enhanced logging for better troubleshooting
          console.log(`${logPrefix} Processing create calendar event with title: "${typedArgs.title}"`);
          console.log(`${logPrefix} Event time range: ${typedArgs.start_time} to ${typedArgs.end_time}`);
          console.log(`${logPrefix} Event description: "${typedArgs.description || ''}"`);

          // Additional validation for required fields
          if (!typedArgs.title || !typedArgs.start_time || !typedArgs.end_time) {
            console.error(`${logPrefix} Missing required fields for calendar event creation`);
            toolResultContent = JSON.stringify({
              success: false,
              error: "Missing required fields",
              message: "Calendar event creation failed. Title, start time, and end time are required."
            });
            break;
          }

          // Process and standardize date/time strings for backend compatibility
          let startTime = typedArgs.start_time;
          let endTime = typedArgs.end_time;

          // Double-check and convert dates if needed (as a backup in case the LLM doesn't use the correct year)
          try {
            // Process both start and end times
            // The global processDate will be used here now.
            const processedStartTime = processDate(startTime, 'start time');
            if (processedStartTime === null) {
              // Handle error: start_time could not be parsed
              console.error(`${logPrefix} Critical error: start_time "${startTime}" could not be parsed.`);
              toolResultContent = JSON.stringify({
                success: false,
                error: "Invalid start date format",
                message: `The start date "${startTime}" could not be understood. Please provide a valid date.`
              });
              break;
            }
            startTime = processedStartTime;

            const processedEndTime = processDate(endTime, 'end time');
            if (processedEndTime === null) {
              // Handle error: end_time could not be parsed
              console.error(`${logPrefix} Critical error: end_time "${endTime}" could not be parsed.`);
              toolResultContent = JSON.stringify({
                success: false,
                error: "Invalid end date format",
                message: `The end date "${endTime}" could not be understood. Please provide a valid date.`
              });
              break;
            }
            endTime = processedEndTime;
          } catch (error) {
            console.error(`${logPrefix} Error converting time strings:`, error);
            // Continue with original strings if conversion fails
          }

          // Check for duplicates first - similar to how contacts are handled
          const searchStartDate = new Date(startTime);
          // Adjust search time range - look for events within a 2-hour window of the requested time
          searchStartDate.setHours(searchStartDate.getHours() - 2);
          const searchStartDateISO = searchStartDate.toISOString();

          const searchEndDate = new Date(endTime);
          searchEndDate.setHours(searchEndDate.getHours() + 2);
          const searchEndDateISO = searchEndDate.toISOString();

          // Construct search query params
          const searchParams = new URLSearchParams();
          searchParams.append('search_term', typedArgs.title);
          searchParams.append('start_date', searchStartDateISO);
          searchParams.append('end_date', searchEndDateISO);

          // First, check if a similar event already exists (same title, around same time)
          const internalApiBaseUrl = getInternalApiBaseUrl();
          const searchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar?${searchParams.toString()}`;
          console.log(`${logPrefix} Checking for duplicate events: ${searchUrl}`);

          const searchResponse: Response = await fetch(searchUrl as RequestInfo, {
            method: 'GET',
            headers: internalHeaders as HeadersInit,
          } as RequestInit);

          if (searchResponse.ok) {
            const potentialDuplicates = await searchResponse.json();

            if (Array.isArray(potentialDuplicates) && potentialDuplicates.length > 0) {
              console.log(`${logPrefix} Found ${potentialDuplicates.length} potential duplicate events`);

              // Check for actual duplicates (same title within close time range)
              const duplicates = potentialDuplicates.filter(event => {
                // Check for exact duplicate by title (case-insensitive)
                const eventTitle = event.title?.toLowerCase() === typedArgs.title.toLowerCase();

                // Get time values in minutes for comparison
                const eventStartTime = new Date(event.start_time).getTime();
                const requestedStartTime = new Date(startTime).getTime();
                const timeDifference = Math.abs(eventStartTime - requestedStartTime) / (1000 * 60); // difference in minutes

                // Check date as well (day, month, year)
                const eventDate = new Date(event.start_time);
                const requestedDate = new Date(startTime);
                const sameDate =
                  eventDate.getFullYear() === requestedDate.getFullYear() &&
                  eventDate.getMonth() === requestedDate.getMonth() &&
                  eventDate.getDate() === requestedDate.getDate();

                // Return true if it's the same title on the same day and within 60 minutes
                return eventTitle && sameDate && timeDifference < 60;
              });

              if (duplicates.length > 0) {
                const duplicate = duplicates[0];
                console.log(`${logPrefix} Found exact duplicate: ${duplicate.title} at ${duplicate.start_time}`);

                // Format dates for user-friendly message
                const duplicateDate = new Date(duplicate.start_time);
                const formattedDuplicateTime = duplicateDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const formattedDuplicateDate = duplicateDate.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });

                // Return information about duplicate with improved message
                toolResultContent = JSON.stringify({
                  success: false,
                  duplicate_found: true,
                  message: `An event with the same title "${duplicate.title}" already exists on ${formattedDuplicateDate} at ${formattedDuplicateTime}. To avoid duplicates, please update the existing event or choose a different time/title.`,
                  existing_event_id: duplicate.event_id,
                  event: duplicate
                });
                break;
              }
            }
          }

          // If no duplicates found, proceed with creating the event
          // Handle recurrence data if present
          interface RecurrenceData {
            is_recurring?: boolean;
            series_id?: string;
            recurrence_pattern?: string | null;
            recurrence_interval?: number | null;
            recurrence_day_of_week?: number[] | null;
            recurrence_day_of_month?: number | null;
            recurrence_month?: number | null;
            recurrence_end_date?: string | null;
            recurrence_count?: number | null;
            recurrence_timezone?: string | null;
          }

          let recurrenceData: RecurrenceData = {};

          if (typedArgs.is_recurring) {
            console.log(`${logPrefix} Processing recurring event data`);

            // Generate a series ID for this recurring event if needed
            const seriesId = crypto.randomUUID();

            // Build recurrence data from the event data
            recurrenceData = {
              is_recurring: true,
              series_id: seriesId,
              recurrence_pattern: typedArgs.recurrence_pattern,
              recurrence_interval: typedArgs.recurrence_interval || 1,
              recurrence_day_of_week: typedArgs.recurrence_day_of_week,
              recurrence_day_of_month: typedArgs.recurrence_day_of_month,
              recurrence_month: typedArgs.recurrence_month,
              recurrence_end_date: typedArgs.recurrence_end_date,
              recurrence_count: typedArgs.recurrence_count,
              recurrence_timezone: typedArgs.recurrence_timezone || Intl.DateTimeFormat().resolvedOptions().timeZone
            };

            console.log(`${logPrefix} Recurrence data:`, JSON.stringify(recurrenceData));
          } else {
            // Ensure is_recurring is explicitly set to false if not a recurring event
            recurrenceData = { is_recurring: false };
          }

          // Create a strongly-typed, well-formed payload with all required fields
          // and conditionally include optional fields only when they're provided
          const calendarPayload: {
            title: string;
            start_time: string;
            end_time: string;
            is_all_day: boolean;
            user_id: string | null;
            description?: string | null;
            location?: string | null;
            is_recurring?: boolean;
            series_id?: string;
            recurrence_pattern?: string | null;
            recurrence_interval?: number | null;
            recurrence_day_of_week?: number[] | null;
            recurrence_day_of_month?: number | null;
            recurrence_month?: number | null;
            recurrence_end_date?: string | null;
            recurrence_count?: number | null;
            recurrence_timezone?: string | null;
          } = {
            title: typedArgs.title,
            start_time: startTime,
            end_time: endTime,
            is_all_day: typedArgs.is_all_day ?? false,  // Default to false if not provided
            user_id: userId // Pass the user ID to associate the event with the user
          };

          // Only include optional fields if they're explicitly provided (even as null)
          if (typedArgs.description !== undefined) {
            calendarPayload.description = typedArgs.description;
          }

          if (typedArgs.location !== undefined) {
            calendarPayload.location = typedArgs.location;
          }

          // Add recurrence data if present - using type-safe approach
          if ('is_recurring' in recurrenceData && recurrenceData.is_recurring !== undefined) {
            calendarPayload.is_recurring = recurrenceData.is_recurring;
          }

          if ('series_id' in recurrenceData && recurrenceData.series_id !== undefined) {
            calendarPayload.series_id = recurrenceData.series_id;
          }

          if ('recurrence_pattern' in recurrenceData && recurrenceData.recurrence_pattern !== undefined) {
            calendarPayload.recurrence_pattern = recurrenceData.recurrence_pattern;
          }

          if ('recurrence_interval' in recurrenceData && recurrenceData.recurrence_interval !== undefined) {
            calendarPayload.recurrence_interval = recurrenceData.recurrence_interval;
          }

          if ('recurrence_day_of_week' in recurrenceData && recurrenceData.recurrence_day_of_week !== undefined) {
            calendarPayload.recurrence_day_of_week = recurrenceData.recurrence_day_of_week;
          }

          if ('recurrence_day_of_month' in recurrenceData && recurrenceData.recurrence_day_of_month !== undefined) {
            calendarPayload.recurrence_day_of_month = recurrenceData.recurrence_day_of_month;
          }

          if ('recurrence_month' in recurrenceData && recurrenceData.recurrence_month !== undefined) {
            calendarPayload.recurrence_month = recurrenceData.recurrence_month;
          }

          if ('recurrence_end_date' in recurrenceData && recurrenceData.recurrence_end_date !== undefined) {
            calendarPayload.recurrence_end_date = recurrenceData.recurrence_end_date;
          }

          if ('recurrence_count' in recurrenceData && recurrenceData.recurrence_count !== undefined) {
            calendarPayload.recurrence_count = recurrenceData.recurrence_count;
          }

          if ('recurrence_timezone' in recurrenceData && recurrenceData.recurrence_timezone !== undefined) {
            calendarPayload.recurrence_timezone = recurrenceData.recurrence_timezone;
          }

          const internalFetchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar`;
          console.log(`${logPrefix} No duplicates found. Calling calendar API at: ${internalFetchUrl}`);

          const internalResponse: Response = await fetch(internalFetchUrl as RequestInfo, {
            method: 'POST',
            headers: internalHeaders as HeadersInit,
            body: JSON.stringify(calendarPayload),
          } as RequestInit);

          const rawResponse = await internalResponse.text();

          if (!internalResponse.ok) {
            console.error(`${logPrefix} Error from internal ${functionName} call: ${internalResponse.status} ${internalResponse.statusText}`, rawResponse);
            let errorObj;
            try {
              errorObj = JSON.parse(rawResponse);
              console.error(`${logPrefix} Parsed error response:`, errorObj);

              // Provide a better error message
              toolResultContent = JSON.stringify({
                success: false,
                error: `Failed to create calendar event: ${errorObj.message || 'Unknown error'}`,
                details: errorObj
              });
            } catch (e) {
              console.error(`${logPrefix} Failed to parse error response:`, e);
              toolResultContent = JSON.stringify({
                success: false,
                error: `Internal ${functionName} failed with status ${internalResponse.status}`,
                details: rawResponse
              });
            }
          } else {
            // Success case
            console.log(`${logPrefix} Successfully created calendar event. Raw response: ${rawResponse}`);

            let eventData;
            try {
              eventData = JSON.parse(rawResponse);
              console.log(`${logPrefix} Parsed successful response:`, eventData);

              // Return a formatted response for the user
              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${eventData.title}" successfully created.`,
                event: eventData,
                event_id: eventData.event_id
              });
            } catch (e) {
              console.error(`${logPrefix} Error parsing successful response:`, e);
              // Even if we can't parse the response JSON, still treat it as a success if the HTTP status was OK
              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${typedArgs.title}" was successfully created.`,
                event_id: typedArgs.title,
                event: rawResponse
              });
            }
          }
        }
        break;

      case "find_calendar_events":
        {
          console.log(`${logPrefix} Tool call execution with args:`, functionArgs);
          const typedArgs = functionArgs as FindCalendarEventsToolArgs;
          let apiUrl = `${internalApiBaseUrl}/.netlify/functions/calendar`; // Fixed URL to use correct Netlify function path
          const queryParams = new URLSearchParams();

          if (typedArgs.event_id) {
            // If event_id is provided and is a UUID, use it as a path parameter
            // Otherwise, treat it as a search term for the query parameter
            if (isValidUUID(typedArgs.event_id)) {
              apiUrl = `${internalApiBaseUrl}/.netlify/functions/calendar/${encodeURIComponent(typedArgs.event_id)}`; // Corrected: target 'calendar' function
              console.log(`${logPrefix} find_calendar_events: searching by specific event_id (UUID): ${typedArgs.event_id}`);
            } else {
              // Non-UUID event_id is treated as a general search term
              queryParams.append('search_term', typedArgs.event_id);
              console.log(`${logPrefix} find_calendar_events: event_id "${typedArgs.event_id}" is not a UUID, treating as search_term.`);
            }
          } else {
            // Only add other params if event_id was not a UUID path param
            if (typedArgs.search_term) {
              queryParams.append('search_term', typedArgs.search_term);
              console.log(`${logPrefix} find_calendar_events: using search_term: "${typedArgs.search_term}"`);
            }
            if (typedArgs.start_date) {
              const processedStartDate = processDate(typedArgs.start_date, 'start_date');
              if (processedStartDate) queryParams.append('start_date', processedStartDate);
              else console.warn(`${logPrefix} find_calendar_events: start_date "${typedArgs.start_date}" was unparsable, not adding to query.`);
              console.log(`${logPrefix} find_calendar_events: using start_date: "${processedStartDate || 'N/A'}" (original: "${typedArgs.start_date}")`);
            }
            if (typedArgs.end_date) {
              const processedEndDate = processDate(typedArgs.end_date, 'end_date');
              if (processedEndDate) queryParams.append('end_date', processedEndDate);
              else console.warn(`${logPrefix} find_calendar_events: end_date "${typedArgs.end_date}" was unparsable, not adding to query.`);
              console.log(`${logPrefix} find_calendar_events: using end_date: "${processedEndDate || 'N/A'}" (original: "${typedArgs.end_date}")`);
            }
          }

          const queryString = queryParams.toString();
          if (queryString) {
            apiUrl += `?${queryString}`;
          }

          console.log(`${logPrefix} find_calendar_events: Calling internal API: ${apiUrl}`);

          try {
            const response: Response = await fetch(apiUrl as RequestInfo, {
              method: 'GET',
              headers: internalHeaders as HeadersInit,
            } as RequestInit);

            const responseBody = await response.text(); // Get raw text to handle both JSON and errors
            console.log(`${logPrefix} find_calendar_events: Internal API response status: ${response.status}`);
            // console.log(`[assistant-calendar.ts] find_calendar_events: Internal API response body: ${responseBody}`);

            if (!response.ok) {
              console.error(`${logPrefix} find_calendar_events: Internal API error. Status: ${response.status}, Body: ${responseBody}`);
              // Try to parse as JSON for a structured error message, otherwise use the raw body
              try {
                const errorJson = JSON.parse(responseBody);
                toolResultContent = JSON.stringify({ 
                  success: false, 
                  error: `Internal API Error: ${response.status}`, 
                  message: errorJson.message || 'Failed to fetch calendar events from internal API.',
                  details: errorJson 
                });
              } catch {
                toolResultContent = JSON.stringify({
                  success: false,
                  error: `Internal API Error: ${response.status}`,
                  message: 'Failed to fetch calendar events and parse error response.',
                  details: responseBody
                });
              }
            } else {
              // Attempt to parse as JSON, as calendar.ts should return JSON array
              try {
                const events = JSON.parse(responseBody);
                if (Array.isArray(events) && events.length === 0) {
                  toolResultContent = JSON.stringify({ 
                    success: true, 
                    data: [], 
                    message: "No calendar events found matching your criteria." 
                  });
                } else {
                  toolResultContent = JSON.stringify({ success: true, data: events });
                }
              } catch (parseError) {
                console.error(`${logPrefix} find_calendar_events: Error parsing successful response from internal API: ${parseError}. Body: ${responseBody}`);
                toolResultContent = JSON.stringify({
                  success: false,
                  error: "Response parsing error",
                  message: "Successfully called API, but failed to parse the events response.",
                  details: responseBody
                });
              }
            }
          } catch (fetchError: unknown) {
            const errorMessage = fetchError instanceof Error
              ? fetchError.message
              : 'Unknown error occurred';

            console.error(`${logPrefix} find_calendar_events: Fetch error calling internal API: ${errorMessage}`, fetchError);
            toolResultContent = JSON.stringify({
              success: false,
              error: "Internal fetch error",
              message: `Failed to communicate with the internal calendar service: ${errorMessage}`
            });
          }
          break;
        }

      case "update_calendar_event":
        {
          console.log(`${logPrefix} Tool call execution with args:`, functionArgs);
          let typedArgs = functionArgs as UpdateCalendarEventToolArgs;

          // Process event_id first, potentially resolving non-UUIDs
          if (typedArgs.event_id && !isValidUUID(typedArgs.event_id)) {
            const potentialIdentifier = typedArgs.event_id;
            console.log(`${logPrefix} Detected non-UUID event_id: "${potentialIdentifier}". Attempting to find event by this identifier.`);
            const findParams = new URLSearchParams();
            findParams.append('search_term', potentialIdentifier);
            
            const searchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar?${findParams.toString()}`;
            console.log(`${logPrefix} Searching for actual event ID: ${searchUrl}`);

            try {
              const searchResponse: Response = await fetch(searchUrl as RequestInfo, {
                method: 'GET',
                headers: internalHeaders as HeadersInit,
              } as RequestInit);

              if (searchResponse.ok) {
                const matchingEvents = await searchResponse.json() as CalendarEvent[];
                if (Array.isArray(matchingEvents) && matchingEvents.length === 1) {
                  const actualEvent = matchingEvents[0];
                  console.log(`${logPrefix} Found unique event. Replacing non-UUID event_id "${potentialIdentifier}" with actual UUID: ${actualEvent.event_id}`);
                  typedArgs = { ...typedArgs, event_id: actualEvent.event_id };
                } else if (Array.isArray(matchingEvents) && matchingEvents.length > 1) {
                  console.warn(`${logPrefix} Multiple events found for identifier "${potentialIdentifier}". Update cannot proceed.`);
                  toolResultContent = JSON.stringify({
                    success: false,
                    error: `Multiple events found matching "${potentialIdentifier}". Please provide a unique event_id or more specific criteria.`,
                  });
                  return { tool_call_id: toolCallId, role: "tool" as const, content: toolResultContent };
                } else {
                  console.warn(`${logPrefix} No event found for identifier "${potentialIdentifier}".`);
                  toolResultContent = JSON.stringify({
                    success: false,
                    error: `No event found matching "${potentialIdentifier}". Cannot update.`,
                  });
                  return { tool_call_id: toolCallId, role: "tool" as const, content: toolResultContent };
                }
              } else {
                 console.warn(`${logPrefix} Search for actual event_id failed with status: ${searchResponse.status}`);
                 // If search fails, it is risky to proceed. Error out.
                 toolResultContent = JSON.stringify({
                    success: false,
                    error: `Failed to find event by identifier "${potentialIdentifier}" due to server error ${searchResponse.status}.`,
                 });
                 return { tool_call_id: toolCallId, role: "tool"as const, content: toolResultContent };
              }
            } catch (error) {
              console.error(`${logPrefix} Error looking up event by identifier "${potentialIdentifier}":`, error);
               toolResultContent = JSON.stringify({
                 success: false,
                 error: `Error occurred while trying to find event by identifier "${potentialIdentifier}".`,
               });
               return { tool_call_id: toolCallId, role: "tool" as const, content: toolResultContent };
            }
          }

          console.log(`${logPrefix} Attempting to update calendar event ID '${typedArgs.event_id}'`);

          if (!isValidUUID(typedArgs.event_id)) {
            console.error(`${logPrefix} Invalid or unresolved event_id for update: "${typedArgs.event_id}"`);
            toolResultContent = JSON.stringify({
                success: false,
                error: `Cannot update event. The event_id "${typedArgs.event_id}" is not a valid UUID and could not be resolved to a unique event.`,
            });
            return { tool_call_id: toolCallId, role: "tool" as const, content: toolResultContent };
          }

          const requestId = `update_calendar_req_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
          console.log(`${logPrefix} Update calendar request ${requestId} for event ID ${typedArgs.event_id}`);

          const updateUrl = `${internalApiBaseUrl}/.netlify/functions/calendar/${encodeURIComponent(typedArgs.event_id)}`;
          const updatePayload: Partial<Omit<CalendarEvent, 'event_id' | 'user_id' | 'created_at' | 'updated_at'>> = {};

          // Only include fields in the payload if they are explicitly provided (not undefined)
          // For title, ensure it's a non-null, non-empty string before including
          if (typedArgs.title !== undefined && typedArgs.title !== null && typedArgs.title.trim() !== '') {
            updatePayload.title = typedArgs.title;
          }

          if (typedArgs.start_time !== undefined && typedArgs.start_time !== null) {
            const processedStartTime = processDate(typedArgs.start_time, 'update start time');
            if (processedStartTime) {
              updatePayload.start_time = processedStartTime;
            } else {
              console.warn(`${logPrefix} update_calendar_event: start_time "${typedArgs.start_time}" was unparsable by processDate. This field will not be updated.`);
              // Do not return; allow other fields to be updated.
            }
          } else if (typedArgs.start_time === null) {
             // If AI explicitly sends null for start_time, it might mean "clear this" or it might be an error.
             // Backend should decide how to interpret explicit nulls. For now, we pass it if it's explicitly null.
             // However, current CalendarEvent type has start_time as string, not string | null for the database.
             // So, sending null here will likely fail at the DB or backend calendar.ts.
             // It's safer to only process valid date strings or omit the field if null/undefined.
             console.log(`${logPrefix} update_calendar_event: start_time was explicitly null. This field will be omitted from update unless backend handles it.`);
          }


          if (typedArgs.end_time !== undefined && typedArgs.end_time !== null) {
            const processedEndTime = processDate(typedArgs.end_time, 'update end time');
            if (processedEndTime) {
              updatePayload.end_time = processedEndTime;
            } else {
              console.warn(`${logPrefix} update_calendar_event: end_time "${typedArgs.end_time}" was unparsable by processDate. This field will not be updated.`);
            }
          } else if (typedArgs.end_time === null) {
            console.log(`${logPrefix} update_calendar_event: end_time was explicitly null. This field will be omitted from update.`);
          }

          if (typedArgs.description !== undefined) updatePayload.description = typedArgs.description; // Allows null
          if (typedArgs.location !== undefined) updatePayload.location = typedArgs.location; // Allows null
          if (typedArgs.is_all_day !== undefined && typedArgs.is_all_day !== null) {
            updatePayload.is_all_day = typedArgs.is_all_day;
          }
          if (typedArgs.is_recurring !== undefined && typedArgs.is_recurring !== null) {
            updatePayload.is_recurring = typedArgs.is_recurring;
          }
          
          // Only include recurrence fields if is_recurring is true or being set to true
          if (typedArgs.is_recurring === true || (typedArgs.is_recurring === undefined && updatePayload.is_recurring === true)) {
            if (typedArgs.recurrence_pattern !== undefined) updatePayload.recurrence_pattern = typedArgs.recurrence_pattern;
            if (typedArgs.recurrence_interval !== undefined) updatePayload.recurrence_interval = typedArgs.recurrence_interval;
            if (typedArgs.recurrence_day_of_week !== undefined) updatePayload.recurrence_day_of_week = typedArgs.recurrence_day_of_week;
            if (typedArgs.recurrence_day_of_month !== undefined) updatePayload.recurrence_day_of_month = typedArgs.recurrence_day_of_month;
            if (typedArgs.recurrence_month !== undefined) updatePayload.recurrence_month = typedArgs.recurrence_month;
            if (typedArgs.recurrence_end_date !== undefined) updatePayload.recurrence_end_date = typedArgs.recurrence_end_date; // Process this date if not null?
            if (typedArgs.recurrence_count !== undefined) updatePayload.recurrence_count = typedArgs.recurrence_count;
            if (typedArgs.recurrence_timezone !== undefined) updatePayload.recurrence_timezone = typedArgs.recurrence_timezone;
          }


          if (typedArgs.update_scope !== undefined) {
            internalHeaders['X-Update-Scope'] = typedArgs.update_scope;
          }

          // Check if there's anything to update
          if (Object.keys(updatePayload).length === 0) {
            console.log(`${logPrefix} update_calendar_event: No valid fields provided for update. Event ID: ${typedArgs.event_id}`);
            toolResultContent = JSON.stringify({
              success: true, // Considered success as no invalid operation was attempted
              message: "No updatable fields were provided or were valid after processing. No changes made to the event.",
              event_id: typedArgs.event_id,
              update_request_id: requestId
            });
            return { tool_call_id: toolCallId, role: "tool" as const, content: toolResultContent };
          }
          
          // Ensure updated_at is handled by the backend calendar.ts trigger or logic

          console.log(`${logPrefix} Update payload to be sent:`, JSON.stringify(updatePayload));

          const updateResponse: Response = await fetch(updateUrl as RequestInfo, {
            method: 'PUT', // Changed from PATCH to PUT
            headers: {
              ...internalHeaders as HeadersInit,
              'X-Update-Request-ID': requestId
            },
            body: JSON.stringify(updatePayload),
          } as RequestInit);

          if (updateResponse.ok) {
            // Successfully updated the event
            const rawUpdateResult = await updateResponse.text();
            try {
              const updateResult = JSON.parse(rawUpdateResult);
              console.log(`${logPrefix} Internal update_calendar_event call successful. Raw response:`, updateResult);

              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${updateResult.title}" was successfully updated.`,
                event: updateResult, // Add the full updated event object here
                updated_event_id: typedArgs.event_id
              });
            } catch (e) {
              console.error(`${logPrefix} Error parsing calendar update result:`, e);
              // Even if we can't parse the response JSON, still treat it as a success if the HTTP status was OK
              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${typedArgs.title}" was successfully updated.`,
                // We don't have updateResult here, so we can't include the event object
                updated_event_id: typedArgs.event_id,
                update_request_id: requestId
              });
            }
          } else {
            // Failed to update the event
            const errorText = await updateResponse.text();
            console.error(`${logPrefix} Internal update_calendar_event call failed with status ${updateResponse.status}:`, errorText);

            let errorMessage = 'An error occurred while attempting to update the calendar event.';
            try {
              // Try to parse the error message for more details
              const errorJson = JSON.parse(errorText);
              if (errorJson.message) {
                errorMessage = errorJson.message;
              }
            } catch {
              // If parsing fails, we'll stick with the default error message
              console.error(`${logPrefix} Failed to parse error response from update_calendar_event`);
            }

            toolResultContent = JSON.stringify({
              success: false,
              message: errorMessage,
            });
          }
          console.log(`${logPrefix} update_calendar_event response content for OpenAI:`, toolResultContent);
        }
        break;

      case "delete_calendar_event":
        {
          console.log(`${logPrefix} Tool call execution with args:`, functionArgs);
          const typedArgs = functionArgs as DeleteCalendarEventToolArgs;
          const eventId = typedArgs.event_id;
          const searchTerm = typedArgs.search_term || eventId; // Use search_term if provided, otherwise event_id might be a search term
          const confirmed = typedArgs.confirmed || false;

          const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
          const isProvidedIdUuid = eventId ? uuidRegex.test(eventId) : false;

          if (!eventId || typeof eventId !== 'string' || eventId.trim() === '') {
            toolResultContent = JSON.stringify({
              success: false,
              error: "Invalid event_id or search_term for delete_calendar_event. Please provide an event ID or a search term."
            });
            console.log(`${logPrefix} Delete calendar event: invalid event_id/search_term format.`);
            break;
          }

          // Scenario 1: Confirmed deletion with a valid UUID
          if (isProvidedIdUuid && confirmed) {
            console.log(`${logPrefix} Attempting confirmed deletion for event UUID: ${eventId}`);
            const deleteUrl = `${internalApiBaseUrl}/.netlify/functions/calendar/${encodeURIComponent(eventId)}`;
            try {
              const deleteResponse: Response = await fetch(deleteUrl as RequestInfo, {
                method: 'DELETE',
                headers: internalHeaders as HeadersInit,
              } as RequestInit);
              if (deleteResponse.ok) {
                toolResultContent = JSON.stringify({
                  success: true,
                  message: `Calendar event with ID ${eventId} has been successfully deleted.`
                });
                console.log(`${logPrefix} Successfully deleted event UUID: ${eventId}`);
              } else {
                const errorText = await deleteResponse.text();
                const status = deleteResponse.status;
                console.error(`${logPrefix} Failed to delete event UUID ${eventId}. Status: ${status}, Error: ${errorText}`);
                toolResultContent = JSON.stringify({
                  success: false,
                  message: status === 404 
                    ? `Could not delete. Event with ID ${eventId} not found.` 
                    : `Failed to delete event with ID ${eventId}. Server responded: ${errorText}`,
                  error: `Deletion failed with status ${status}`
                });
              }
            } catch (error) {
              console.error(`${logPrefix} Exception during confirmed deletion of event UUID ${eventId}:`, error);
              toolResultContent = JSON.stringify({
                success: false,
                message: `An unexpected error occurred while trying to delete event with ID ${eventId}.`,
                error: (error instanceof Error ? error.message : String(error))
              });
            }
            break; // Exit delete_calendar_event case
          }

          // Scenario 2: Need to find event (either by non-UUID event_id/search_term, or by UUID but not yet confirmed)
          let eventToConfirm: CalendarEvent | null = null;
          let effectiveSearchTerm = searchTerm;

          if (isProvidedIdUuid && !confirmed) {
            // We have a UUID, but need to fetch details for confirmation
            console.log(`${logPrefix} Event ID ${eventId} is a UUID, fetching details for confirmation.`);
            const fetchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar/${encodeURIComponent(eventId.trim())}`;
            try {
              const response: Response = await fetch(fetchUrl as RequestInfo, { method: 'GET', headers: internalHeaders as HeadersInit } as RequestInit);
              if (response.ok) {
                eventToConfirm = await response.json() as CalendarEvent;
                console.log(`${logPrefix} Found event by UUID for confirmation:`, eventToConfirm);
              } else {
                console.log(`${logPrefix} Event not found by UUID ${eventId} when attempting to get details for confirmation.`);
                 // Proceed to search by title if direct UUID fetch fails (maybe ID was mistyped but resembles UUID)
                 effectiveSearchTerm = eventId; // Use the potentially mistyped UUID as a search term now
              }
            } catch (error) {
              console.error(`${logPrefix} Error fetching event by UUID ${eventId} for confirmation:`, error);
              // Proceed to search by title if direct UUID fetch fails
              effectiveSearchTerm = eventId;
            }
          }
          
          // If eventToConfirm is still null, search by term (either original term, or eventId if it wasn't a UUID or fetch failed)
          if (!eventToConfirm) {
            console.log(`${logPrefix} Searching for event by term: "${effectiveSearchTerm}" for deletion confirmation.`);
            const searchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar?search_term=${encodeURIComponent(effectiveSearchTerm.trim())}`;
            try {
              const response: Response = await fetch(searchUrl as RequestInfo, { method: 'GET', headers: internalHeaders as HeadersInit } as RequestInit);
              if (response.ok) {
                const matchingEvents = await response.json() as CalendarEvent[];
                if (matchingEvents.length === 1) {
                  eventToConfirm = matchingEvents[0];
                  console.log(`${logPrefix} Found single event by search for confirmation:`, eventToConfirm);
                } else if (matchingEvents.length > 1) {
                  toolResultContent = JSON.stringify({
                    success: false,
                    message: `Found multiple events matching "${effectiveSearchTerm}". Please provide more details to clarify which event you mean. Matches: ${matchingEvents.map(e => `"${e.title}"`).join(', ')}`,
                    requires_clarification: true
                  });
                  break;
                } else {
                  console.log(`${logPrefix} No events found by search term: "${effectiveSearchTerm}".`);
                }
              }
            } catch (error) {
              console.error(`${logPrefix} Error searching for event by term "${effectiveSearchTerm}":`, error);
            }
          }

          // Scenario 3: Respond for confirmation or if event not found
          if (eventToConfirm) {
            toolResultContent = JSON.stringify({
              success: true, // Indicates we found an event to confirm
              action_pending: 'confirmation',
              event_id: eventToConfirm.event_id, // CRITICAL: This is the actual UUID
              event_title: eventToConfirm.title,
              message: `Found event: "${eventToConfirm.title}". Please confirm if you want to delete this event.`,
              requires_confirmation: true,
              // Instruct LLM on how to confirm
              next_step_guidance: `To confirm deletion, call 'delete_calendar_event' again with event_id: "${eventToConfirm.event_id}" (this exact UUID) AND confirmed: true.`
            });
          } else {
            toolResultContent = JSON.stringify({
              success: false,
              message: `Could not find a unique calendar event matching "${effectiveSearchTerm}". Please try a different search term or provide the event's unique ID.`,
              error: "Event not found for deletion."
            });
          }
        }
        break;

      default:
        console.warn(`${logPrefix} Unknown tool function: ${functionName}`); // Used logPrefix
        toolResultContent = JSON.stringify({ error: `Unknown tool function: ${functionName}` });
    }
  } catch (error) {
    console.error(`${logPrefix} Error executing tool ${functionName} (ID: ${toolCallId}):`, error); // Used logPrefix
    toolResultContent = JSON.stringify({ error: `Failed to execute tool ${functionName}: ${error instanceof Error ? error.message : String(error)}` });
  }

  return {
    tool_call_id: toolCallId,
    role: "tool" as const,
    content: toolResultContent,
  };
}

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => { // Changed _context to context
  const reqId = context.awsRequestId || `local-cal-${Date.now()}`; // For logging, unique prefix for calendar
  const logPrefix = `[assistant-calendar.ts][ReqID:${reqId}]`;

  console.log(`${logPrefix} Function invoked ---`);
  console.log(`${logPrefix} NETLIFY_LOGS_DEBUG: Function execution started`); // Added for robust logging
  console.log(`${logPrefix} HTTP Method: ${event.httpMethod}`);
  console.log(`${logPrefix} Path: ${event.path}`);
  
  // Log environment variables for troubleshooting if needed
  console.log(`${logPrefix} NETLIFY_ENV: ${process.env.NETLIFY || 'not set'}`); // Uncommented
  console.log(`${logPrefix} NODE_ENV: ${process.env.NODE_ENV || 'not set'}`); // Uncommented

  // Sanitize and log headers (partial)
  const safeHeaders: Record<string, string | undefined> = {};
  for (const key in event.headers) {
    if (key.toLowerCase() === 'authorization') {
      safeHeaders[key] = 'Bearer ***';
    } else if (key.toLowerCase() === 'cookie') {
       safeHeaders[key] = '***';
    } else {
      safeHeaders[key] = event.headers[key];
    }
  }
  console.log(`${logPrefix} Headers (partial): ${JSON.stringify(safeHeaders)}`);


  // CORS headers definition
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*", 
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json"
  };

  // Handle OPTIONS preflight requests
  if (event.httpMethod === 'OPTIONS') {
    console.log(`${logPrefix} Handling OPTIONS preflight request`); // Used logPrefix
    return {
      statusCode: 204,
      headers: {
        ...corsHeaders,
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }

  let userId: string | null = null;
  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  
  if (!OPENAI_API_KEY) {
    console.error(`${logPrefix} OPENAI_API_KEY is not set.`); // Used logPrefix
    return { statusCode: 500, body: JSON.stringify({ error: 'Server configuration error: Missing API key.' }), headers: corsHeaders };
  }

  const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
  const messagesForOpenAI: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [];
  let toolChoiceSetting: OpenAI.Chat.Completions.ChatCompletionToolChoiceOption = 'auto';
  let assistantResponse: OpenAI.Chat.Completions.ChatCompletionMessage | undefined;

  try {
    userId = getUserIdFromEvent(event);
    if (!userId) {
      return { statusCode: 401, body: JSON.stringify({ error: 'User not authenticated or JWT invalid/missing SUB claim.' }), headers: corsHeaders };
    }

    if (!event.body) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ message: "Request body is missing." }) };
    }

    let requestBody: AssistantRequestBody;
    try {
      requestBody = JSON.parse(event.body);
    } catch (error) {
      console.error(`${logPrefix} Error parsing request body:`, error); // Used logPrefix
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ message: "Invalid JSON in request body." }) };
    }

    let currentMessages = requestBody.messages || [];
    currentMessages = currentMessages.filter(msg => {
      if (msg.role === 'user') {
        const content = msg.content;
        const isEmptyOrUndefined = !content || content.trim() === '' || content.trim().toLowerCase() === 'undefined';
        if (isEmptyOrUndefined) {
          console.warn(`${logPrefix} Filtering out empty or 'undefined' user message:`, msg); // Used logPrefix
          return false;
        }
      }
      return true;
    });

    // Define system message
    const currentDateTime = new Date().toISOString();
    const timeZone = requestBody.localTimeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    const userLocalTime = new Date().toLocaleString('en-US', { timeZone });
    const utcOffset = -(new Date().getTimezoneOffset() / 60);
    const utcOffsetStr = utcOffset >= 0 ? `UTC+${utcOffset}` : `UTC${utcOffset}`;
    const hasNoFollowUpConfirmation = requestBody.confirmationContext?.requiresFollowUp === false;

    const systemMessageContent = `You are an expert AI assistant specialized in calendar management. You help users create, find, update, and delete calendar events, including recurring events. You have access to calendar-specific tools to perform these operations.\n\nToday's current date and time is ${userLocalTime} (${currentDateTime} in UTC). The user's local time zone is ${timeZone} (${utcOffsetStr}).\n\n## CRITICAL BEHAVIOR REQUIREMENTS\n1. ALWAYS collect ALL required information upfront in your FIRST response\n2. NEVER ask follow-up questions for optional fields (description, location) after a user confirms\n3. When collecting event information, get REQUIRED fields in one go: title, start time, end time, and is_all_day\n4. For OPTIONAL fields (description, location), ask for them in your FIRST response but proceed if user doesn't provide them\n5. For RECURRING events, you must collect ALL recurrence details when is_recurring=true\n6. When a user confirms, OR WHEN YOU STATE YOU WILL PROCEED, IMMEDIATELY complete the action by including the relevant tool call in your current response. Do not wait for a separate confirmation or a new user message.\n7. Fields that are explicitly marked as optional in the schema should be treated as truly optional\n${hasNoFollowUpConfirmation ? '8. ‼️ CRITICAL INSTRUCTION: The user has confirmed and requested NO additional questions. Complete the current operation IMMEDIATELY without asking for more details. ‼️' : ''}\n\n## IMPORTANT FORMATTING REQUIREMENTS\nYou MUST format ALL responses using proper Markdown formatting. Your responses will be rendered as markdown in the frontend, so this is CRITICAL for readability:\n- Use **bold text** for important information like event titles, dates, and times\n- Use headings (## and ###) to organize sections of your response\n- Present event details in tables when showing multiple events\n- Use bullet points or numbered lists for steps or multiple items\n- Use \`code formatting\` for IDs or technical values\n- Use > blockquotes for important notes or warnings\n\nEVERY response you provide MUST follow these markdown formatting guidelines. If you don't use markdown properly, your responses will be difficult to read.\n\n## Important Time Zone Handling\n- The calendar system stores all dates/times in UTC format in the database\n- When showing times to users, convert from UTC to their local time zone (${timeZone})\n- When users provide times, assume they are in their local time zone and convert to UTC for storage\n- When displaying events in lists or details, ALWAYS follow this exact format with Timezone as a separate line item:\n  * **Title:** Event Title\n  * **Start Time:** May 18, 2025, 6:00 PM - 6:30 PM\n  * **Timezone:** ${timeZone}\n  * **Description:** Event description (if available)\n  * **Location:** Location info (if available)\n  * **Recurrence:** Recurrence pattern (if applicable)\n- If you display UTC times, always explicitly label them as "(UTC)"\n\n## Calendar Operations Guidelines\n\nWhen creating calendar events:\n1. Always use the current year (${new Date().getFullYear()}) for dates unless a specific year is mentioned\n2. Format ISO dates properly with the correct year\n3. For relative dates like "tomorrow" or "next week," calculate them based on today's date: ${new Date().toISOString().split('T')[0]}\n4. Store times in UTC but display them to users in their local time zone (${timeZone})\n5. ALWAYS collect ALL details (including description and location) in your FIRST interaction\n\n## Recurring Event Guidelines\n1. When a user mentions "recurring", "repeating", "weekly", "monthly", etc., proactively ask about recurrence details\n2. For recurring events, collect the following information:\n   - Recurrence pattern (daily, weekly, monthly, yearly)\n   - Recurrence interval (e.g., every 2 weeks)\n   - For weekly: which days of the week (Monday, Tuesday, etc.)\n   - For monthly: which day of the month (1st, 15th, etc.)\n   - For yearly: which month and day\n   - End date or number of occurrences (when does the recurrence end?)\n3. When displaying recurring events, clearly indicate the recurrence pattern\n4. For updating or deleting recurring events, ask if they want to affect just that instance, all future instances, or all instances in the series`;

    const systemMessage: OpenAI.Chat.Completions.ChatCompletionSystemMessageParam = {
      role: 'system',
      content: systemMessageContent,
    };

    // --- Main Logic: Handle Tool Call Result OR New User Message ---
    if (requestBody.tool_call) {
      console.log(`${logPrefix} Received direct tool call execution request from client for: ${requestBody.tool_call.function.name}, ID: ${requestBody.tool_call.id}`); // Used logPrefix
      
      if (!currentMessages || currentMessages.length === 0) {
        const criticalErrorMsg = `[${logPrefix}:CRITICAL] Tool call execution request received from client, but no preceding messages (conversation history) found in requestBody.messages. This is a CLIENT-SIDE BUG. The client MUST send the conversation history. Tool call: ` + JSON.stringify(requestBody.tool_call); // Used logPrefix
        console.error(criticalErrorMsg);
        return { 
          statusCode: 400, 
          headers: corsHeaders, 
          body: JSON.stringify({ 
            error: 'Client-side error: Message history missing for tool call execution.',
            details: 'The server received a tool_call execution request without the preceding conversation messages. This history is essential. Please ensure the client application includes the \'messages\' array in the request body when submitting tool calls for execution.'
          })
        };
      }
      
      const lastMessageInHistory = currentMessages[currentMessages.length - 1];
      if (
        !lastMessageInHistory ||
        lastMessageInHistory.role !== 'assistant' ||
        !lastMessageInHistory.tool_calls ||
        !lastMessageInHistory.tool_calls.some(tc => tc.id === requestBody.tool_call?.id)
      ) {
        console.error(`${logPrefix} CRITICAL CLIENT-SIDE BUG: Tool call execution request for ID '${requestBody.tool_call.id}' received, but the provided message history from the client is missing the preceding assistant message with this tool_call. Aborting. History:`, JSON.stringify(currentMessages)); // Used logPrefix
        return { 
          statusCode: 400, 
          headers: corsHeaders, 
          body: JSON.stringify({ 
            error: 'Invalid conversation history from client for tool call execution.',
            details: `Tool call for ID '${requestBody.tool_call.id}' was submitted for execution, but the message history provided by the client did not contain the required preceding assistant message that originally requested this tool_call. The client must send the complete message history.`,
            expected_tool_call_id_in_last_assistant_message: requestBody.tool_call.id,
            actual_last_message: lastMessageInHistory
          })
        };
      }
      
      // Execute the tool call
      const toolMessageResult = await executeSingleToolCall(
        requestBody.tool_call, 
        event.headers, 
        userId,
        reqId // Pass reqId here
      );
      
      // Return the raw tool result directly to the client
      console.log(`${logPrefix} Executed tool call ${requestBody.tool_call.id}. Returning raw tool result directly to client.`); // Used logPrefix
      // Construct a history that includes the original messages, the assistant's tool request, and this tool's result.
      // This allows the client to have the full context if needed.
      const historyForClientAfterToolExecution = [...currentMessages, toolMessageResult];
      
      return {
        statusCode: 200,
        body: JSON.stringify({
          role: 'tool', // Clearly indicate this is a tool result
          tool_call_id: toolMessageResult.tool_call_id,
          content: toolMessageResult.content, // The raw JSON string content of the tool execution
          name: requestBody.tool_call.function.name, // Include the function name for completeness
          messages: historyForClientAfterToolExecution // Provide the updated history
        }),
        headers: corsHeaders
      };
      // NOTE: The execution path for this branch now ends here and does not proceed to the OpenAI call below.

    } else {
      // This is a regular user message, not a tool call result
      if (!currentMessages || currentMessages.length === 0) {
        // This should ideally not happen if client always sends at least the user message.
        // If it does, it implies an empty request or malformed one.
        console.warn(`${logPrefix} CurrentMessages is empty for a non-tool_call request. This might indicate an issue with client sending empty messages array.`); // Used logPrefix
        // We must have at least one user message to proceed. If not, it's an error.
        // However, the prompt filtering above might make currentMessages empty if the user message was just "undefined"
        // For now, let's assume if it's empty here, we should just send system + the (empty) currentMessages.
        // OpenAI might complain if the last message isn't 'user'. This needs robust handling.
        // For now, if currentMessages is empty after filtering, it's likely an issue.
         return { statusCode: 400, body: JSON.stringify({ error: 'Messages array is effectively empty after filtering, for a non-tool_call request.' }), headers: corsHeaders };
      }

      // For new user messages, prepend our standard system message.
      messagesForOpenAI.push(systemMessage);
      messagesForOpenAI.push(...currentMessages); // currentMessages should end with the latest user message.
      
      console.log(`${logPrefix} Processing regular user message. Total messages for OpenAI: ${messagesForOpenAI.length}`); // Used logPrefix

      const latestUserMessageContent = currentMessages.filter(msg => msg.role === 'user').pop()?.content;
      console.log(`${logPrefix} Most recent user message content: "${latestUserMessageContent}"`); // Used logPrefix

      if (latestUserMessageContent === 'Find all my calendar events.') {
        toolChoiceSetting = { type: "function", function: { name: "find_calendar_events" } };
        console.log(`${logPrefix} Forcing tool_choice to 'find_calendar_events' for the generic event fetch query.`); // Used logPrefix
      }
    }
    
    // Log the messages being sent to OpenAI for debugging
    console.log(`${logPrefix} Messages being sent to OpenAI:`, JSON.stringify(messagesForOpenAI, null, 2)); // Used logPrefix

    const modelToUse = process.env.OPENAI_MODEL || 'gpt-4o-mini';
    console.log(`${logPrefix} Making API call to OpenAI with model: ${modelToUse}, Tool choice: ${typeof toolChoiceSetting === 'string' ? toolChoiceSetting : JSON.stringify(toolChoiceSetting)}`); // Used logPrefix

    const chatCompletion = await openai.chat.completions.create({
      model: modelToUse,
      messages: messagesForOpenAI,
      tools: tools,
      tool_choice: toolChoiceSetting,
    });

    assistantResponse = chatCompletion.choices[0]?.message;

    if (!assistantResponse) {
      console.error(`${logPrefix} No response message received from OpenAI.`); // Used logPrefix
      return { statusCode: 500, body: JSON.stringify({ error: 'No response message received from OpenAI.' }), headers: corsHeaders };
    }

    // If OpenAI requests tool calls, these are returned to the client.
    // If it's a text response (after a tool result or a direct answer), that's also returned.
    console.log(`${logPrefix} Received response from OpenAI. Tool calls present: `, !!assistantResponse.tool_calls); // Used logPrefix

    if (assistantResponse.tool_calls && assistantResponse.tool_calls.length > 0) {
      // If there are tool calls, send back the tool_calls object AND the message history
      // The history sent to the client MUST include the assistant's message that contains the tool_calls.
      const historyForClient: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [...messagesForOpenAI, assistantResponse];
      console.log(`${logPrefix} OpenAI requested tool calls. Sending tool_calls and COMPLETE message history (including assistant message with tool_calls) to client.`); // Used logPrefix
      return {
        statusCode: 200,
        body: JSON.stringify({
          role: assistantResponse.role,
          content: assistantResponse.content,
          tool_calls: assistantResponse.tool_calls,
          messages: historyForClient // Send the updated history
        }),
        headers: corsHeaders
      };
    } else {
      // If no tool calls (e.g., a direct text response), just send the assistant's message
      // Also include the history that led to this response for client-side state management.
      const historyForClient: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [...messagesForOpenAI, assistantResponse];
      console.log(`${logPrefix} OpenAI provided a direct text response. Sending to client with history.`); // Used logPrefix
      return {
        statusCode: 200,
        body: JSON.stringify({
          role: assistantResponse.role,
          content: assistantResponse.content,
          // No tool_calls in this branch
          messages: historyForClient // Also include history here
        }),
        headers: corsHeaders
      };
    }

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred.';
    console.error(`${logPrefix} Error in handler:`, errorMessage, error); // Used logPrefix
    // Log the messagesForOpenAI array if an error occurs after it's populated
    if (messagesForOpenAI.length > 0) {
      console.error(`${logPrefix} Messages sent to OpenAI during error: `, JSON.stringify(messagesForOpenAI, null, 2)); // Used logPrefix
    }
    return { statusCode: 500, body: JSON.stringify({ error: errorMessage }), headers: corsHeaders };
  }
};

export { handler };
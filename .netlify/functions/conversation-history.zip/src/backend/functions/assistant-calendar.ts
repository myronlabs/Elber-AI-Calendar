import type { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";
import OpenAI from 'openai';
// @ts-ignore
import fetch from 'node-fetch'; // For making internal HTTP requests
import { jwtDecode } from 'jwt-decode'; // Import jwt-decode
// Define CalendarEvent interface inline to avoid import issues
interface CalendarEvent {
  event_id: string;
  user_id: string;
  title: string;
  start_time: string;
  end_time: string;
  created_at: string;
  updated_at: string;
  is_all_day: boolean;
  description?: string | null;
  location?: string | null;
  google_event_id?: string | null;
  zoom_meeting_id?: string | null;
}

// Interface for the decoded JWT payload
interface DecodedJwt {
  sub?: string; // Subject (user ID)
  [key: string]: any; // Allow other claims
}

// Helper function to get authenticated user ID from JWT
const getUserIdFromEvent = (event: HandlerEvent): string | null => { 
  const authHeader = event.headers?.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7); // Remove "Bearer " prefix
    try {
      const decodedToken = jwtDecode<DecodedJwt>(token);
      if (decodedToken && decodedToken.sub) {
        console.log(`[assistant-calendar.ts] Extracted user ID (sub): ${decodedToken.sub} from JWT.`);
        return decodedToken.sub;
      } else {
        console.warn('[assistant-calendar.ts] JWT decoded but did not contain a sub (user ID) claim.', decodedToken);
        return null;
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error during JWT decoding.';
      console.error(`[assistant-calendar.ts] Error decoding JWT: ${errorMessage}`, error);
      return null;
    }
  }
  console.warn('[assistant-calendar.ts] No Authorization header with Bearer token found.');
  return null; 
};

// Helper function to validate UUID format
const isValidUUID = (uuid: string): boolean => {
  if (!uuid) return false;
  const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
  return uuidRegex.test(uuid);
};

// Helper function to process date strings
const processDate = (dateString: string, label: string): string => {
  console.log(`[assistant-calendar.ts] Processing date for ${label}: initial value = "${dateString}"`);
  if (!dateString || dateString.trim() === '') {
    console.warn(`[assistant-calendar.ts] processDate: Received empty or null date string for ${label}. Returning empty string.`);
    return '';
  }

  // Attempt to parse common natural language terms first
  const now = new Date();
  const lowerCaseDateString = dateString.toLowerCase();

  if (lowerCaseDateString.includes('today') || lowerCaseDateString.includes('now')) {
    // More sophisticated date parsing might be needed if time is included, e.g., "today at 5pm"
    // For now, simple 'today' implies the current date at the beginning or end of day based on context
    // Let's assume for now that if it's 'today', the time component is handled separately or is not critical here.
    const todayStr = now.toISOString();
    console.log(`[assistant-calendar.ts] processDate: Interpreted "${dateString}" as today. ISO: ${todayStr} for ${label}`);
    return todayStr;
  }
  if (lowerCaseDateString.includes('tomorrow')) {
    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString();
    console.log(`[assistant-calendar.ts] processDate: Interpreted "${dateString}" as tomorrow. ISO: ${tomorrowStr} for ${label}`);
    return tomorrowStr;
  }
  // Add more natural language processing here if needed (e.g., 'next Monday', 'end of month')

  // If not a recognized natural language term, try to parse as ISO or other common formats
  try {
    const date = new Date(dateString); // Try to parse directly
    if (!isNaN(date.getTime())) {
      const isoDate = date.toISOString();
      console.log(`[assistant-calendar.ts] processDate: Parsed "${dateString}" to ISO: ${isoDate} for ${label}`);
      return isoDate;
    }
  } catch (e) {
    console.warn(`[assistant-calendar.ts] processDate: Could not parse "${dateString}" as a standard date for ${label}. Error: ${e}`);
  }
  
  // Fallback: If LLM provides a specific time like "10:00 AM" without a date, this function might not be the best place to handle it.
  // The LLM should be prompted to provide full date-time strings in ISO format or clear natural language.
  // If it's just a time, it might need to be combined with a date (e.g., today's date).
  // For now, if it's not parsable as a full date, return the original string and let the backend API handle it, or log a warning.
  console.warn(`[assistant-calendar.ts] processDate: Could not robustly parse "${dateString}" for ${label}. Returning original string. Consider refining LLM prompt for date formats.`);
  return dateString; // Fallback to original string if specific parsing fails
};

// Helper function to check if a string is a UUID
const isUUID = (id: string): boolean => {
  const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
  return uuidRegex.test(id);
};

// Helper function to get the base URL for internal API calls
const getInternalApiBaseUrl = (): string => {
  const context = process.env.CONTEXT;
  // CONTEXT will be 'dev' for local development (netlify dev)
  //           'branch-deploy' for branch deploys
  //           'deploy-preview' for deploy previews
  //           'production' for the main production site
  if (context === 'dev') {
    return process.env.URL || 'http://localhost:8888'; 
  } else if (process.env.DEPLOY_PRIME_URL) {
    // DEPLOY_PRIME_URL is available for deploy previews and production deploys
    // It represents the primary URL for that deploy (e.g., unique-preview-url.netlify.app or your-production-site.netlify.app)
    return process.env.DEPLOY_PRIME_URL;
  } else if (process.env.URL) {
    // URL is the main canonical URL of the site (less specific than DEPLOY_PRIME_URL for previews)
    return process.env.URL;
  }
  // Fallback if context is somehow not one of the expected Netlify contexts
  console.warn('[assistant-calendar.ts] Could not robustly determine Netlify API base URL, defaulting to localhost. CONTEXT:', context);
  return 'http://localhost:8888'; 
};

// Helper function to prepare request headers
function getInternalHeaders(eventHeaders: {[key: string]: string | undefined} = {}): Record<string, string> {
  return {
    'Content-Type': 'application/json',
    'Authorization': eventHeaders.authorization || '' // Forward existing auth
  };
}

// Define message types based on OpenAI's message formats
type ChatMessage =
  | { role: 'user'; content: string; tool_calls?: never; tool_call_id?: never; }
  | { role: 'assistant'; content: string | null; tool_calls?: OpenAI.Chat.Completions.ChatCompletionMessageToolCall[]; tool_call_id?: never; }
  | { role: 'system'; content: string; tool_calls?: never; tool_call_id?: never; }
  | { role: 'tool'; content: string; tool_call_id: string; tool_calls?: never; };

interface AssistantRequestBody {
  messages?: ChatMessage[];
  tool_call?: DirectToolCall;
  localTimeZone?: string; // Add this field to receive client time zone
}

// Calendar-specific tool function argument types
interface CreateCalendarEventToolArgs {
  title: string;
  start_time: string;
  end_time: string;
  description: string | null;
  location: string | null;
  is_all_day: boolean;
}

interface FindCalendarEventsToolArgs {
  search_term?: string; // General search term for title, description, location
  start_date?: string;  // ISO format or natural language (e.g., 'today', 'next week')
  end_date?: string;    // ISO format or natural language
  event_id?: string;    // Specific event ID to find (can also be a title if ID is not known)
}

interface UpdateCalendarEventToolArgs {
  event_id: string; // Mandatory: ID of the event to update. LLM should find it first if not provided by user.
  title: string; // Mandatory: The title of the event. If you are changing the title, provide the new title here. If you are not changing the title, provide the event's current title.
  start_time?: string;
  end_time?: string;
  description?: string | null;
  location?: string | null;
  is_all_day?: boolean;
}

interface DeleteCalendarEventToolArgs {
  event_id: string; // Event ID or identifier like title
  search_term?: string; // Optional search term to use instead of event_id
  confirmed?: boolean; // Optional confirmation flag
}

// All possible calendar tool function arguments
type ToolFunctionArgs = 
  CreateCalendarEventToolArgs |
  FindCalendarEventsToolArgs |
  UpdateCalendarEventToolArgs |
  DeleteCalendarEventToolArgs;

// Define an interface for the direct tool call object sent by AssistantPage.tsx
// This should match the structure of OpenAI.Chat.Completions.ChatCompletionMessageToolCall
interface DirectToolCall {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string; // Arguments are stringified JSON
  };
}

// Define the calendar-specific tools for OpenAI
const tools: OpenAI.Chat.Completions.ChatCompletionTool[] = [
  {
    type: "function",
    function: {
      name: "create_calendar_event",
      description: "Creates a new calendar event with the provided details.",
      strict: true,
      parameters: {
        type: "object",
        properties: {
          title: {
            type: "string",
            description: "Title of the calendar event."
          },
          start_time: {
            type: "string",
            description: "Start time of the event in ISO format or natural language (e.g., 'May 10th at 06:00 PM')."
          },
          end_time: {
            type: "string",
            description: "End time of the event in ISO format or natural language (e.g., 'May 10th at 06:30 PM')."
          },
          description: {
            type: ["string", "null"],
            description: "Optional description of the event."
          },
          location: {
            type: ["string", "null"],
            description: "Optional location of the event."
          },
          is_all_day: {
            type: "boolean",
            description: "Whether the event is an all-day event. If not provided, will be treated as false."
          }
        },
        required: ["title", "start_time", "end_time", "description", "location", "is_all_day"],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "find_calendar_events",
      description: "Searches for calendar events based on the provided criteria.",
      parameters: {
        type: "object",
        properties: {
          search_term: {
            type: "string",
            description: "General search term for title, description, location."
          },
          start_date: {
            type: "string",
            description: "Start date of the event in ISO format or natural language (e.g., 'today', 'next week')."
          },
          end_date: {
            type: "string",
            description: "End date of the event in ISO format or natural language."
          },
          event_id: {
            type: "string",
            description: "Specific event ID to find (can also be a title if ID is not known)."
          },
        },
        required: [],
        additionalProperties: false
      },
    },
  },
  {
    type: "function",
    function: {
      name: "update_calendar_event",
      description: "Updates an existing calendar event. Identify the event using event_id (UUID preferred, or current title if event_id is not a UUID). The 'title' parameter must always be provided (current title if unchanged, new title if changing). Other fields are optional and only updated if provided.",
      parameters: {
        type: "object",
        properties: {
          event_id: {
            type: "string",
            description: "The ID (UUID) of the event to update. Alternatively, if not using a UUID, this can be the current title of the event for lookup purposes (especially if the title itself is not being changed)."
          },
          title: { 
            type: "string", 
            description: "The title of the event. If you are changing the title, provide the new title here. If you are not changing the title, provide the event's current title." 
          },
          start_time: { type: "string", description: "The new start date and time in ISO 8601 format (e.g., '2024-07-21T10:00:00Z') or natural language (e.g., 'next Monday at 10am'). Processed by processDate." },
          end_time: { type: "string", description: "The new end date and time in ISO 8601 format or natural language. Processed by processDate." },
          description: { type: "string", description: "The new description for the event." },
          location: { type: "string", description: "The new location of the event." },
          is_all_day: { type: "boolean", description: "Set to true if the event is an all-day event." },
        },
        required: ["event_id", "title"],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "delete_calendar_event",
      description: "Deletes a calendar event. If a non-UUID (e.g., event title) is provided as 'event_id', the system will search for the event. If a single event is found, it will return the event's details and its actual UUID, asking for confirmation. To confirm and delete, call this function again with the 'event_id' set to the actual UUID of the event and 'confirmed' set to true. If 'event_id' is already a UUID, the event will be deleted directly if 'confirmed' is true.",
      parameters: {
        type: "object",
        properties: {
          event_id: {
            type: "string",
            description: "The UUID of the event to delete, or a search term (e.g., event title). If a search term is used and a unique event is found, you will be prompted to call this function again with the event's actual UUID to confirm deletion." 
          },
          search_term: {
            type: "string",
            description: "Optional search term to use instead of event_id."
          },
          confirmed: {
            type: "boolean",
            description: "Optional confirmation flag. If true, the event will be deleted if event_id is a valid UUID."
          },
        },
        required: ["event_id"],
        additionalProperties: false
      },
    },
  }
];

// Main function to execute calendar tool calls
async function executeSingleToolCall(
  toolCall: OpenAI.Chat.Completions.ChatCompletionMessageToolCall,
  eventHeaders: HandlerEvent['headers'],
  userId: string | null
): Promise<OpenAI.Chat.Completions.ChatCompletionToolMessageParam> {
  const functionName = toolCall.function.name;
  let functionArgs: ToolFunctionArgs;

  try {
    functionArgs = JSON.parse(toolCall.function.arguments) as ToolFunctionArgs;
  } catch (e) {
    console.error(`Error parsing arguments for tool ${functionName} (ID: ${toolCall.id}): ${toolCall.function.arguments}`, e);
    return {
      tool_call_id: toolCall.id,
      role: "tool" as const,
      content: JSON.stringify({ error: "Failed to parse function arguments.", details: (e instanceof Error ? e.message : String(e)) }),
    };
  }

  console.log(`[assistant-calendar.ts] Executing tool call ID: ${toolCall.id}, Function: ${functionName}, Args:`, functionArgs);

  let toolResultContent = "";
  const internalApiBaseUrl = getInternalApiBaseUrl();
  const internalHeaders = getInternalHeaders(eventHeaders);

  try {
    switch (functionName) {
      case "create_calendar_event":
        {
          console.log(`[assistant-calendar.ts] Tool call execution: create_calendar_event with args:`, functionArgs);
          const typedArgs = functionArgs as CreateCalendarEventToolArgs;

          // Enhanced logging for better troubleshooting
          console.log(`[assistant-calendar.ts] Processing create calendar event with title: "${typedArgs.title}"`);
          console.log(`[assistant-calendar.ts] Event time range: ${typedArgs.start_time} to ${typedArgs.end_time}`);
          console.log(`[assistant-calendar.ts] Event description: "${typedArgs.description || ''}"`);

          // Additional validation for required fields
          if (!typedArgs.title || !typedArgs.start_time || !typedArgs.end_time) {
            console.error(`[assistant-calendar.ts] Missing required fields for calendar event creation`);
            toolResultContent = JSON.stringify({
              success: false,
              error: "Missing required fields",
              message: "Calendar event creation failed. Title, start time, and end time are required."
            });
            break;
          }

          // Process and standardize date/time strings for backend compatibility
          let startTime = typedArgs.start_time;
          let endTime = typedArgs.end_time;

          // Double-check and convert dates if needed (as a backup in case the LLM doesn't use the correct year)
          try {
            // Get current year for properly setting dates
            const currentYear = new Date().getFullYear();
            const currentDate = new Date();

            const processDate = (dateString: string, label: string): string => {
              // If already in ISO format, check if year needs correction
              if (dateString.includes('T') || dateString.match(/^\d{4}-\d{2}-\d{2}/)) {
                const date = new Date(dateString);
                if (!isNaN(date.getTime())) {
                  // Check if year is too far in the past or future (more than 1 year difference)
                  if (Math.abs(date.getFullYear() - currentYear) > 1) {
                    console.log(`[assistant-calendar.ts] ${label}: Year ${date.getFullYear()} seems incorrect, updating to ${currentYear}`);
                    date.setFullYear(currentYear);
                    return date.toISOString();
                  }
                  return dateString; // Already valid ISO with reasonable year
                }
              }

              // Not ISO format - convert from natural language
              console.log(`[assistant-calendar.ts] Converting natural language ${label} to ISO: "${dateString}"`);

              // Try to parse with special cases for relative dates
              let date;
              const lowerDate = dateString.toLowerCase();

              if (lowerDate.includes('tomorrow')) {
                date = new Date(currentDate);
                date.setDate(date.getDate() + 1);
              }
              else if (lowerDate.includes('next week')) {
                date = new Date(currentDate);
                date.setDate(date.getDate() + 7);
              }
              else if (lowerDate.includes('next month')) {
                date = new Date(currentDate);
                date.setMonth(date.getMonth() + 1);
              }
              else if (lowerDate.match(/next (mon|tues|wednes|thurs|fri|satur|sun)day/)) {
                // Parse "next Monday", "next Tuesday", etc.
                const dayMap: {[key: string]: number} = {
                  'sunday': 0, 'sun': 0,
                  'monday': 1, 'mon': 1,
                  'tuesday': 2, 'tues': 2,
                  'wednesday': 3, 'wednes': 3,
                  'thursday': 4, 'thurs': 4,
                  'friday': 5, 'fri': 5,
                  'saturday': 6, 'satur': 6
                };

                let targetDay = -1;
                for (const [key, value] of Object.entries(dayMap)) {
                  if (lowerDate.includes(key)) {
                    targetDay = value;
                    break;
                  }
                }

                if (targetDay !== -1) {
                  date = new Date(currentDate);
                  const currentDay = date.getDay();
                  let daysToAdd = targetDay - currentDay;
                  if (daysToAdd <= 0) daysToAdd += 7; // Ensure we get next week
                  date.setDate(date.getDate() + daysToAdd);
                } else {
                  date = new Date(dateString);
                }
              }
              else {
                // Standard parsing for other dates
                date = new Date(dateString);
              }

              // Validate and fix the parsed date
              if (!isNaN(date.getTime())) {
                // If date is in the past or far future, adjust the year
                if (Math.abs(date.getFullYear() - currentYear) > 1) {
                  console.log(`[assistant-calendar.ts] ${label}: Correcting year from ${date.getFullYear()} to ${currentYear}`);
                  date.setFullYear(currentYear);
                }

                const result = date.toISOString();
                console.log(`[assistant-calendar.ts] Converted ${label}: ${result}`);
                return result;
              }

              // If we couldn't parse it, return original string and let backend handle it
              console.log(`[assistant-calendar.ts] Couldn't convert ${label} to date: ${dateString}`);
              return dateString;
            };

            // Process both start and end times
            startTime = processDate(startTime, 'start time');
            endTime = processDate(endTime, 'end time');
          } catch (error) {
            console.error(`[assistant-calendar.ts] Error converting time strings:`, error);
            // Continue with original strings if conversion fails
          }

          // Check for duplicates first - similar to how contacts are handled
          const searchStartDate = new Date(startTime);
          // Adjust search time range - look for events within a 2-hour window of the requested time
          searchStartDate.setHours(searchStartDate.getHours() - 2);
          const searchStartDateISO = searchStartDate.toISOString();

          const searchEndDate = new Date(endTime);
          searchEndDate.setHours(searchEndDate.getHours() + 2);
          const searchEndDateISO = searchEndDate.toISOString();

          // Construct search query params
          const searchParams = new URLSearchParams();
          searchParams.append('search_term', typedArgs.title);
          searchParams.append('start_date', searchStartDateISO);
          searchParams.append('end_date', searchEndDateISO);

          // First, check if a similar event already exists (same title, around same time)
          const internalApiBaseUrl = getInternalApiBaseUrl();
          const searchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar?${searchParams.toString()}`;
          console.log(`[assistant-calendar.ts] Checking for duplicate events: ${searchUrl}`);

          const searchResponse = await fetch(searchUrl, {
            method: 'GET',
            headers: internalHeaders
          });

          if (searchResponse.ok) {
            const potentialDuplicates = await searchResponse.json();

            if (Array.isArray(potentialDuplicates) && potentialDuplicates.length > 0) {
              console.log(`[assistant-calendar.ts] Found ${potentialDuplicates.length} potential duplicate events`);

              // Check for actual duplicates (same title within close time range)
              const duplicates = potentialDuplicates.filter(event => {
                // Check for exact duplicate by title (case-insensitive)
                const eventTitle = event.title?.toLowerCase() === typedArgs.title.toLowerCase();

                // Get time values in minutes for comparison
                const eventStartTime = new Date(event.start_time).getTime();
                const requestedStartTime = new Date(startTime).getTime();
                const timeDifference = Math.abs(eventStartTime - requestedStartTime) / (1000 * 60); // difference in minutes

                // Check date as well (day, month, year)
                const eventDate = new Date(event.start_time);
                const requestedDate = new Date(startTime);
                const sameDate =
                  eventDate.getFullYear() === requestedDate.getFullYear() &&
                  eventDate.getMonth() === requestedDate.getMonth() &&
                  eventDate.getDate() === requestedDate.getDate();

                // Return true if it's the same title on the same day and within 60 minutes
                return eventTitle && sameDate && timeDifference < 60;
              });

              if (duplicates.length > 0) {
                const duplicate = duplicates[0];
                console.log(`[assistant-calendar.ts] Found exact duplicate: ${duplicate.title} at ${duplicate.start_time}`);

                // Format dates for user-friendly message
                const duplicateDate = new Date(duplicate.start_time);
                const formattedDuplicateTime = duplicateDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const formattedDuplicateDate = duplicateDate.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });

                // Return information about duplicate with improved message
                toolResultContent = JSON.stringify({
                  success: false,
                  duplicate_found: true,
                  message: `An event with the same title "${duplicate.title}" already exists on ${formattedDuplicateDate} at ${formattedDuplicateTime}. To avoid duplicates, please update the existing event or choose a different time/title.`,
                  existing_event_id: duplicate.event_id,
                  event: duplicate
                });
                break;
              }
            }
          }

          // If no duplicates found, proceed with creating the event
          const calendarPayload = {
            title: typedArgs.title,
            start_time: startTime,
            end_time: endTime,
            description: typedArgs.description || null,
            location: typedArgs.location || null,
            is_all_day: typedArgs.is_all_day,
            user_id: userId // Pass the user ID to associate the event with the user
          };

          const internalFetchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar`;
          console.log(`[assistant-calendar.ts] No duplicates found. Calling calendar API at: ${internalFetchUrl}`);

          const internalResponse = await fetch(internalFetchUrl, {
            method: 'POST',
            headers: internalHeaders,
            body: JSON.stringify(calendarPayload),
          });

          const rawResponse = await internalResponse.text();

          if (!internalResponse.ok) {
            console.error(`[assistant-calendar.ts] Error from internal ${functionName} call: ${internalResponse.status} ${internalResponse.statusText}`, rawResponse);
            let errorObj;
            try {
              errorObj = JSON.parse(rawResponse);
              console.error(`[assistant-calendar.ts] Parsed error response:`, errorObj);

              // Provide a better error message
              toolResultContent = JSON.stringify({
                success: false,
                error: `Failed to create calendar event: ${errorObj.message || 'Unknown error'}`,
                details: errorObj
              });
            } catch (e) {
              console.error(`[assistant-calendar.ts] Failed to parse error response:`, e);
              toolResultContent = JSON.stringify({
                success: false,
                error: `Internal ${functionName} failed with status ${internalResponse.status}`,
                details: rawResponse
              });
            }
          } else {
            // Success case
            console.log(`[assistant-calendar.ts] Successfully created calendar event. Raw response: ${rawResponse}`);

            let eventData;
            try {
              eventData = JSON.parse(rawResponse);
              console.log(`[assistant-calendar.ts] Parsed successful response:`, eventData);

              // Return a formatted response for the user
              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${eventData.title}" successfully created.`,
                event: eventData,
                event_id: eventData.event_id
              });
            } catch (e) {
              console.error(`[assistant-calendar.ts] Error parsing successful response:`, e);
              // Even if we can't parse the response JSON, still treat it as a success if the HTTP status was OK
              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${typedArgs.title}" was successfully created.`,
                event_id: typedArgs.title,
                event: rawResponse
              });
            }
          }
        }
        break;

      case "find_calendar_events":
        {
          console.log(`[assistant-calendar.ts] Tool call execution: find_calendar_events with args:`, functionArgs);
          const typedArgs = functionArgs as FindCalendarEventsToolArgs;
          let apiUrl = `${internalApiBaseUrl}/.netlify/functions/calendar`; // Fixed URL to use correct Netlify function path
          const queryParams = new URLSearchParams();

          if (typedArgs.event_id) {
            // If event_id is provided and is a UUID, use it as a path parameter
            // Otherwise, treat it as a search term for the query parameter
            if (isValidUUID(typedArgs.event_id)) {
              apiUrl = `${internalApiBaseUrl}/.netlify/functions/calendar/${encodeURIComponent(typedArgs.event_id)}`; // Corrected: target 'calendar' function
              console.log(`[assistant-calendar.ts] find_calendar_events: searching by specific event_id (UUID): ${typedArgs.event_id}`);
            } else {
              // Non-UUID event_id is treated as a general search term
              queryParams.append('search_term', typedArgs.event_id);
              console.log(`[assistant-calendar.ts] find_calendar_events: event_id "${typedArgs.event_id}" is not a UUID, treating as search_term.`);
            }
          } else {
            // Only add other params if event_id was not a UUID path param
            if (typedArgs.search_term) {
              queryParams.append('search_term', typedArgs.search_term);
              console.log(`[assistant-calendar.ts] find_calendar_events: using search_term: "${typedArgs.search_term}"`);
            }
            if (typedArgs.start_date) {
              const processedStartDate = processDate(typedArgs.start_date, 'start_date');
              if (processedStartDate) queryParams.append('start_date', processedStartDate);
              console.log(`[assistant-calendar.ts] find_calendar_events: using start_date: "${processedStartDate}" (original: "${typedArgs.start_date}")`);
            }
            if (typedArgs.end_date) {
              const processedEndDate = processDate(typedArgs.end_date, 'end_date');
              if (processedEndDate) queryParams.append('end_date', processedEndDate);
              console.log(`[assistant-calendar.ts] find_calendar_events: using end_date: "${processedEndDate}" (original: "${typedArgs.end_date}")`);
            }
          }

          const queryString = queryParams.toString();
          if (queryString) {
            apiUrl += `?${queryString}`;
          }

          console.log(`[assistant-calendar.ts] find_calendar_events: Calling internal API: ${apiUrl}`);

          try {
            const response = await fetch(apiUrl, {
              method: 'GET',
              headers: internalHeaders,
            });

            const responseBody = await response.text(); // Get raw text to handle both JSON and errors
            console.log(`[assistant-calendar.ts] find_calendar_events: Internal API response status: ${response.status}`);
            // console.log(`[assistant-calendar.ts] find_calendar_events: Internal API response body: ${responseBody}`);

            if (!response.ok) {
              console.error(`[assistant-calendar.ts] find_calendar_events: Internal API error. Status: ${response.status}, Body: ${responseBody}`);
              // Try to parse as JSON for a structured error message, otherwise use the raw body
              try {
                const errorJson = JSON.parse(responseBody);
                toolResultContent = JSON.stringify({ 
                  success: false, 
                  error: `Internal API Error: ${response.status}`, 
                  message: errorJson.message || 'Failed to fetch calendar events from internal API.',
                  details: errorJson 
                });
              } catch (parseError) {
                toolResultContent = JSON.stringify({ 
                  success: false, 
                  error: `Internal API Error: ${response.status}`, 
                  message: 'Failed to fetch calendar events and parse error response.',
                  details: responseBody
                });
              }
            } else {
              // Attempt to parse as JSON, as calendar.ts should return JSON array
              try {
                const events = JSON.parse(responseBody);
                if (Array.isArray(events) && events.length === 0) {
                  toolResultContent = JSON.stringify({ 
                    success: true, 
                    data: [], 
                    message: "No calendar events found matching your criteria." 
                  });
                } else {
                  toolResultContent = JSON.stringify({ success: true, data: events });
                }
              } catch (parseError) {
                console.error(`[assistant-calendar.ts] find_calendar_events: Error parsing successful response from internal API: ${parseError}. Body: ${responseBody}`);
                toolResultContent = JSON.stringify({
                  success: false,
                  error: "Response parsing error",
                  message: "Successfully called API, but failed to parse the events response.",
                  details: responseBody
                });
              }
            }
          } catch (fetchError: any) {
            console.error(`[assistant-calendar.ts] find_calendar_events: Fetch error calling internal API: ${fetchError.message}`, fetchError);
            toolResultContent = JSON.stringify({ 
              success: false, 
              error: "Internal fetch error", 
              message: `Failed to communicate with the internal calendar service: ${fetchError.message}` 
            });
          }
          break;
        }

      case "update_calendar_event":
        {
          console.log(`[assistant-calendar.ts] Tool call execution: update_calendar_event with args:`, functionArgs);
          let typedArgs = functionArgs as UpdateCalendarEventToolArgs;

          const processedStartTime = typedArgs.start_time ? processDate(typedArgs.start_time, 'update start time') : undefined;
          const processedEndTime = typedArgs.end_time ? processDate(typedArgs.end_time, 'update end time') : undefined;

          // Check if the event ID is not a valid UUID - if so, treat it as a title search
          const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
          if (typedArgs.event_id && !uuidRegex.test(typedArgs.event_id)) {
            // If event_id is not a UUID, it might be a title or some other identifier passed by the LLM.
            // We'll use this as a search_term to find the actual event_id.
            // The LLM should ideally call find_calendar_events first if unsure about the ID.
            const potentialTitle = typedArgs.event_id; // Assume the non-UUID event_id is the title to search for.
            console.log(`[assistant-calendar.ts] Detected non-UUID event_id: "${potentialTitle}". Attempting to find event by this identifier.`);

            const findParams = new URLSearchParams();
            findParams.append('search_term', potentialTitle);
            // Potentially add date context if available from original user query, though LLM should manage this.

            const searchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar?${findParams.toString()}`;
            console.log(`[assistant-calendar.ts] Searching for actual event ID: ${searchUrl}`);

            try {
              const searchResponse = await fetch(searchUrl, {
                method: 'GET',
                headers: internalHeaders,
              });

              if (searchResponse.ok) {
                const matchingEvents = await searchResponse.json();
                console.log(`[assistant-calendar.ts] Found ${matchingEvents.length} events matching title "${potentialTitle}"`);

                if (Array.isArray(matchingEvents) && matchingEvents.length === 1) {
                  const actualEvent = matchingEvents[0];
                  console.log(`[assistant-calendar.ts] Found unique event. Replacing non-UUID event_id "${potentialTitle}" with actual UUID: ${actualEvent.event_id}`);
                  typedArgs = { ...typedArgs, event_id: actualEvent.event_id }; // Update args with the real event_id
                } else if (Array.isArray(matchingEvents) && matchingEvents.length > 1) {
                  console.warn(`[assistant-calendar.ts] Multiple events found for identifier "${potentialTitle}". Update cannot proceed without a unique event_id.`);
                  toolResultContent = JSON.stringify({
                    success: false,
                    error: `Multiple events found matching "${potentialTitle}". Please provide a unique event_id or more specific criteria.`,
                  });
                  // Early exit if multiple events found
                  return {
                    tool_call_id: toolCall.id,
                    role: "tool" as const,
                    content: toolResultContent,
                  };
                } else {
                  console.warn(`[assistant-calendar.ts] No event found for identifier "${potentialTitle}".`);
                  toolResultContent = JSON.stringify({
                    success: false,
                    error: `No event found matching "${potentialTitle}". Cannot update.`,
                  });
                  // Early exit if no event found
                  return {
                    tool_call_id: toolCall.id,
                    role: "tool" as const,
                    content: toolResultContent,
                  };
                }
              } else {
                 console.warn(`[assistant-calendar.ts] Search for actual event_id failed with status: ${searchResponse.status}`);
              }
            } catch (error) {
              console.error(`[assistant-calendar.ts] Error looking up event by identifier "${potentialTitle}":`, error);
              // If search fails, might still proceed if LLM insists, but it's risky. Better to error out.
               toolResultContent = JSON.stringify({
                 success: false,
                 error: `Error occurred while trying to find event by identifier "${potentialTitle}".`,
               });
               return {
                 tool_call_id: toolCall.id,
                 role: "tool" as const,
                 content: toolResultContent,
               };
            }
          }

          // Log the event ID for debugging - it might have been updated above
          console.log(`[assistant-calendar.ts] Attempting to update calendar event ID '${typedArgs.event_id}'`);

          // Check again if event_id is now a valid UUID before proceeding
          if (!uuidRegex.test(typedArgs.event_id)) {
            console.error(`[assistant-calendar.ts] Invalid or unresolved event_id for update: "${typedArgs.event_id}"`);
            toolResultContent = JSON.stringify({
                success: false,
                error: `Cannot update event. The event_id "${typedArgs.event_id}" is not a valid UUID and could not be resolved to a unique event.`,
            });
            return {
                tool_call_id: toolCall.id,
                role: "tool" as const,
                content: toolResultContent,
            };
          }

          // Create a unique identifier for this specific update request for tracking
          const requestId = `update_calendar_req_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
          console.log(`[assistant-calendar.ts] Update calendar request ${requestId} for event ID ${typedArgs.event_id}`);

          const updateUrl = `${internalApiBaseUrl}/.netlify/functions/events/${encodeURIComponent(typedArgs.event_id)}`; // Corrected: target 'events' function
          const updatePayload: Partial<Omit<CalendarEvent, 'event_id' | 'user_id' | 'created_at'>> = {};
          if (typedArgs.title !== undefined) updatePayload.title = typedArgs.title;
          if (processedStartTime !== undefined) updatePayload.start_time = processedStartTime;
          if (processedEndTime !== undefined) updatePayload.end_time = processedEndTime;
          if (typedArgs.description !== undefined) updatePayload.description = typedArgs.description;
          if (typedArgs.location !== undefined) updatePayload.location = typedArgs.location;
          if (typedArgs.is_all_day !== undefined) updatePayload.is_all_day = typedArgs.is_all_day;
          // Ensure updated_at is handled by the backend calendar.ts trigger or logic

          console.log('[assistant-calendar.ts] Update payload:', JSON.stringify(updatePayload));

          const updateResponse = await fetch(updateUrl, {
            method: 'PUT', // Changed from PATCH to PUT
            headers: {
              ...internalHeaders,
              'X-Update-Request-ID': requestId
            },
            body: JSON.stringify(updatePayload),
          });

          if (updateResponse.ok) {
            // Successfully updated the event
            const rawUpdateResult = await updateResponse.text();
            try {
              const updateResult = JSON.parse(rawUpdateResult);
              console.log(`[assistant-calendar.ts] Internal update_calendar_event call successful. Raw response:`, updateResult);

              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${updateResult.title}" was successfully updated.`,
                updated_event_id: typedArgs.event_id
              });
            } catch (e) {
              console.error(`[assistant-calendar.ts] Error parsing calendar update result:`, e);
              // Even if we can't parse the response JSON, still treat it as a success if the HTTP status was OK
              toolResultContent = JSON.stringify({
                success: true,
                message: `Calendar event "${typedArgs.title}" was successfully updated.`,
                updated_event_id: typedArgs.event_id,
                update_request_id: requestId
              });
            }
          } else {
            // Failed to update the event
            const errorText = await updateResponse.text();
            console.error(`[assistant-calendar.ts] Internal update_calendar_event call failed with status ${updateResponse.status}:`, errorText);

            let errorMessage = 'An error occurred while attempting to update the calendar event.';
            try {
              // Try to parse the error message for more details
              const errorJson = JSON.parse(errorText);
              if (errorJson.message) {
                errorMessage = errorJson.message;
              }
            } catch {}

            toolResultContent = JSON.stringify({
              success: false,
              message: errorMessage,
            });
          }
          console.log(`[assistant-calendar.ts] update_calendar_event response content for OpenAI:`, toolResultContent);
        }
        break;

      case "delete_calendar_event":
        {
          console.log(`[assistant-calendar.ts] Tool call execution: delete_calendar_event with args:`, functionArgs);
          const typedArgs = functionArgs as DeleteCalendarEventToolArgs;
          let eventId = typedArgs.event_id;
          const searchTerm = typedArgs.search_term || eventId; // Use search_term if provided, otherwise event_id might be a search term
          const confirmed = typedArgs.confirmed || false;

          const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
          const isProvidedIdUuid = eventId ? uuidRegex.test(eventId) : false;

          if (!eventId || typeof eventId !== 'string' || eventId.trim() === '') {
            toolResultContent = JSON.stringify({
              success: false,
              error: "Invalid event_id or search_term for delete_calendar_event. Please provide an event ID or a search term."
            });
            console.log("[assistant-calendar.ts] Delete calendar event: invalid event_id/search_term format.");
            break;
          }

          // Scenario 1: Confirmed deletion with a valid UUID
          if (isProvidedIdUuid && confirmed) {
            console.log(`[assistant-calendar.ts] Attempting confirmed deletion for event UUID: ${eventId}`);
            const deleteUrl = `${internalApiBaseUrl}/.netlify/functions/events/${encodeURIComponent(eventId)}`;
            try {
              const deleteResponse = await fetch(deleteUrl, {
                method: 'DELETE',
                headers: internalHeaders,
              });
              if (deleteResponse.ok) {
                toolResultContent = JSON.stringify({
                  success: true,
                  message: `Calendar event with ID ${eventId} has been successfully deleted.`
                });
                console.log(`[assistant-calendar.ts] Successfully deleted event UUID: ${eventId}`);
              } else {
                const errorText = await deleteResponse.text();
                const status = deleteResponse.status;
                console.error(`[assistant-calendar.ts] Failed to delete event UUID ${eventId}. Status: ${status}, Error: ${errorText}`);
                toolResultContent = JSON.stringify({
                  success: false,
                  message: status === 404 
                    ? `Could not delete. Event with ID ${eventId} not found.` 
                    : `Failed to delete event with ID ${eventId}. Server responded: ${errorText}`,
                  error: `Deletion failed with status ${status}`
                });
              }
            } catch (error) {
              console.error(`[assistant-calendar.ts] Exception during confirmed deletion of event UUID ${eventId}:`, error);
              toolResultContent = JSON.stringify({
                success: false,
                message: `An unexpected error occurred while trying to delete event with ID ${eventId}.`,
                error: (error instanceof Error ? error.message : String(error))
              });
            }
            break; // Exit delete_calendar_event case
          }

          // Scenario 2: Need to find event (either by non-UUID event_id/search_term, or by UUID but not yet confirmed)
          let eventToConfirm: CalendarEvent | null = null;
          let effectiveSearchTerm = searchTerm;

          if (isProvidedIdUuid && !confirmed) {
            // We have a UUID, but need to fetch details for confirmation
            console.log(`[assistant-calendar.ts] Event ID ${eventId} is a UUID, fetching details for confirmation.`);
            const fetchUrl = `${internalApiBaseUrl}/.netlify/functions/events/${encodeURIComponent(eventId.trim())}`;
            try {
              const response = await fetch(fetchUrl, { method: 'GET', headers: internalHeaders });
              if (response.ok) {
                eventToConfirm = await response.json() as CalendarEvent;
                console.log(`[assistant-calendar.ts] Found event by UUID for confirmation:`, eventToConfirm);
              } else {
                console.log(`[assistant-calendar.ts] Event not found by UUID ${eventId} when attempting to get details for confirmation.`);
                 // Proceed to search by title if direct UUID fetch fails (maybe ID was mistyped but resembles UUID)
                 effectiveSearchTerm = eventId; // Use the potentially mistyped UUID as a search term now
              }
            } catch (error) {
              console.error(`[assistant-calendar.ts] Error fetching event by UUID ${eventId} for confirmation:`, error);
              // Proceed to search by title if direct UUID fetch fails
              effectiveSearchTerm = eventId;
            }
          }
          
          // If eventToConfirm is still null, search by term (either original term, or eventId if it wasn't a UUID or fetch failed)
          if (!eventToConfirm) {
            console.log(`[assistant-calendar.ts] Searching for event by term: "${effectiveSearchTerm}" for deletion confirmation.`);
            const searchUrl = `${internalApiBaseUrl}/.netlify/functions/calendar?search_term=${encodeURIComponent(effectiveSearchTerm.trim())}`;
            try {
              const response = await fetch(searchUrl, { method: 'GET', headers: internalHeaders });
              if (response.ok) {
                const matchingEvents = await response.json() as CalendarEvent[];
                if (matchingEvents.length === 1) {
                  eventToConfirm = matchingEvents[0];
                  console.log(`[assistant-calendar.ts] Found single event by search for confirmation:`, eventToConfirm);
                } else if (matchingEvents.length > 1) {
                  toolResultContent = JSON.stringify({
                    success: false,
                    message: `Found multiple events matching "${effectiveSearchTerm}". Please provide more details to clarify which event you mean. Matches: ${matchingEvents.map(e => `"${e.title}"`).join(', ')}`,
                    requires_clarification: true
                  });
                  break;
                } else {
                  console.log(`[assistant-calendar.ts] No events found by search term: "${effectiveSearchTerm}".`);
                }
              }
            } catch (error) {
              console.error(`[assistant-calendar.ts] Error searching for event by term "${effectiveSearchTerm}":`, error);
            }
          }

          // Scenario 3: Respond for confirmation or if event not found
          if (eventToConfirm) {
            toolResultContent = JSON.stringify({
              success: true, // Indicates we found an event to confirm
              action_pending: 'confirmation',
              event_id: eventToConfirm.event_id, // CRITICAL: This is the actual UUID
              event_title: eventToConfirm.title,
              message: `Found event: "${eventToConfirm.title}". Please confirm if you want to delete this event.`,
              requires_confirmation: true,
              // Instruct LLM on how to confirm
              next_step_guidance: `To confirm deletion, call 'delete_calendar_event' again with event_id: "${eventToConfirm.event_id}" (this exact UUID) AND confirmed: true.`
            });
          } else {
            toolResultContent = JSON.stringify({
              success: false,
              message: `Could not find a unique calendar event matching "${effectiveSearchTerm}". Please try a different search term or provide the event's unique ID.`,
              error: "Event not found for deletion."
            });
          }
        }
        break;

      default:
        console.warn(`Unknown tool function: ${functionName}`);
        toolResultContent = JSON.stringify({ error: `Unknown tool function: ${functionName}` });
    }
  } catch (error) {
    console.error(`Error executing tool ${functionName} (ID: ${toolCall.id}):`, error);
    toolResultContent = JSON.stringify({ error: `Failed to execute tool ${functionName}: ${error instanceof Error ? error.message : String(error)}` });
  }

  return {
    tool_call_id: toolCall.id,
    role: "tool" as const,
    content: toolResultContent,
  };
}

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  // Initial logging
  console.log("--- assistant-calendar.ts function invoked ---");
  console.log("HTTP Method:", event.httpMethod);
  console.log("Path:", event.path);
  console.log("Headers (partial):", {
    'content-type': event.headers['content-type'],
    'authorization': event.headers['authorization'] ? 'Bearer ***' : undefined, // Don't log full token
  });

  // CORS headers definition
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*", 
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json"
  };

  // Handle OPTIONS preflight requests
  if (event.httpMethod === 'OPTIONS') {
    console.log("--- assistant-calendar.ts handling OPTIONS preflight request ---");
    return {
      statusCode: 204,
      headers: {
        ...corsHeaders,
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }

  let userId: string | null = null; 
  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

  try {
    if (!OPENAI_API_KEY) {
      console.error('[assistant-calendar.ts] OPENAI_API_KEY is not set.');
      return {
          statusCode: 500,
          body: JSON.stringify({ error: 'Server configuration error: Missing API key.' }),
          headers: corsHeaders 
      };
    }

    userId = getUserIdFromEvent(event);
    if (!userId) {
      return { statusCode: 401, body: JSON.stringify({ error: 'User not authenticated or JWT invalid/missing SUB claim.' }), headers: corsHeaders };
    }

    if (!event.body) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Request body is missing.' }), headers: corsHeaders };
    }

    let requestBody: AssistantRequestBody;
    try {
      requestBody = JSON.parse(event.body);
    } catch (e) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON in request body.' }), headers: corsHeaders };
    }

    // Handle direct tool calls from the client (similar to assistant-contacts.ts)
    if (requestBody.tool_call) {
      console.log(`[assistant-calendar.ts] Received direct tool call request from client: ${requestBody.tool_call.function.name}`);
      
      const toolCall = requestBody.tool_call;
      const toolResult = await executeSingleToolCall(toolCall, event.headers, userId);
      
      return {
        statusCode: 200,
        body: JSON.stringify(toolResult),
        headers: corsHeaders
      };
    }

    // Handle regular message flow
    if (!requestBody.messages || !Array.isArray(requestBody.messages) || requestBody.messages.length === 0) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Messages array is missing or empty in request body.' }), headers: corsHeaders };
    }
    console.log('[assistant-calendar.ts] Request body and messages validated successfully.');

    const incomingMessagesFromUser = requestBody.messages;
    const latestUserMessage = incomingMessagesFromUser.filter(msg => msg.role === 'user').pop();
    console.log(`[assistant-calendar.ts] Most recent user message: "${latestUserMessage?.content}"`);

    // Define system message specifically for calendar operations with current date/time context
    const currentDateTime = new Date().toISOString();
    
    // Use client time zone if provided, otherwise fallback to server time zone
    const timeZone = requestBody.localTimeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    console.log(`[assistant-calendar.ts] Using time zone: ${timeZone} (${requestBody.localTimeZone ? 'client-provided' : 'server default'})`);
    
    const userLocalTime = new Date().toLocaleString('en-US', { timeZone });
    const utcOffset = -(new Date().getTimezoneOffset() / 60); // Convert to hours and make positive for east, negative for west
    const utcOffsetStr = utcOffset >= 0 ? `UTC+${utcOffset}` : `UTC${utcOffset}`;

    const systemMessage: OpenAI.Chat.Completions.ChatCompletionSystemMessageParam = {
      role: 'system',
      content: `You are an expert AI assistant specialized in calendar management. You help users create, find, update, and delete calendar events. You have access to calendar-specific tools to perform these operations.

Today's current date and time is ${userLocalTime} (${currentDateTime} in UTC). The user's local time zone is ${timeZone} (${utcOffsetStr}).

## Important Time Zone Handling
- The calendar system stores all dates/times in UTC format in the database
- When showing times to users, convert from UTC to their local time zone (${timeZone})
- When users provide times, assume they are in their local time zone and convert to UTC for storage
- When displaying events in lists or details, ALWAYS follow this exact format with Timezone as a separate line item:
  * **Title:** Event Title
  * **Start Time:** May 18, 2025, 6:00 PM - 6:30 PM
  * **Timezone:** ${timeZone}
  * **Description:** Event description (if available)
  * **Location:** Location info (if available)
  * **Event ID:** Event UUID (if available)
- If you display UTC times, always explicitly label them as "(UTC)"

## Formatting Guidelines
Always format your responses using rich Markdown for better readability:
- Use **bold text** for important information like event titles, dates, and times
- Use headings (## and ###) to organize sections of your response
- Present event details in tables when showing multiple events
- Use bullet points or numbered lists for steps or multiple items
- Use \`code formatting\` for IDs or technical values
- Use > blockquotes for important notes or warnings

## Calendar Operations Guidelines

When creating calendar events:
1. Always use the current year (${new Date().getFullYear()}) for dates unless a specific year is mentioned
2. Format ISO dates properly with the correct year
3. For relative dates like "tomorrow" or "next week," calculate them based on today's date: ${new Date().toISOString().split('T')[0]}
4. Store times in UTC but display them to users in their local time zone (${timeZone})`
    };

    // Prepare the messages for OpenAI API call, always starting with the system message
    const messagesForOpenAI: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      systemMessage,
      ...incomingMessagesFromUser
    ];

    const modelToUse = process.env.OPENAI_MODEL || 'gpt-4o-mini'; // Default model

    console.log(`[assistant-calendar.ts] Making API call to OpenAI with model: ${modelToUse}`);

    let toolChoiceSetting: OpenAI.Chat.Completions.ChatCompletionToolChoiceOption = 'auto';

    // Check if the request is specifically the one from CalendarContext's fetchEvents
    if (
      incomingMessagesFromUser &&
      incomingMessagesFromUser.length === 1 &&
      incomingMessagesFromUser[0].role === 'user' &&
      incomingMessagesFromUser[0].content === 'Find all my calendar events.'
    ) {
      toolChoiceSetting = { type: "function", function: { name: "find_calendar_events" } };
      console.log(`[assistant-calendar.ts] Forcing tool_choice to 'find_calendar_events' for the generic event fetch query.`);
    }

    const initialChatCompletion = await openai.chat.completions.create({
      model: modelToUse,
      messages: messagesForOpenAI,
      tools: tools,
      tool_choice: toolChoiceSetting, // Use the determined setting
    });

    const responseMessage = initialChatCompletion.choices[0]?.message;

    if (!responseMessage) {
      console.error('[assistant-calendar.ts] No response message received from OpenAI.');
      return { statusCode: 500, body: JSON.stringify({ error: 'No response message received from OpenAI.' }), headers: corsHeaders };
    }

    if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0) {
      console.log(`[assistant-calendar.ts] Tool calls detected. Count: ${responseMessage.tool_calls.length}`);
      
      // Simply return the OpenAI response with tool_calls to the client
      // Let the frontend handle tool execution and subsequent steps
      console.log('[assistant-calendar.ts] Returning response with tool_calls to client for execution.');
      return {
        statusCode: 200,
        body: JSON.stringify(responseMessage),
        headers: corsHeaders
      };
    } else {
      // Just a regular text response, no tool calls
      console.log(`[assistant-calendar.ts] Response is a regular text message, no tool calls.`);
      return { statusCode: 200, body: JSON.stringify(responseMessage), headers: corsHeaders };
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred.';
    console.error('[assistant-calendar.ts] Error:', errorMessage, error);
    return { statusCode: 500, body: JSON.stringify({ error: errorMessage }), headers: corsHeaders };
  }
};

export { handler };
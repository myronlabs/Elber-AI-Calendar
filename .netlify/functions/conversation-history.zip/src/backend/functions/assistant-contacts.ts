import type { Handler, HandlerEvent, HandlerContext, HandlerResponse } from "@netlify/functions";
import OpenAI from 'openai';
// @ts-ignore
import fetch from 'node-fetch'; // For making internal HTTP requests
// import { jwtDecode } from 'jwt-decode'; // No longer needed directly, use getUserIdFromEvent
import { analyzeConfirmation } from '../services';

// Import shared utilities and types
import { 
  isValidUUID, 
  getUserIdFromEvent, 
  getInternalApiBaseUrl, 
  getInternalHeaders 
} from './_shared/utils';
import type { 
  ConfirmationStatus, 
  GenericChatMessage,
  DirectToolCall,
  AssistantRequestBody
  // DecodedJwt is used internally by getUserIdFromEvent, not directly here
} from './_shared/types';

// Local type definitions specific to assistant-contacts tools
// These can remain here or be moved to _shared/types.ts if they become more generic.
// For now, keeping them local as they are very specific to this function's tools.

interface DeleteContactToolArgs {
  contact_id: string;
}

interface FindContactsToolArgs {
  search_term: string;
  contact_id?: string; 
}

interface ConfirmDeleteContactToolArgs {
  contact_id: string;
  confirm: boolean;
  contact_name: string;
}

interface CreateContactToolArgs {
  first_name: string;
  last_name: string | null;
  email: string | null;
  phone: string | null;
  company: string | null;
  notes: string | null;
}

interface UpdateContactToolArgs {
  contact_id: string;
  // All fields are optional for update, matching Partial<CreateContactToolArgs> effectively
  first_name?: string | null;
  last_name?: string | null;
  email?: string | null;
  phone?: string | null;
  company?: string | null;
  notes?: string | null;
}

// Helper function to validate incoming messages against the GenericChatMessage structure.
// This is a basic validation, can be expanded if needed.
const validateMessages = (messages: any[]): messages is GenericChatMessage[] => {
  if (!Array.isArray(messages)) return false;
  return messages.every(msg => 
    msg &&
    typeof msg.role === 'string' &&
    (msg.content === null || typeof msg.content === 'string') &&
    (msg.tool_calls === undefined || Array.isArray(msg.tool_calls)) &&
    (msg.tool_call_id === undefined || typeof msg.tool_call_id === 'string')
  );
};


/**
 * Creates a properly formatted confirm_delete_contact tool call
 * Ensures all required parameters are included
 */
function createDeleteConfirmationToolCall(
  contactId: string,
  contactName: string | null | undefined
): OpenAI.Chat.Completions.ChatCompletionMessageToolCall { // Changed to OpenAI's type
  const safeName = contactName || `Contact ID ${contactId.substring(0, 8)}`;
  return {
    id: `tool_confirm_delete_${Date.now()}_${contactId.substring(0,4)}`, // Ensure unique tool call ID
    type: 'function',
    function: {
      name: 'confirm_delete_contact',
      arguments: JSON.stringify({
        contact_id: contactId,
        // 'confirm' will be decided by the user's response to the assistant's question
        // The assistant should ask for confirmation, and then the next user message
        // will be processed by `processConfirmation` before this tool is called again WITH confirm:true/false.
        // So, when *this* specific tool call is *generated* to be sent to the client/LLM,
        // it's for the *purpose* of asking the LLM to confirm with the user.
        // The actual confirmation will come in a subsequent call to this tool.
        // For now, we can omit `confirm` or set a placeholder if the schema requires it.
        // Let's assume the schema for confirm_delete_contact requires `contact_id` and `contact_name` for the confirmation prompt,
        // and `confirm` is only added when the tool is actually executed with the user's decision.
        contact_name: safeName 
      })
    }
  };
}

// REMOVED: DecodedJwt (now in _shared/types.ts, used by getUserIdFromEvent)
// REMOVED: getUserIdFromEvent (now in _shared/utils.ts)
// REMOVED: isValidUUID (now in _shared/utils.ts)
// REMOVED: ConfirmationStatus (now in _shared/types.ts)
// REMOVED: ChatMessage (replaced by GenericChatMessage from _shared/types.ts)
// REMOVED: AssistantRequestBody (now in _shared/types.ts)
// REMOVED: DirectToolCall (now in _shared/types.ts)

// Export tools and executeSingleToolCall for use by other assistant functions
export { tools, executeSingleToolCall };

/**
 * Processes user confirmation using OpenAI instead of regex patterns
 */
const processConfirmation = async (
  message: string,
  context: { actionType: string; entityName: string; }
): Promise<ConfirmationStatus> => {
  console.log(`[assistant-contacts] Analyzing confirmation: "${message}" for ${context.actionType} of ${context.entityName}`);
  return await analyzeConfirmation(message, {
    actionType: context.actionType,
    itemName: context.entityName
  });
};

const tools: OpenAI.Chat.Completions.ChatCompletionTool[] = [
  {
    type: "function",
    function: {
      name: "create_contact",
      description: "Creates a new contact in the CRM with the provided details. Requires at least a first name.",
      parameters: {
        type: "object",
        properties: {
          first_name: { type: "string", description: "First name of the contact." },
          last_name: { type: ["string", "null"], description: "Last name of the contact. Can be null." },
          email: { type: ["string", "null"], description: "Email address of the contact. Must be a valid email format if provided." },
          phone: { type: ["string", "null"], description: "Phone number of the contact." },
          company: { type: ["string", "null"], description: "Company name of the contact." },
          notes: { type: ["string", "null"], description: "Additional notes for the contact." }
        },
        required: ["first_name"],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "update_contact",
      description: "Updates an existing contact in the CRM. Requires the contact_id and at least one field to update.",
      parameters: {
        type: "object",
        properties: {
          contact_id: { type: "string", description: "The UUID of the contact to update." },
          first_name: { type: ["string", "null"], description: "New first name. Null or empty to clear." },
          last_name: { type: ["string", "null"], description: "New last name. Null or empty to clear." },
          email: { type: ["string", "null"], description: "New email. Must be valid. Null to clear." },
          phone: { type: ["string", "null"], description: "New phone number. Null to clear." },
          company: { type: ["string", "null"], description: "New company name. Null to clear." },
          notes: { type: ["string", "null"], description: "New notes. Null to clear." }
        },
        required: ["contact_id"],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "find_contacts",
      description: "Finds contacts based on a search term (name, email, phone, company) or a specific contact_id. If no search term or contact_id is provided, it lists all contacts. Returns one or more matching contacts, or an empty list if no matches.",
      parameters: {
        type: "object",
        properties: {
          search_term: { type: ["string", "null"], description: "A general search term to find contacts (name, email, phone, company). Leave empty or null to list all contacts if contact_id is also not provided." },
          contact_id: { type: "string", description: "A specific UUID of a contact to find." }
        },
        // No fields are strictly required; either search_term or contact_id can be used, or both.
        // The function logic should handle cases where neither or both are provided.
        // For OpenAI, it's often better to make one "conditionally required" or describe behavior.
        // Let's assume the LLM will be smart enough to provide one, or the backend /contacts API handles empty.
        // If contact_id is provided, it takes precedence.
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "confirm_delete_contact",
      description: "Confirms or denies the deletion of a contact. This tool is called after the user has been asked to confirm a delete operation identified by contact_id and contact_name. The user's response (yes/no) is used to set the 'confirm' flag.",
      parameters: {
        type: "object",
        properties: {
          contact_id: { type: "string", description: "The UUID of the contact to be deleted." },
          contact_name: { type: "string", description: "The name of the contact, for confirmation context." },
          confirm: { type: "boolean", description: "Set to true if deletion is confirmed, false if denied." }
        },
        required: ["contact_id", "contact_name", "confirm"],
        additionalProperties: false
      }
    }
  }
];

// This type is specific to how assistant-contacts wants to structure the tool execution result before sending to OpenAI.
// It's slightly different from _shared/types.ts AssistantRequestBody.tool_response
interface BackendToolResponseMessage {
  tool_call_id: string;
  role: "tool"; // OpenAI requires role "tool" for tool responses
  // name: string; // OpenAI's ChatCompletionToolMessageParam does not have 'name' at the top level, it's part of the original tool_call
  content: string; // Stringified JSON result or error message
}

async function executeSingleToolCall(
  toolCall: OpenAI.Chat.Completions.ChatCompletionMessageToolCall, 
  eventHeaders: HandlerEvent['headers'], 
  userId: string | null, // Passed in, not extracted here anymore
  reqId?: string
): Promise<OpenAI.Chat.Completions.ChatCompletionToolMessageParam> { // OpenAI's type for tool message params
  const logPrefix = `[assistant-contacts.ts]${reqId ? `[ReqID:${reqId}]` : ''}[ToolCall:${toolCall.id}]`;
  const { name: toolName, arguments: argsString } = toolCall.function;
  let content: string; // This will be JSON stringified

  const internalApiBaseUrl = getInternalApiBaseUrl(); // Now includes /api
  const internalHeaders = getInternalHeaders(eventHeaders); // Gets standard headers

  console.log(`${logPrefix} Executing tool: ${toolName} with args: ${argsString}`);

  // Ensure userId is available for operations that require it, though some tools might be public
  // For contacts, all operations are user-specific.
  if (!userId) {
    console.error(`${logPrefix} Error: User ID is missing. Cannot execute tool ${toolName}.`);
    content = JSON.stringify({ error: "User authentication required to execute contact tools." });
    return { tool_call_id: toolCall.id, role: "tool", content };
  }

  try {
    const args = JSON.parse(argsString);

    switch (toolName) {
      case 'find_contacts': {
        const { search_term, contact_id } = args as FindContactsToolArgs;
        // internalApiBaseUrl already has /api
        let findUrl = `${internalApiBaseUrl}/contacts`;
        if (contact_id && isValidUUID(contact_id)) { // Validate UUID before using
          findUrl += `?contact_id=${encodeURIComponent(contact_id)}`;
          console.log(`${logPrefix} find_contacts: Searching by contact_id: ${contact_id}`);
        } else if (search_term && search_term.trim() !== "") {
          findUrl += `?search_term=${encodeURIComponent(search_term)}`;
          console.log(`${logPrefix} find_contacts: Searching by search_term: ${search_term}`);
        } else {
           // Neither contact_id nor a non-empty search_term is provided, so list all contacts.
          console.log(`${logPrefix} find_contacts: No specific contact_id or search_term provided. Attempting to list all contacts.`);
          // The findUrl remains `${internalApiBaseUrl}/contacts` without query parameters.
        }

        console.log(`${logPrefix} Calling internal API to find contacts: ${findUrl}`);
        const response = await fetch(findUrl, { method: 'GET', headers: internalHeaders });
        
        if (!response.ok) {
          const errorBody = await response.text();
          console.error(`${logPrefix} Error from /contacts API (${response.status}): ${errorBody}`);
          content = JSON.stringify({ error: `Failed to find contacts. Status: ${response.status}`, details: errorBody.substring(0, 500) });
        } else {
          const data = await response.json();
          console.log(`${logPrefix} Successfully found contacts. Count: ${Array.isArray(data) ? data.length : (data.contacts ? data.contacts.length : 'N/A')}`);
          content = JSON.stringify(data);
        }
        break;
      }

      case 'create_contact': {
        const contactDetails = args as CreateContactToolArgs;
        // Validate required fields before sending
        if (!contactDetails.first_name || typeof contactDetails.first_name !== 'string' || contactDetails.first_name.trim() === '') {
            content = JSON.stringify({ error: "Validation error: 'first_name' is required and must be a non-empty string for create_contact." });
            break;
        }
        const createUrl = `${internalApiBaseUrl}/contacts`;
        console.log(`${logPrefix} Calling internal API to create contact: ${createUrl}`);
        const response = await fetch(createUrl, {
            method: 'POST',
            headers: internalHeaders,
          body: JSON.stringify(contactDetails),
        });
        if (!response.ok) {
          const errorBody = await response.text();
          console.error(`${logPrefix} Error from /contacts API during create (${response.status}): ${errorBody}`);
          content = JSON.stringify({ error: `Failed to create contact. Status: ${response.status}`, details: errorBody.substring(0,500) });
        } else {
          const data = await response.json();
          console.log(`${logPrefix} Successfully created contact.`);
          content = JSON.stringify(data);
        }
            break;
          }

      case 'update_contact': {
        const { contact_id, ...updateDetails } = args as UpdateContactToolArgs;
        if (!contact_id || !isValidUUID(contact_id)) {
          content = JSON.stringify({ error: "Invalid or missing contact_id for update_contact." });
          break;
        }
        if (Object.keys(updateDetails).length === 0) {
          content = JSON.stringify({ error: "No fields provided to update for update_contact." });
            break;
          }

        const updateUrl = `${internalApiBaseUrl}/contacts/${encodeURIComponent(contact_id)}`;
        console.log(`${logPrefix} Calling internal API to update contact: ${updateUrl}`);
        const response = await fetch(updateUrl, {
          method: 'PUT', // Assuming /contacts/{id} uses PUT for updates
            headers: internalHeaders,
          body: JSON.stringify(updateDetails),
        });
        if (!response.ok) {
          const errorBody = await response.text();
          console.error(`${logPrefix} Error from /contacts API during update (${response.status}): ${errorBody}`);
          content = JSON.stringify({ error: `Failed to update contact ${contact_id}. Status: ${response.status}`, details: errorBody.substring(0,500) });
          } else {
          const data = await response.json();
          console.log(`${logPrefix} Successfully updated contact ${contact_id}.`);
          content = JSON.stringify(data);
        }
            break;
          }

      case 'confirm_delete_contact': {
        const { contact_id, confirm, contact_name } = args as ConfirmDeleteContactToolArgs;
        
        if (!contact_id || !isValidUUID(contact_id)) {
          content = JSON.stringify({ error: "Invalid or missing contact_id for confirm_delete_contact." });
            break;
          }
        if (confirm === undefined) {
           content = JSON.stringify({ error: "Confirmation decision (true/false) is required for confirm_delete_contact."});
            break;
          }

        if (confirm) {
          console.log(`${logPrefix} User confirmed deletion for contact ID: ${contact_id}, Name: ${contact_name}`);
          // The /contacts endpoint uses DELETE with contact_id in the body or path.
          // Let's assume the /contacts DELETE expects contact_id in the body based on current structure.
          // This is a PATCH in contacts.ts, but should be a DELETE. Let's assume it's being fixed there or use PATCH.
          // For now, aligning with what assistant-contacts might expect to send to a /contacts DELETE
          const deleteUrl = `${internalApiBaseUrl}/contacts`; 
          console.log(`${logPrefix} Calling internal API to delete contact: ${deleteUrl}`);
          const response = await fetch(deleteUrl, {
            method: 'DELETE',
            headers: internalHeaders,
            body: JSON.stringify({ contact_id }), // Send contact_id in body
          });

          if (!response.ok) {
            const errorBody = await response.text();
            console.error(`${logPrefix} Error from /contacts API during delete (${response.status}): ${errorBody}`);
            content = JSON.stringify({ error: `Failed to delete contact ${contact_id}. Status: ${response.status}`, details: errorBody.substring(0,500) });
          } else {
            const data = await response.json(); // Expect a success message
            console.log(`${logPrefix} Successfully initiated deletion for contact ${contact_id}. Response: ${JSON.stringify(data)}`);
            content = JSON.stringify(data);
          }
        } else {
          console.log(`${logPrefix} User denied deletion for contact ID: ${contact_id}, Name: ${contact_name}`);
          content = JSON.stringify({ message: `Deletion of contact ${contact_name} was cancelled by the user.`, contact_id: contact_id, deleted: false });
        }
        break;
      }

      default:
        console.warn(`${logPrefix} Unknown tool function: ${toolName}`);
        content = JSON.stringify({ error: `Unknown tool function: ${toolName}` });
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred during tool execution.";
    console.error(`${logPrefix} Error executing tool ${toolName}: ${errorMessage}`, error);
    content = JSON.stringify({ error: `Error in tool ${toolName}: ${errorMessage}` });
  }

  return {
    tool_call_id: toolCall.id,
    role: "tool",
    content, // Content is already stringified JSON
  };
}

// The main handler for the Netlify Function
export const handler: Handler = async (event: HandlerEvent, context: HandlerContext): Promise<HandlerResponse> => {
  const reqId = context.awsRequestId || `local-${Date.now()}`; // For logging
  const logPrefix = `[assistant-contacts.ts][ReqID:${reqId}]`;

  console.log(`${logPrefix} Function invoked ---`);
  console.log(`${logPrefix} HTTP Method: ${event.httpMethod}`);
  console.log(`${logPrefix} Path: ${event.path}`);
  // Basic logging for headers, avoid logging sensitive info like full Authorization
  const safeHeaders: Record<string, string | undefined> = {};
  for (const key in event.headers) {
    if (key.toLowerCase() === 'authorization') {
      safeHeaders[key] = 'Bearer ***';
    } else if (key.toLowerCase() === 'cookie') {
       safeHeaders[key] = '***';
    } else {
      safeHeaders[key] = event.headers[key];
    }
  }
  console.log(`${logPrefix} Headers (partial): ${JSON.stringify(safeHeaders)}`);


  if (event.httpMethod !== 'POST') {
    console.warn(`${logPrefix} Method Not Allowed: ${event.httpMethod}`);
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method Not Allowed' }),
      headers: { 'Content-Type': 'application/json', 'Allow': 'POST' },
    };
  }

  const userId = getUserIdFromEvent(event, 'assistant-contacts.ts'); // Use shared util
  if (!userId) {
    // getUserIdFromEvent already logs the reason
    return {
      statusCode: 401,
      body: JSON.stringify({ message: 'Authentication required. User ID could not be determined.' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
  // Successfully authenticated at this point, userId is available.

  let requestBody: AssistantRequestBody;
  try {
    if (!event.body) {
      console.warn(`${logPrefix} Request body is missing.`);
      throw new Error("Request body is missing.");
    }
    requestBody = JSON.parse(event.body);
    console.log(`${logPrefix} Parsed requestBody (structure):`, { 
      hasMessages: !!requestBody.messages, 
      messageCount: requestBody.messages?.length,
      hasToolCall: !!requestBody.tool_call,
      toolCallName: requestBody.tool_call?.function?.name,
      hasToolResponse: !!requestBody.tool_response,
      toolResponseId: requestBody.tool_response?.tool_call_id
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error parsing request body.";
    console.error(`${logPrefix} Failed to parse request body: ${errorMessage}. Body received (first 200 chars): ${event.body ? event.body.substring(0,200) : 'N/A'}`);
    return {
      statusCode: 400,
      body: JSON.stringify({ message: `Invalid request body: ${errorMessage}` }),
      headers: { 'Content-Type': 'application/json' },
    };
  }

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  try {
    // Scenario 1: Direct tool call from client/frontend (legacy or specific cases)
    // This is when the client says "execute this specific tool with these args"
    if (requestBody.tool_call && requestBody.tool_call.id && requestBody.tool_call.function) {
      console.log(`${logPrefix} Received direct tool call for execution: ${requestBody.tool_call.function.name}`);
      
      // Convert DirectToolCall to OpenAI.Chat.Completions.ChatCompletionMessageToolCall
      // They are structurally compatible for what executeSingleToolCall needs.
      const openAIToolCall: OpenAI.Chat.Completions.ChatCompletionMessageToolCall = {
        id: requestBody.tool_call.id,
        type: 'function', // Assuming all direct tool calls are functions
        function: {
          name: requestBody.tool_call.function.name,
          arguments: requestBody.tool_call.function.arguments // Already stringified JSON
        }
      };

      const toolResult = await executeSingleToolCall(openAIToolCall, event.headers, userId, reqId);
      
      // Check if content is a string before using substring
      const contentPreview = typeof toolResult.content === 'string' 
        ? toolResult.content.substring(0, 100) + '...'
        : 'Content is not a string';
        
      console.log(`${logPrefix} Direct tool call executed. Result content: ${contentPreview}`);
      return {
        statusCode: 200,
        body: JSON.stringify(toolResult), // Send back the single tool result message
        headers: { 'Content-Type': 'application/json' },
      };
    } 
    // Scenario 2: Client sends tool response to be included in conversation history
    // This is when OpenAI previously requested a tool_call, client executed it, and is now sending the result back.
    else if (requestBody.tool_response && requestBody.tool_response.tool_call_id) {
        if (!requestBody.messages || requestBody.messages.length === 0) {
            console.error(`${logPrefix} Tool response provided without prior messages array.`);
            return { 
                statusCode: 400, 
                body: JSON.stringify({ message: "Tool response must be accompanied by the conversation history (messages)."}),
                headers: { 'Content-Type': 'application/json' }
            };
        }
        console.log(`${logPrefix} Received tool response for tool_call_id: ${requestBody.tool_response.tool_call_id}. Appending to conversation.`);
        
        const toolResponseMessage: GenericChatMessage = {
            role: 'tool',
            tool_call_id: requestBody.tool_response.tool_call_id,
            content: typeof requestBody.tool_response.output === 'string' 
                       ? requestBody.tool_response.output 
                       : JSON.stringify(requestBody.tool_response.output),
        };
        requestBody.messages.push(toolResponseMessage);
        // Now proceed to call OpenAI with the updated messages array below.
    }
    // Scenario 3: Standard conversation flow (initial message or ongoing chat)
    // This will also handle the case where a tool_response was just added to messages.
    
    if (!requestBody.messages || requestBody.messages.length === 0) {
      console.warn(`${logPrefix} No messages provided for OpenAI API call and not a direct tool call/response.`);
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'No messages provided for conversation.' }),
        headers: { 'Content-Type': 'application/json' },
      };
    }

    // Validate the messages structure before sending to OpenAI
    if (!validateMessages(requestBody.messages)) {
        console.error(`${logPrefix} Invalid messages structure in requestBody.`);
        // Log the problematic messages for debugging, avoid sending potentially huge/malformed objects in response
        try {
            console.error("Problematic messages array (stringified):", JSON.stringify(requestBody.messages, null, 2).substring(0, 1000));
        } catch (e) {
            console.error("Problematic messages array could not be stringified.");
        }
          return {
            statusCode: 400, 
            body: JSON.stringify({ message: "Invalid message structure. Please check roles, content, and tool call formats." }),
            headers: { 'Content-Type': 'application/json' }
        };
    }
    
    // First pass to identify assistant messages with tool_calls for tracking context
    const toolCallMap = new Map<string, number>();
    requestBody.messages.forEach((m, index) => {
      if (m.role === 'assistant' && m.tool_calls && m.tool_calls.length > 0) {
        m.tool_calls.forEach(tc => {
          if (tc.id) {
            toolCallMap.set(tc.id, index); // Remember which assistant message has this tool_call_id
          }
        });
      }
    });

    // Process all messages, but ensure tool messages have corresponding assistant tool_calls
    const validMessages = requestBody.messages
      .filter(m => {
        // Keep all non-tool messages
        if (m.role !== 'tool') return true;

        // For tool messages, verify they match an assistant's tool_call_id
        return m.tool_call_id && toolCallMap.has(m.tool_call_id);
      });

    // Log information about message filtering
    console.log(`${logPrefix} Original message count: ${requestBody.messages.length}`);
    console.log(`${logPrefix} Valid message count: ${validMessages.length}`);
    console.log(`${logPrefix} Tool call map size: ${toolCallMap.size}`);
    console.log(`${logPrefix} Message roles sequence: ${validMessages.map(m => m.role).join(', ')}`);

    // Ensure messages are typed correctly for OpenAI
    const openAIMessages = validMessages.map(m => ({
        role: m.role as 'user' | 'assistant' | 'system' | 'tool', // Cast needed due to GenericChatMessage flexibility
        content: m.content === null ? '' : m.content, // Ensure content is never null
        ...(m.tool_calls && { tool_calls: m.tool_calls }),
        ...(m.tool_call_id && { tool_call_id: m.tool_call_id }),
        ...(m.name && { name: m.name }) // Include name if present (esp. for tool calls)
    })) as OpenAI.Chat.Completions.ChatCompletionMessageParam[];


    console.log(`${logPrefix} Received conversation request for OpenAI API. Validating ${openAIMessages.length} messages.`);

    // System Prompt - specific to contacts
    const systemPrompt: OpenAI.Chat.Completions.ChatCompletionSystemMessageParam = {
      role: "system",
      content: `You are Elber, an AI assistant specializing in contact management for a CRM.
Current date: ${new Date().toISOString()}
// The User ID is available to the system for operations but should not be displayed in responses.

You must never display internal identifiers such as User IDs, Contact IDs, Event IDs, or any other UUIDs in your responses to the user. These IDs are confidential and for system use only. Refer to items by their user-understandable attributes like name, title, etc.

## Formatting Guidelines
Always format your responses using rich Markdown for better readability:
- Use **bold text** for important information like contact names, email addresses, and phone numbers.
- Use headings (## and ###) to organize sections of your response, especially when presenting contact details.
- Present contact details in a structured list or table when appropriate.
- Use bullet points or numbered lists for steps or multiple items (e.g., listing multiple contacts found).
- Use \`code formatting\` for technical values. Avoid displaying internal IDs (like \`contact_id\`) to the user; use names or other user-friendly identifiers instead for display purposes. Internal IDs are for tool use only.
- Use > blockquotes for important notes, warnings, or when asking for confirmation.

## Core Capabilities:
- Create new contacts (requires at least a first name).
- Find existing contacts (by name, email, phone, company, or specific contact_id).
- Update existing contacts (requires contact_id and fields to change).
- Delete contacts (always requires user confirmation specifying contact_id and name for internal tool use, but only confirm by name to the user).

Confirmation Flow for Deletion:
1. If the user asks to delete a contact, first use 'find_contacts' to locate the exact contact and get its ID and name. (The ID is for your internal use with tools).
2. If one or more contacts are found, present the options to the user by name if ambiguous (e.g., "I found John Doe and Jane Doe. Which one do you mean?"), or state the full name of the contact you intend to delete (e.g., "I found John Doe, is this the contact you'd like to delete?"). Do not state the Contact ID to the user.
3. Ask the user for explicit confirmation by name (e.g., "Are you sure you want to delete John Doe?").
4. If the user confirms (e.g., "Yes", "Confirm", "Do it"), then call the 'confirm_delete_contact' tool with 'confirm: true', the 'contact_id' (which you retrieved in step 1), and 'contact_name'.
5. If the user denies (e.g., "No", "Cancel"), then call 'confirm_delete_contact' with 'confirm: false', along with the 'contact_id' and 'contact_name'.
6. If the user's response is ambiguous, ask for clarification.

Tool Usage Guidelines:
- When finding contacts, if multiple matches are found, list them clearly using Markdown (e.g., by name and other distinguishing details, but not by ID). If a unique ID is available from a previous step or user input, use that with find_contacts internally.
- For creating/updating, ensure all provided data seems reasonable. Email should look like an email.
- When calling 'confirm_delete_contact', you MUST provide the 'contact_id', the 'contact_name' (as presented to the user for confirmation by name), and the boolean 'confirm' status.

Error Handling by Tools:
- If a tool call results in an error (e.g., contact not found, validation error), this will be returned in the 'content' of the tool's response message. Inform the user clearly about the issue, using Markdown to highlight key error details if appropriate, without revealing internal IDs.
- Do not retry a failed tool call unless the error suggests a temporary issue or you have new information from the user.

Interaction Style:
- Be concise and clear.
- When action is taken (create, update, delete), confirm this back to the user (e.g., "Okay, I've deleted John Doe.").
- If you need more information, ask specific questions.
- Do not perform actions with side effects (create, update, delete) without the user explicitly asking for it or confirming it. If a user says "jay poe is now at new company inc", this is a statement, not a request to update. Ask "Would you like me to update Jay Poe's company to New Company Inc?".
- When searching, if a search term like "Poe" yields "Jay Poe" and "Edgar Allan Poe", present both using Markdown lists (by name and other relevant details, not ID) and ask which one the user means before proceeding with actions like update/delete.
- For updates, if the user provides partial information (e.g., "update Jay's email to new@example.com"), find "Jay", confirm if it's the correct "Jay" (e.g. "I found Jay Poe, is that who you mean?"), then call 'update_contact' with only the email field (and the internal contact_id).
- Do NOT invent contact_ids. They are UUIDs and come from the 'find_contacts' tool or previous interactions and are for your internal use only.
- Strive to use the exact contact_name (first and last if available) when confirming actions like deletion with the user.
`
    };

    console.log(`${logPrefix} Making API call to OpenAI with model: ${process.env.OPENAI_MODEL || 'gpt-4o-mini'}`);
    console.log(`${logPrefix} Sending ${openAIMessages.length + 1} messages to OpenAI (including system prompt).`);
    
    // For debugging, log the messages being sent, especially the last few
    // openAIMessages.slice(-3).forEach((msg, idx) => console.log(`${logPrefix} OpenAI Message ${openAIMessages.length -3 + idx}: Role: ${msg.role}, Content (start): ${typeof msg.content === 'string' ? msg.content.substring(0,100) : 'N/A'}, ToolCalls: ${msg.tool_calls ? msg.tool_calls.length : 'N/A'}, ToolCallId: ${msg.tool_call_id || 'N/A'}`));


    const response = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [systemPrompt, ...openAIMessages],
          tools: tools,
      tool_choice: "auto", // Let OpenAI decide when to use tools
      // temperature: 0.7, // Default is usually fine
      // max_tokens: 1000, // Default is usually fine
    });

    const responseMessage = response.choices[0].message;
    console.log(`${logPrefix} OpenAI response received. Finish reason: ${response.choices[0].finish_reason}`);
    // console.log(`${logPrefix} Full OpenAI response message:`, JSON.stringify(responseMessage, null, 2));


    // If OpenAI wants to call one or more tools
    if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0) {
      console.log(`${logPrefix} OpenAI response includes ${responseMessage.tool_calls.length} tool call(s).`);
      console.log(`${logPrefix} Tool calls: ${JSON.stringify(responseMessage.tool_calls)}`);
      
      // Option 1: If your client-side is set up to execute tools
      // Send the assistant's message (which includes tool_calls) back to the client.
      // The client will then execute the tools and send the results back.
      // This is the standard parallel function calling flow.
      
      // If only ONE tool call is present and we want to execute it immediately on the backend (legacy or specific design):
      // This was the "singleToolId" logic previously.
      // For now, we will follow the standard approach: return the message with tool_calls to the client.
      // The client is expected to make a new POST request for each tool execution (or a batch if supported).
      // However, the prompt implies this backend function *can* execute tools.
      // The original code structure had a path for direct tool execution.

      // Let's assume if OpenAI returns tool_calls, we send them back to the client for execution.
      // The client then sends a new request with the tool_response.
      // This current function should NOT execute tools returned by OpenAI in this path.
      // It should only execute tools if it receives a `requestBody.tool_call` (direct execution request).

            return {
              statusCode: 200,
        body: JSON.stringify(responseMessage), // Send the assistant's turn (incl. tool_calls)
        headers: { 'Content-Type': 'application/json' },
            };

          } else {
      // If OpenAI returns a direct message without tool calls
            console.log(`${logPrefix} OpenAI response is a direct message.`);
      // console.log(`${logPrefix} Message content: ${responseMessage.content ? responseMessage.content.substring(0, 200) : 'N/A'}...`);
            return {
              statusCode: 200,
        body: JSON.stringify(responseMessage), // Send the assistant's direct message
        headers: { 'Content-Type': 'application/json' },
      };
    }

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred processing the request.";
    let errorStack = error instanceof Error ? error.stack : undefined;
    
    console.error(`${logPrefix} Error in handler: ${errorMessage}`, errorStack);

    // Check for OpenAI specific errors if possible
    if (error instanceof OpenAI.APIError) {
        console.error(`${logPrefix} OpenAI API Error: status=${error.status}, type=${error.type}, code=${error.code}, param=${error.param}`);
        // Sanitize OpenAI error before sending to client if needed, or send a generic message
        return {
            statusCode: error.status || 500,
            body: JSON.stringify({ 
                message: `OpenAI API Error: ${error.message}`,
                type: error.type,
                code: error.code
            }),
            headers: { 'Content-Type': 'application/json' },
        };
    }

    return {
      statusCode: 500,
      body: JSON.stringify({ message: "An internal server error occurred.", details: errorMessage }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
};
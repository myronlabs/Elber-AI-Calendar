import type { Handler, HandlerEvent, HandlerContext, HandlerResponse } from "@netlify/functions";
import { getUserIdFromEvent } from './_shared/utils';
import { FastContactFormatter } from '@services/fastContactFormatter';
import { Contact } from '../types/domain';
import { getAssistantConfig } from '@services/assistantConfig';

interface AssistantContactsFastRequestBody {
  action: string;
  searchTerm?: string; // searchTerm might be optional depending on usage
  contacts: Contact[]; // Use imported Contact type
}

/**
 * Fast Contact Assistant Handler
 * Provides instant responses for contact searches without OpenAI
 */
export const handler: Handler = async (event: HandlerEvent, context: HandlerContext): Promise<HandlerResponse> => {
  const reqId = context.awsRequestId || `local-${Date.now()}`;
  const logPrefix = `[assistant-contacts-fast][${reqId}]`;
  
  console.log(`${logPrefix} Function invoked`);
  
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method Not Allowed' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
  
  const userId = getUserIdFromEvent(event, 'assistant-contacts-fast');
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: 'Authentication required' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
  
  try {
    const parsedEventBody = JSON.parse(event.body || '{}') as AssistantContactsFastRequestBody;
    const { action, searchTerm, contacts } = parsedEventBody;
    
    if (action !== 'format_contacts') {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid action' }),
        headers: { 'Content-Type': 'application/json' },
      };
    }
    
    const config = getAssistantConfig();
    
    if (!contacts || !Array.isArray(contacts)) {
        console.error(`${logPrefix} Contacts array is missing or not an array in request body.`);
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Invalid request: contacts must be an array.' }),
            headers: { 'Content-Type': 'application/json' },
        };
    }
    
    // Format contacts using fast formatter
    let formattedResponse: string;
    
    if (contacts.length > config.contactSummaryThreshold) {
      formattedResponse = FastContactFormatter.formatContactSummary(
        contacts, 
        config.contactSummaryThreshold
      );
    } else {
      formattedResponse = FastContactFormatter.formatContactsForDisplay(
        contacts,
        searchTerm || "" // Pass empty string if searchTerm is undefined
      );
    }
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        role: 'assistant',
        content: formattedResponse
      }),
      headers: { 'Content-Type': 'application/json' },
    };
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error(`${logPrefix} Error:`, error);
    
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error', error: errorMessage }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
};
import type { Handler, HandlerEvent, HandlerContext, HandlerResponse } from "@netlify/functions";
import { getUserIdFromEvent, getInternalApiBaseUrl, getInternalHeaders } from './_shared/utils';
import { FastContactFormatter } from '@services/fastContactFormatter';
import { ContactSearchResponse, prioritizeContactsByMatchType } from '../types/search';
import fetch, { Response as FetchResponse } from 'node-fetch';

interface ContactsInstantSearchRequestBody {
  searchTerm: string;
}

// Reuse the ContactSearchResponse type from our shared types
type ContactsSearchApiResponse = ContactSearchResponse;

/**
 * Instant Contact Search
 * Combines search and formatting in one fast endpoint
 * Completely bypasses OpenAI for immediate results
 */
export const handler: Handler = async (event: HandlerEvent, context: HandlerContext): Promise<HandlerResponse> => {
  const reqId = context.awsRequestId || `local-${Date.now()}`;
  const logPrefix = `[contacts-instant-search][${reqId}]`;
  
  console.log(`${logPrefix} Function invoked`);
  
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method Not Allowed' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
  
  const userId = getUserIdFromEvent(event, 'contacts-instant-search');
  if (!userId) {
    return {
      statusCode: 401,
      body: JSON.stringify({ message: 'Authentication required' }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
  
  try {
    const parsedEventBody = JSON.parse(event.body || '{}') as ContactsInstantSearchRequestBody;
    const { searchTerm } = parsedEventBody;
    
    if (!searchTerm || typeof searchTerm !== 'string') {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Search term is required and must be a string' }),
        headers: { 'Content-Type': 'application/json' },
      };
    }
    
    console.log(`${logPrefix} Searching for: "${searchTerm}"`);
    
    // Call the optimized search endpoint
    const searchUrl = `${getInternalApiBaseUrl()}/.netlify/functions/contacts-search`;
    const fetchResponse: FetchResponse = await fetch(searchUrl, {
      method: 'POST',
      headers: {
        ...getInternalHeaders(event.headers),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        query: searchTerm,
        limit: 50,
        offset: 0
      })
    });
    
    if (!fetchResponse.ok) {
      throw new Error(`Search failed: ${fetchResponse.statusText}`);
    }
    
    const searchResult = await fetchResponse.json() as ContactsSearchApiResponse;
    const { contacts, total, cached } = searchResult;
    
    // Log the contacts order to help debug sorting issues
    console.log(`${logPrefix} Results from contacts-search: ${contacts.length} contacts found, cached: ${cached}`);
    if (contacts.length > 0) {
      console.log(`${logPrefix} First result: ${contacts[0].first_name} ${contacts[0].last_name || ''} (ID: ${contacts[0].contact_id})`);
      if (contacts.length > 1) {
        console.log(`${logPrefix} Second result: ${contacts[1].first_name} ${contacts[1].last_name || ''} (ID: ${contacts[1].contact_id})`);
      }
    }
    
    if (!Array.isArray(contacts)) {
      console.error(`${logPrefix} contacts-search API did not return a contacts array.`);
      return {
        statusCode: 500,
        body: JSON.stringify({ message: 'Internal server error: Invalid response from search service.' }),
        headers: { 'Content-Type': 'application/json' },
      };
    }

    // Use the type-safe match determiner from our shared utility
    const cleanQuery = searchTerm.trim();
    
    // Log all contacts and their match types for debugging
    console.log(`${logPrefix} Analyzing ${contacts.length} contacts for match types with query: "${cleanQuery}"`);
    
    // Initialize filteredContacts with all contacts
    let filteredContacts = [...contacts];
    
    // Check if we have any exact name matches or high-ranking matches that should be prioritized
    // by using our get_exact_name_matches function via an internal call to contacts-search
    if (cleanQuery.length > 0) {
      // This will use our database's scoring function to get exact matches
      console.log(`${logPrefix} Checking for exact name matches using SQL function`);
      
      try {
        // Call the same endpoint but with a special parameter to use our exact match function
        const exactMatchUrl = `${getInternalApiBaseUrl()}/.netlify/functions/contacts-search`;
        const exactMatchHeaders = getInternalHeaders(event.headers);
        
        // Generate a unique request ID for tracking this exact match request
        const exactMatchRequestId = `exact-matches-${Date.now()}`;
        
        const exactMatchResponse: FetchResponse = await fetch(exactMatchUrl, {
          method: 'POST',
          headers: {
            ...exactMatchHeaders,
            'Content-Type': 'application/json',
            'X-Request-Id': exactMatchRequestId,
            // Add special header to indicate we want exact matches
            'X-Search-Mode': 'exact_matches'
          },
          body: JSON.stringify({
            query: cleanQuery,
            limit: 10,  // We only need a few top matches
            offset: 0
          })
        });
        
        if (exactMatchResponse.ok) {
          const exactMatchResults = await exactMatchResponse.json() as ContactsSearchApiResponse;
          const exactMatches = exactMatchResults.contacts;
          
          if (exactMatches && exactMatches.length > 0) {
            console.log(`${logPrefix} Found ${exactMatches.length} exact matches using SQL function`);
            
            // Replace our contact list with only the exact matches if there are any
            if (exactMatches.length === 1) {
              // Single exact match - return only this one
              console.log(`${logPrefix} Using single exact match: ${exactMatches[0].first_name} ${exactMatches[0].last_name || ''}`);
              filteredContacts = exactMatches;
            } else if (exactMatches.length > 1) {
              // Multiple exact matches - return these prioritized contacts
              console.log(`${logPrefix} Using ${exactMatches.length} prioritized exact matches`);
              filteredContacts = exactMatches;
            }
          } else {
            console.log(`${logPrefix} No exact matches found using SQL function`);
          }
        } else {
          console.log(`${logPrefix} Exact match query failed with status: ${exactMatchResponse.status}`);
        }
      } catch (error) {
        // If the exact match query fails, we'll fall back to the standard results
        console.error(`${logPrefix} Error fetching exact matches:`, error);
      }
    }
    
    // Fall back to our categorization logic if we couldn't use the SQL function
    // or if we didn't find any exact matches
    if (contacts.length > 1) {
      // Use our shared utility to prioritize contacts by match type
      const prioritizedContacts = prioritizeContactsByMatchType(contacts, cleanQuery);
      
      // Log the prioritized results
      console.log(`${logPrefix} Contacts prioritized by match type: ${prioritizedContacts.length} contacts`);
      if (prioritizedContacts.length > 0) {
        console.log(`${logPrefix} First prioritized contact: ${prioritizedContacts[0].first_name} ${prioritizedContacts[0].last_name || ''} (ID: ${prioritizedContacts[0].contact_id})`);
        if (prioritizedContacts.length > 1) {
          console.log(`${logPrefix} Second prioritized contact: ${prioritizedContacts[1].first_name} ${prioritizedContacts[1].last_name || ''} (ID: ${prioritizedContacts[1].contact_id})`);
        }
      }
      
      // Update the filtered contacts with the prioritized list
      filteredContacts = prioritizedContacts;
      
      // Special case for exact full name matches - only return these
      // Check if the first contact is an exact full name match
      if (prioritizedContacts.length > 0) {
        const firstContactFullName = `${prioritizedContacts[0].first_name || ''} ${prioritizedContacts[0].last_name || ''}`.trim().toLowerCase();
        const isExactMatch = firstContactFullName === cleanQuery.toLowerCase();
        
        if (isExactMatch) {
          // Find all exact matches (could be more than one person with same name)
          const exactFullNameMatches = prioritizedContacts.filter(contact => {
            const fullName = `${contact.first_name || ''} ${contact.last_name || ''}`.trim().toLowerCase();
            return fullName === cleanQuery.toLowerCase();
          });
          
          if (exactFullNameMatches.length > 0) {
            console.log(`${logPrefix} Found ${exactFullNameMatches.length} exact full name matches. Using ONLY these.`);
            filteredContacts = exactFullNameMatches;
          }
        }
      }
    }
    
    // Log the final filtered contacts that will be displayed to the user
    console.log(`${logPrefix} Final contacts to display: ${filteredContacts.length} contacts`);
    if (filteredContacts.length > 0) {
      console.log(`${logPrefix} First result in final display: ${filteredContacts[0].first_name} ${filteredContacts[0].last_name || ''} (ID: ${filteredContacts[0].contact_id})`);
      if (filteredContacts.length > 1) {
        console.log(`${logPrefix} Second result in final display: ${filteredContacts[1].first_name} ${filteredContacts[1].last_name || ''} (ID: ${filteredContacts[1].contact_id})`);
      }
    }
    
    // Format the filtered results
    const formattedResponse = FastContactFormatter.formatContactsForDisplay(
      filteredContacts,
      searchTerm
    );
    
    // Return in the same format as assistant messages
    return {
      statusCode: 200,
      body: JSON.stringify({
        messages: [{
          role: 'assistant',
          content: formattedResponse
        }],
        // Add structured data to the response for better frontend handling
        structuredData: {
          contacts: filteredContacts.map(contact => ({
            contact_id: contact.contact_id,
            first_name: contact.first_name,
            last_name: contact.last_name,
            email: contact.email,
            phone: contact.phone,
            company: contact.company,
            job_title: contact.job_title,
            formatted_address: contact.formatted_address,
            street_address: contact.street_address,
            city: contact.city,
            state_province: contact.state_province,
            postal_code: contact.postal_code,
            country: contact.country,
            birthday: contact.birthday,
            notes: contact.notes
            // No need to include match_score as the array order already reflects it
          }))
        },
        searchMetadata: {
          totalFound: filteredContacts.length, // Use filtered count
          hasMore: filteredContacts.length < total, // Only true if we filtered results
          cached: cached
        }
      }),
      headers: { 'Content-Type': 'application/json' },
    };
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error(`${logPrefix} Error:`, error);
    
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error', error: errorMessage }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
};
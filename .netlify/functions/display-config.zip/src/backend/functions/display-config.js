"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/backend/functions/display-config.ts
var display_config_exports = {};
__export(display_config_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(display_config_exports);

// src/backend/services/displayConfigService.ts
var defaultConfigs = {
  mobile: {
    dpi: 326,
    // iPhone-like DPI
    devicePixelRatio: 2
  },
  tablet: {
    dpi: 264,
    // iPad-like DPI
    devicePixelRatio: 2
  },
  desktop: {
    dpi: 96,
    // Standard desktop DPI
    devicePixelRatio: 1
  }
};
function detectDeviceType(deviceInfo) {
  const { screenWidth, screenHeight, userAgent } = deviceInfo;
  const smallerDimension = Math.min(screenWidth, screenHeight);
  const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
  if (mobileRegex.test(userAgent)) {
    if (smallerDimension < 600) {
      return "mobile";
    } else {
      return "tablet";
    }
  }
  return "desktop";
}
function getOrientation(width, height) {
  return height > width ? "portrait" : "landscape";
}
function calculateDPI(deviceInfo) {
  const deviceType = detectDeviceType(deviceInfo);
  const baseDPI = defaultConfigs[deviceType].dpi;
  const adjustedDPI = baseDPI * (deviceInfo.devicePixelRatio || 1);
  return Math.round(adjustedDPI);
}
function createDisplayConfig(deviceInfo) {
  const deviceType = detectDeviceType(deviceInfo);
  const orientation = getOrientation(deviceInfo.screenWidth, deviceInfo.screenHeight);
  const dpi = calculateDPI(deviceInfo);
  return {
    dpi,
    width: deviceInfo.screenWidth,
    height: deviceInfo.screenHeight,
    devicePixelRatio: deviceInfo.devicePixelRatio || defaultConfigs[deviceType].devicePixelRatio,
    screenType: deviceType,
    orientation
  };
}
var globalDisplayConfig = null;
function setGlobalDisplayConfig(config) {
  globalDisplayConfig = config;
}
function getGlobalDisplayConfig() {
  return globalDisplayConfig;
}

// src/backend/functions/display-config.ts
var handler = async (event, _context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  console.log(`[display-config] Request method: ${event.httpMethod}, Path: ${event.path}`);
  console.log(`[display-config] Content-Type: ${event.headers["content-type"] || event.headers["Content-Type"] || "Not provided"}`);
  if (event.body) {
    try {
      console.log(`[display-config] Request body preview: ${event.body.substring(0, 100)}...`);
    } catch (e) {
      console.log(`[display-config] Request body logging error:`, e);
    }
  }
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers,
      body: ""
    };
  }
  try {
    if (event.httpMethod === "GET") {
      const displayConfig = getGlobalDisplayConfig();
      if (!displayConfig) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({
            error: "No display configuration found. Please set one first."
          })
        };
      }
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          displayConfig
        })
      };
    } else if (event.httpMethod === "POST") {
      let clientDeviceInfo;
      try {
        if (!event.body) {
          throw new Error("Request body is empty");
        }
        clientDeviceInfo = JSON.parse(event.body);
        console.log("[display-config] Successfully parsed request body as JSON");
      } catch (parseError) {
        console.error("[display-config] Error parsing request body:", parseError);
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            error: "Invalid JSON in request body",
            details: parseError instanceof Error ? parseError.message : String(parseError),
            received: event.body ? event.body.substring(0, 100) + "..." : "empty body"
          })
        };
      }
      if (!clientDeviceInfo.screenWidth || !clientDeviceInfo.screenHeight) {
        console.error("[display-config] Missing required fields in client device info:", clientDeviceInfo);
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            error: "Invalid request. screenWidth and screenHeight are required.",
            received: clientDeviceInfo
          })
        };
      }
      const displayConfig = createDisplayConfig(clientDeviceInfo);
      setGlobalDisplayConfig(displayConfig);
      console.log("Display configuration updated:", displayConfig);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          displayConfig
        })
      };
    } else {
      return {
        statusCode: 405,
        headers,
        body: JSON.stringify({
          error: "Method not allowed"
        })
      };
    }
  } catch (error) {
    console.error("Error handling display configuration request:", error);
    console.error("Request method:", event.httpMethod);
    console.error("Request path:", event.path);
    console.error("Request headers:", JSON.stringify(event.headers));
    if (event.body) {
      try {
        console.error("Request body preview:", event.body.substring(0, 150));
      } catch (e) {
        console.error("Could not log request body:", e);
      }
    }
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to process display configuration request.",
        details: error instanceof Error ? error.message : String(error),
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        path: event.path,
        method: event.httpMethod
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
